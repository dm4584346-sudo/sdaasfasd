"use strict";
/* Wave Desktop 4.5 — renderer. All data comes from the main process via window.wave.call.
   Two interfaces share this file: "classic" (4.1 look) and "glass" (new). Switch: Настройки → Интерфейс. */
const $ = (s) => document.querySelector(s),
  $$ = (s) => [...document.querySelectorAll(s)];
const root = document.documentElement;
const isGlass = () => root.dataset.ui === "glass";
const isSpotify = () => isGlass() && root.dataset.skin === "spotify";
// 4.20: the PC pages of the Spotify skin («Моя волна», the album hero) do not fit a phone — it keeps its own
const spDesk = () => isSpotify() && !root.hasAttribute("data-mobile");
const api = (n, d) =>
  window.wave
    ? window.wave.call(n, d).catch((e) => {
        throw new Error(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ""));
      })
    : Promise.reject(new Error("Запустите приложение через Wave Desktop.exe"));
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
/* Smaller artwork for lists: a 44px row does not need a 500×500 jpeg (that was a big part of the lag
   when opening large playlists). size: s ≈ 100px, m ≈ 300px, l ≈ 500px+ */
function thumb(u, size = "m") {
  if (!u || typeof u !== "string" || u.startsWith("data:")) return u || "";
  // s / m / l — lists, cards, big covers; x — the cover viewer (largest size the CDN has)
  const k = { s: 0, m: 1, l: 2, x: 3 }[size] ?? 2;
  if (/sndcdn\.com\/visuals-/.test(u)) return u; // banners: no square sizes
  if (/sndcdn\.com\//.test(u))
    return u.replace(/-(large|t\d+x\d+|original|crop)\./, ["-t300x300.", "-t300x300.", "-t500x500.", "-t500x500."][k]);
  if (/avatars\.yandex\.net\//.test(u))
    return u.replace(/\/(\d+x\d+|%%)$/, "/" + ["300x300", "400x400", "600x600", "1000x1000"][k]);
  if (/\/(150x150|480x480|1000x1000)\.jpg/.test(u))
    return u.replace(
      /\/(150x150|480x480|1000x1000)\.jpg/,
      "/" + ["480x480", "480x480", "1000x1000", "1000x1000"][k] + ".jpg",
    );
  if (/i\.scdn\.co\/image\/ab67616d0000(b273|1e02|4851)/.test(u))
    return u.replace(/ab67616d0000(b273|1e02|4851)/, "ab67616d0000" + ["1e02", "1e02", "b273", "b273"][k]);
  return u;
}
const cssUrl = (u) => `url("${String(u).replace(/["\\\n\r]/g, (c) => "\\" + c)}")`;
const bg = (u, sz = "m") => (u ? `style="background-image:url('${esc(thumb(u, sz))}')"` : "");
// lazy background: set when the element scrolls into view (cards, shelves, grids)
const lbg = (u, sz = "m") => (u ? `data-bg="${esc(thumb(u, sz))}"` : "");
const fmt = (s) => {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600),
    m = Math.floor((s % 3600) / 60),
    x = String(s % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${x}` : `${m}:${x}`;
};
const plural = (n, a, b, c) => {
  const m = n % 10,
    h = n % 100;
  return n + " " + (m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 10 || h >= 20) ? b : c);
};
// "Name (Super Slowed)" -> ["Name", "Super Slowed"] — the new interface shows the version in grey
function splitTitle(t) {
  const s = String(t || "");
  const m = s.match(/^(.+?)\s*[([]([^()[\]]{1,70})[)\]]\s*$/);
  return m ? [m[1], m[2]] : [s, ""];
}
const SRC = { soundcloud: "SC", audius: "AU", spotify: "SP", yandex: "YM", youtube: "YT", local: "Файл" };
const SRC_NAME = {
  soundcloud: "SoundCloud",
  audius: "Audius",
  youtube: "YouTube Music",
  spotify: "Spotify",
  yandex: "Яндекс Музыка",
  local: "Свой файл",
};
const icon = (id, cls = "") => `<svg class="${cls}"><use href="#i-${id}"/></svg>`;
const S = {
  settings: null,
  likes: [],
  likeSet: new Set(),
  dislikes: new Set(),
  playlists: [],
  history: [],
  likesCover: null,
  spotify: { connected: false },
  queue: [],
  index: -1,
  wave: false,
  waveOpts: {},
  shuffle: false,
  repeat: "off",
  current: null,
  stream: null,
  lists: {},
  listSeq: 0,
  back: [],
  fwd: [],
  route: null,
  errors: 0,
  searchSource: "all",
  lastSearch: "",
  matchedInfo: null,
  palette: null,
  hotOf: {},
  bg: false,
  unfocused: false,
};
let audio = $("#audio"); // may be swapped (see swapAudio)
let hls = null,
  toastT;
function toast(m, ms = 4200) {
  const t = $("#toast");
  t.textContent = m;
  t.hidden = false;
  clearTimeout(toastT);
  toastT = setTimeout(() => (t.hidden = true), ms);
}
const reg = (list) => {
  const id = "l" + ++S.listSeq;
  S.lists[id] = list;
  return id;
};
const debounce = (f, ms) => {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => f(...a), ms);
  };
};

/* ---------------- rendering helpers ---------------- */
const NO_ARTIST = "Неизвестный исполнитель";
function artistList(t) {
  if (!t) return [];
  if (t.artists && t.artists.length) return t.artists.filter((x) => x && x.name);
  return String(t.artist || "")
    .split(/,\s*/)
    .filter(Boolean)
    .map((name) => ({ name }));
}
// every artist is a link: without an id the page is found by name (SoundCloud / Audius search)
function artistsHtml(t) {
  return artistList(t)
    .map((x) =>
      x.name === NO_ARTIST
        ? esc(x.name)
        : `<a data-artist="${esc(x.id || "")}" data-name="${esc(x.name)}">${esc(x.name)}</a>`,
    )
    .join(", ");
}
function titleHtml(title) {
  if (!isGlass()) return esc(title);
  const [m, v] = splitTitle(title);
  return `<b>${esc(m)}</b>${v ? ` <span class="tv">${esc(v)}</span>` : ""}`;
}
function trackRow(t, lid, i, { num = false, top = null } = {}) {
  const cur = S.current && S.current.id === t.id;
  const liked = S.likeSet.has(t.id);
  const mi = S.matchedInfo?.[t.id];
  const hot = S.hotOf[lid] === t.id ? `<span class="hot" title="Самый прослушиваемый">${icon("bolt")}</span>` : "";
  const hl = S.hlTrack && S.hlTrack.route === S.route && S.hlTrack.id === t.id ? " hl-track" : "";
  return `<div class="tr${num ? " num" : ""}${cur ? " cur" : ""}${hl}" data-l="${lid}" data-i="${i}"${top != null ? ` style="top:${top}px"` : ""}>${num ? `<span class="n">${i + 1}</span>` : ""}
  <div class="c" ${bg(t.cover, "s")}>${t.cover ? "" : icon("note")}<span class="ov">${cur && !audio.paused ? '<span class="eq"><i></i><i></i><i></i></span>' : icon("play")}</span></div>
  <div class="tm"><div class="tt">${hot}${t.explicit ? '<span class="badge-e">E</span>' : ""}${titleHtml(t.title)}</div><div class="ta"><span class="src ${t.source}">${SRC[t.source] || "SC"}</span>${mi ? `<span class="mt" title="Играет: ${esc(mi.artist + " — " + mi.title)}">→ ${SRC[mi.source] || "SC"}</span>` : ""}${artistsHtml(t)}</div></div>
  ${isSpotify() && num && S.spShowPlays && S.route?.startsWith("rplaylist:yma:") ? `<span class="sp-play-count">${Number.isFinite(t.plays) ? fmtNum(t.plays) : "—"}</span>` : ""}
  <button class="icon-btn lk${liked ? " on" : ""}" data-act="like" title="Нравится">${icon(liked ? "heart" : "heart-o")}</button>
  <span class="d">${t.duration ? fmt(t.duration) : ""}</span>
  <button class="icon-btn more" data-act="menu" title="Ещё">${icon("more")}</button></div>`;
}

/* ---------- virtual track lists: only rows near the viewport exist in the DOM ---------- */
const VL_MIN = 40;
const rowH = () => (isGlass() ? 62 : 56);
const VLS = new Set();
// ⚡ «самый прослушиваемый»: the Yandex album best track, else the most played one (needs play counts)
function hotId(list) {
  const h = list.find((t) => t.hot);
  if (h) return h.id;
  let best = null,
    n = 0;
  for (const t of list)
    if (t.plays > 0) {
      n++;
      if (!best || t.plays > best.plays) best = t;
    }
  return n >= 2 ? best.id : null;
}
const tracksHtml = (list, opt = {}) => {
  if (!list.length) return '<div class="empty"><b>Пусто</b>Здесь пока нет треков</div>';
  const lid = reg(list);
  if (opt.hot !== false) {
    const h = hotId(list);
    if (h) S.hotOf[lid] = h;
  }
  if (list.length <= VL_MIN)
    return `<div class="tracks${opt.cols ? " " + opt.cols : ""}">${list.map((t, i) => trackRow(t, lid, i, opt)).join("")}</div>`;
  return `<div class="tracks vlist" data-vl="${lid}" data-num="${opt.num ? 1 : ""}" style="height:${list.length * rowH()}px"></div>`;
};
function vlMount(el) {
  el.classList.add("on");
  const list = S.lists[el.dataset.vl];
  if (!list) return;
  el._vl = { lid: el.dataset.vl, num: !!el.dataset.num, a: -1, b: -1, h: rowH() };
  el.style.height = list.length * el._vl.h + "px";
  VLS.add(el);
  vlRender(el, true);
}
function vlRender(el, force) {
  const st = el._vl,
    list = st && S.lists[st.lid];
  if (!list) return;
  const sc = el.closest(".content,.queue-list") || document.documentElement;
  const r = el.getBoundingClientRect(),
    cr = sc.getBoundingClientRect();
  const h = st.h,
    top = cr.top - r.top,
    bottom = top + cr.height;
  let a = Math.max(0, Math.floor(top / h) - 10),
    b = Math.min(list.length, Math.ceil(bottom / h) + 10);
  a = Math.floor(a / 8) * 8;
  b = Math.min(list.length, Math.ceil(b / 8) * 8);
  if (b < a) b = a;
  if (!force && a === st.a && b === st.b) return;
  st.a = a;
  st.b = b;
  let html = "";
  for (let i = a; i < b; i++) html += trackRow(list[i], st.lid, i, { num: st.num, top: i * h });
  el.innerHTML = html;
}
function vlUpdateAll(force) {
  for (const el of VLS) {
    if (!el.isConnected) VLS.delete(el);
    else vlRender(el, force);
  }
}
let vlRaf = 0;
const vlSchedule = () => {
  if (!vlRaf)
    vlRaf = requestAnimationFrame(() => {
      vlRaf = 0;
      vlUpdateAll(false);
    });
};
addEventListener("resize", vlSchedule);

/* ---------- lazy images ---------- */
const lazyIO =
  "IntersectionObserver" in window
    ? new IntersectionObserver(
        (ents) => {
          for (const en of ents)
            if (en.isIntersecting) {
              const el = en.target;
              el.style.backgroundImage = cssUrl(el.dataset.bg);
              el.removeAttribute("data-bg");
              lazyIO.unobserve(el);
            }
        },
        { rootMargin: "400px 900px" },
      )
    : null;
function lazyScan() {
  for (const el of document.querySelectorAll("[data-bg]:not(.lz)")) {
    el.classList.add("lz");
    if (lazyIO) lazyIO.observe(el);
    else el.style.backgroundImage = cssUrl(el.dataset.bg);
  }
}
new MutationObserver((muts) => {
  // ignore our own virtual-list row swaps
  if (muts.every((m) => m.target.classList && m.target.classList.contains("vlist"))) return;
  for (const el of document.querySelectorAll(".vlist:not(.on)")) vlMount(el);
  lazyScan();
}).observe(document.body, { childList: true, subtree: true });
function trackCard(t, lid, i) {
  return `<button class="card" data-l="${lid}" data-i="${i}" data-act="play-card"><div class="cv" ${lbg(t.cover)}><div class="hov"><span class="pbtn">${icon("play")}</span></div></div><b>${esc(t.title)}</b><small>${esc(t.artist)}</small></button>`;
}
function shelf(title, list, { go, cards = "track", note = "", cls = "" } = {}) {
  if (!list || !list.length) return "";
  let items;
  if (cards === "track") {
    const lid = reg(list);
    items = list.map((t, i) => trackCard(t, lid, i)).join("");
  } else items = list.map(cards).join("");
  return shelfHtml(title, items, { go, note, cls: cls || (cards === clipCard ? "clips" : "") });
}
// a titled horizontal shelf with ‹ › arrows (disabled at the ends, see shelfArrows)
function shelfHtml(title, items, { go, note = "", cls = "" } = {}) {
  if (!items) return "";
  const sid = "s" + ++S.listSeq;
  return `<section class="section"><div class="sec-head"><h2>${go ? `<button data-go="${esc(go)}">${esc(title)}<i class="arr">›</i></button>` : esc(title)}</h2>${note ? `<span class="sec-note">${esc(note)}</span>` : ""}<div class="shelf-nav"><button class="round-btn" data-scroll="${sid}" data-dir="-1" title="Назад">${icon("left")}</button><button class="round-btn" data-scroll="${sid}" data-dir="1" title="Вперёд">${icon("right")}</button></div></div><div class="shelf${cls ? " " + cls : ""}" id="${sid}">${items}</div></section>`;
}
const plCard = (p) =>
  `<button class="card" data-go="${p.id.startsWith("local:") ? "playlist" : "rplaylist"}:${esc(p.id)}"><div class="cv" ${lbg(p.cover)}>${p.cover ? "" : `<div class="cv-ph">${icon("note")}</div>`}<div class="hov"><span class="pbtn">${icon("right")}</span></div></div><b>${esc(p.title)}</b><small>${esc(p.owner || plural(p.count || 0, "трек", "трека", "треков"))}</small></button>`;
const artistCard = (a) =>
  `<button class="card" data-artist="${esc(a.id || "")}" data-name="${esc(a.name)}"><div class="cv round" ${lbg(a.avatar)}>${a.avatar ? "" : `<div class="cv-ph">${esc((a.name || "?")[0])}</div>`}</div><b style="text-align:center">${esc(a.name)}</b><small style="text-align:center">${a.followers ? fans(a.followers) : a.genre ? esc(a.genre) : "Исполнитель"}</small></button>`;
const fans = (n) => (n >= 1e4 ? fmtBig(n) + " подписчиков" : plural(n, "подписчик", "подписчика", "подписчиков"));
// 4.8: albums (year · type) and YouTube clips (open in the browser)
const albCard = (p) =>
  `<button class="card" data-go="rplaylist:${esc(p.id)}"><div class="cv" ${lbg(p.cover)}>${p.cover ? "" : `<div class="cv-ph">${icon("note")}</div>`}<div class="hov"><span class="pbtn">${icon("right")}</span></div></div><b>${esc(p.title)}</b><small>${esc([p.year, p.kind].filter(Boolean).join(" · ") || p.owner || "")}</small></button>`;
/* 4.9: clips play inside Wave — main puts the YouTube embed player (a separate WebContentsView) exactly over
   .clip-frame; the renderer only draws the dimmed box and reports the frame's position. Music pauses while a clip
   plays and resumes after it, if it was playing. */
const CLIP = { box: null, resume: false, ro: null, raf: 0 };
function clipRect() {
  const r = CLIP.box?.querySelector(".clip-frame")?.getBoundingClientRect();
  return r && { x: r.left, y: r.top, w: r.width, h: r.height };
}
function clipSync() {
  cancelAnimationFrame(CLIP.raf);
  CLIP.raf = requestAnimationFrame(() => {
    const b = clipRect();
    if (b && CLIP.box) api("clip-bounds", { bounds: b }).catch(() => {});
  });
}
async function openClip(id, { title = "", by = "", link = "" } = {}) {
  if (!id) return;
  if (!/^(yt:)?[A-Za-z0-9_-]{11}$/.test(id)) return link && api("open-external", { url: link });
  closeClip(true);
  const box = document.createElement("div");
  box.className = "clipbox";
  box.innerHTML = `<div class="clip-win" role="dialog" aria-label="${esc(title)}"><div class="clip-head"><div class="clip-t"><b>${esc(title)}</b>${by ? `<small>${esc(by)}</small>` : ""}</div>${link ? `<button class="btn sm ghost" data-ext="${esc(link)}">${icon("link")}Открыть на YouTube</button>` : ""}<button class="iconbtn clip-x" title="Закрыть (Esc)" aria-label="Закрыть">${icon("close")}</button></div><div class="clip-frame"><span class="clip-load">Загрузка клипа…</span></div></div>`;
  document.body.appendChild(box);
  CLIP.box = box;
  box.addEventListener("click", (e) => {
    if (e.target === box || e.target.closest(".clip-x")) closeClip();
  });
  CLIP.resume = !!S.current && !audio.paused;
  if (CLIP.resume) togglePlay();
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  if (CLIP.box !== box) return;
  CLIP.ro = new ResizeObserver(clipSync);
  CLIP.ro.observe(box.querySelector(".clip-frame"));
  window.addEventListener("resize", clipSync);
  try {
    await api("clip-open", { id, bounds: clipRect() });
  } catch (e) {
    if (CLIP.box !== box) return;
    closeClip();
    toast("Не удалось открыть клип: " + e.message);
    if (link) api("open-external", { url: link });
  }
}
function closeClip(silent) {
  const box = CLIP.box;
  if (!box) return;
  CLIP.box = null;
  CLIP.ro?.disconnect();
  CLIP.ro = null;
  window.removeEventListener("resize", clipSync);
  api("clip-close").catch(() => {});
  box.remove();
  if (CLIP.resume && !silent && S.current && audio.paused) togglePlay();
  if (!silent) CLIP.resume = false;
}
const clipCard = (v) =>
  `<button class="card clip" data-clip="${esc(v.id)}" data-link="${esc(v.link)}" data-title="${esc(v.title)}" data-by="${esc(v.artist || "")}" title="Смотреть клип"><div class="cv wide" ${lbg(v.thumb || v.cover)}><div class="hov"><span class="pbtn">${icon("play")}</span></div>${v.duration ? `<span class="cdur">${fmt(v.duration)}</span>` : ""}</div><b>${esc(v.title)}</b><small>${esc(v.artist)}</small></button>`;
const skel = (n) => Array.from({ length: n }, () => '<div class="skel loading-row"></div>').join("");
let contentSeq = 0;
function setContent(html, { flush = false } = {}) {
  const c = $("#content");
  contentSeq++;
  c.classList.toggle("flush", flush);
  c.innerHTML = html;
  if (c.dataset.pageEnter === "pending" && !html.includes("loading-row")) {
    c.dataset.pageEnter = "done";
    if (S.settings?.animation !== false && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
      c.classList.remove("page-enter");
      void c.offsetWidth;
      c.classList.add("page-enter");
    }
  }
  c.scrollTop = 0;
  syncSticky();
}
/* 4.13: a playlist page scrolled down (like Yandex Music): its title appears in the top bar beside ‹ ›, and its
   genre chips — in a row under the bar, each only after the original went under the bar */
const GS = { seq: -1, h1: null, chips: null };
function syncSticky() {
  const bar = $(".topbar"),
    c = $("#content"),
    ttl = $("#gs-title"),
    row = $("#gs-chips");
  if (!bar || !c || !ttl || !row) return;
  if (GS.seq !== contentSeq) {
    GS.seq = contentSeq;
    GS.h1 = isGlass() ? c.querySelector(".ghero h1") : null;
    GS.chips = GS.h1 ? c.querySelector("#gchips") : null;
    ttl.textContent = GS.h1?.textContent || "";
    row.innerHTML = "";
  }
  if (!GS.h1?.isConnected) {
    bar.classList.remove("gs-t", "gs-c");
    return;
  }
  const edge = c.getBoundingClientRect().top + bar.offsetHeight;
  bar.classList.toggle("gs-t", GS.h1.getBoundingClientRect().bottom < edge);
  const chips = !!GS.chips?.isConnected && GS.chips.getBoundingClientRect().bottom < edge;
  if (chips && !row.childElementCount)
    row.innerHTML = [...GS.chips.querySelectorAll("[data-chip]")]
      .map(
        (b) =>
          `<button class="${esc(b.className)}" data-gs-chip="${esc(b.dataset.chip)}" title="${esc(b.title || "")}">${esc(b.textContent)}</button>`,
      )
      .join("");
  if (chips)
    for (const b of row.children)
      b.classList.toggle("on", !!GS.chips.querySelector(`[data-chip="${b.dataset.gsChip}"].on`));
  bar.classList.toggle("gs-c", chips);
}
// 4.6: a skeleton only when a page takes longer than a blink — fast pages replace the old one directly
function skelLater(n = 8, ms = 160) {
  const seq = contentSeq,
    route = S.route;
  setTimeout(() => contentSeq === seq && S.route === route && setContent(skel(n)), ms);
}

/* ---------------- router ---------------- */
function go(route, { push = true, keep = false } = {}) {
  if (push && S.route && S.route !== route) {
    S.back.push(S.route);
    if (S.back.length > 60) S.back.shift();
    S.fwd = [];
  }
  if (CLIP.box && !keep) closeClip();
  if (S.hlTrack && S.hlTrack.route !== route) S.hlTrack = null;
  const pageChanged = S.route !== route;
  S.route = route;
  if (pageChanged) {
    $("#content").classList.remove("page-enter");
    $("#content").dataset.pageEnter = /^(artist|artist-tracks|track):/.test(route) ? "pending" : "";
  }
  // a re-render of the same page keeps the track panel (and the lists of its rows)
  const keepL = keep ? Object.fromEntries($$("#tpanel [data-l]").map((r) => [r.dataset.l, S.lists[r.dataset.l]])) : {};
  S.lists = { q: S.queue, ...keepL };
  S.hotOf = {};
  if (!keep) closeTrackPanel(true);
  S.matchedInfo = null;
  S.openPlaylist = null;
  S.spShowPlays = false;
  VLS.clear();
  $("#back").disabled = !S.back.length;
  $("#forward").disabled = !S.fwd.length;
  const [name, ...rest] = route.split(":");
  const arg = rest.join(":");
  const wavePage = name === "wave" && isGlass() && !spDesk();
  document.body.classList.toggle("on-wave", wavePage);
  if (!wavePage) WaveFx.stop ? WaveFx.stop() : WaveFx.halt();
  $$(".nav button").forEach((b) =>
    b.classList.toggle(
      "active",
      b.dataset.go === name ||
        (name === "mix" && b.dataset.go === "mix:@all") ||
        ((name === "likes" || name === "playlist" || name === "history" || name === "favartists") &&
          b.dataset.go === "collection") ||
        ((name === "cat" || name === "chart" || name === "genre") && b.dataset.go === "search"),
    ),
  );
  $$(".pin").forEach((b) => b.classList.toggle("active", b.dataset.go === route));
  const views = {
    home,
    wave: () => (spDesk() ? spotifyWaveView() : isGlass() ? waveView() : home()),
    search: () => (isGlass() ? gSearchView(arg) : searchView(arg)),
    collection: () => (isGlass() ? gCollection() : collection()),
    concerts: concertsView,
    books: booksView,
    cat: () => catView(arg),
    chart: chartView,
    likes,
    history: historyView,
    playlist: () => localPlaylist(arg),
    mix: () => (arg === "@all" || !arg ? globalMixView() : mixView(arg)),
    rplaylist: () => remotePlaylist(arg),
    artist: () => artistView(arg),
    "artist-tracks": () => artistTracksView(arg),
    track: () => trackView(arg),
    favartists: favArtistsView,
    profile,
    settings: settingsView,
    offline: () => (window.waveOfflineView || home)(),
    pals: () => (window.WaveSocial ? window.WaveSocial.view("friends") : (window.wavePalsView || home)()),
    friends: () => window.WaveSocial?.view("friends"),
    listen: () => window.WaveSocial?.view("listen"),
    account: () => window.WaveSocial?.openPrivacy(),
    people: () => window.WaveSocial?.view("people", arg),
    genre: () => genreView(arg),
    ymtag: () => ymTagView(arg),
  };
  (views[name] || home)();
}
const reroute = () => {
  const top = $("#content").scrollTop;
  go(S.route, { push: false, keep: true });
  $("#content").scrollTop = top;
};
$("#content").addEventListener(
  "scroll",
  (e) => {
    $(".topbar").classList.toggle("solid", e.target.scrollTop > 40);
    syncSticky();
    vlSchedule();
  },
  { passive: true },
);
$("#gs-title").onclick = () => $("#content").scrollTo({ top: 0, behavior: "smooth" });
$("#gs-chips").onclick = (e) => {
  const b = e.target.closest("[data-gs-chip]");
  if (!b || !GS.chips?.isConnected) return;
  GS.chips.querySelector(`[data-chip="${b.dataset.gsChip}"]`)?.click();
  syncSticky();
};
$("#queue-list").addEventListener("scroll", vlSchedule, { passive: true });
function navBack() {
  if (!S.back.length) return;
  S.fwd.push(S.route);
  go(S.back.pop(), { push: false });
}
function navFwd() {
  if (!S.fwd.length) return;
  S.back.push(S.route);
  go(S.fwd.pop(), { push: false });
}
$("#back").onclick = navBack;
$("#forward").onclick = navFwd;
// 4.6: the side buttons of the mouse go back / forward. Windows also sends them as an app command
// (main process → «nav» event): both paths can fire for one press, so a second one within 250 ms is ignored
let navAt = 0;
function navStep(dir) {
  const now = performance.now();
  if (now - navAt < 250) return;
  navAt = now;
  if (dir > 0) return navFwd();
  // «back» closes an open overlay first (like «Esc»), the page changes on the next press
  if (lboxOpen()) return closeLightbox();
  if (lyOpen()) return toggleLyrics(false);
  if (!fpEl().hidden) return closeFull();
  navBack();
}
addEventListener("mouseup", (e) => {
  if (e.button !== 3 && e.button !== 4) return;
  e.preventDefault();
  navStep(e.button === 3 ? -1 : 1);
});

/* ---------------- views ---------------- */
const MOODS = [
  ["all", "Любое"],
  ["energetic", "Энергичное"],
  ["fun", "Весёлое"],
  ["calm", "Спокойное"],
  ["sad", "Грустное"],
  ["rap", "Рэп"],
  ["rock", "Рок"],
  ["wakeup", "Бодрое утро"],
  ["sleep", "Для сна"],
];
const DIV = [
  ["default", "Всё вперемешку"],
  ["favorite", "Любимое"],
  ["discover", "Незнакомое"],
  ["popular", "Популярное"],
];
function waveHero() {
  const w = S.settings.wave;
  const playing = S.wave && !audio.paused;
  return `<section class="wave${playing ? " playing" : ""}${S.settings.animation ? "" : " no-anim"}" id="wave-hero"><div class="wave-bg"><i class="blob b1"></i><i class="blob b2"></i><i class="blob b3"></i><i class="blob b4"></i></div>
  <div class="wave-in"><h1><button class="wave-play" id="wave-play">${icon(playing ? "pause" : "play")}</button>Моя волна</h1>
  <div class="wave-now" id="wave-now">${S.wave && S.current ? esc(S.current.artist + " — " + S.current.title) : "Бесконечный поток музыки под ваш вкус"}</div>
  <div class="wave-chips">${MOODS.map(([k, v]) => `<button class="chip${w.mood === k ? " on" : ""}" data-mood="${k}">${esc(v)}</button>`).join("")}<button class="chip" id="wave-tune">${icon("tune")}Настроить</button></div></div></section>`;
}
/* ---------------- 4.6: home — «Для вас» / «Тренды» like Yandex Music ----------------
   The Yandex landing (blocks of the web app) fills both tabs; personal blocks need the account and are not
   available outside Russia (HTTP 451) — then «Для вас» is built from the library and SoundCloud / Audius
   shelves, «Тренды» from the open Yandex blocks (chart, editorial playlists) or SoundCloud trends. */
const HOME_TABS = [
  ["foryou", "Для вас"],
  ["popular", "Тренды"],
];
function homeTab() {
  let t = S.homeTab;
  if (!t)
    try {
      t = localStorage.getItem("wave.homeTab");
    } catch {}
  return HOME_TABS.some(([k]) => k === t) ? t : "foryou";
}
async function home() {
  const glass = isGlass();
  const tab = homeTab();
  setContent(
    (glass ? "" : waveHero()) +
      `<div class="htabs" id="htabs" role="tablist">${HOME_TABS.map(([k, v]) => `<button class="htab${k === tab ? " on" : ""}" data-htab="${k}" role="tab">${esc(v)}</button>`).join("")}</div>` +
      `<div id="home-rest">${'<div class="section">' + skel(4) + "</div>"}</div>`,
  );
  if (!glass) bindWave();
  $$("[data-htab]").forEach(
    (b) =>
      (b.onclick = () => {
        if (b.classList.contains("on")) return;
        S.homeTab = b.dataset.htab;
        try {
          localStorage.setItem("wave.homeTab", S.homeTab);
        } catch {}
        $$("[data-htab]").forEach((x) => x.classList.toggle("on", x === b));
        renderHome();
      }),
  );
  const route = S.route;
  const [sc, ym] = await Promise.allSettled([
    S.homeData && Date.now() - S.homeData.at < 300e3 ? S.homeData : api("home").then((d) => ({ ...d, at: Date.now() })),
    api("ym-landing", { id: "main" }),
  ]);
  if (sc.status === "fulfilled") S.homeData = sc.value;
  S.ymMain = ym.status === "fulfilled" ? ym.value : { tabs: [], errors: [ym.reason?.message || "нет ответа"] };
  if (S.route !== route) return;
  if (sc.status === "rejected" && !S.homeData) S.homeErr = sc.reason?.message || "ошибка";
  renderHome();
}
const ymTab = (d, id) => (d?.tabs || []).find((t) => t.id === id)?.blocks || [];
function renderHome() {
  const box = $("#home-rest");
  if (!box) return;
  const tab = homeTab();
  const d = S.homeData || {};
  const RU = {
    "Artists to watch out for": "Артисты, за которыми стоит следить",
    "Curated by SoundCloud": "Подборки SoundCloud",
    "Trending by genre": "В тренде по жанрам",
  };
  const scShelves = (all) =>
    shelf("В тренде на SoundCloud", d.trending) +
    (all
      ? shelf("Рэп и хип-хоп", d.rap) +
        (d.selections || []).map((x) => shelf(RU[x.title] || x.title, x.items, { cards: plCard })).join("") +
        shelf("Фонк", d.phonk)
      : "") +
    shelf("Тренды Audius", d.audius);
  let html = "";
  if (tab === "foryou") {
    const blocks = ymTab(S.ymMain, "foryou");
    // 4.13: «Артист рекомендует» only here (Yandex may put it into «Тренды» — it is moved to «Для вас»)
    const picks = ymTab(S.ymMain, "popular").filter((b) => isPickBlock(b) && !blocks.some((x) => x.id === b.id));
    let local = false;
    for (const b of blocks) {
      if (b.type === "LIKES_AND_HISTORY") {
        html += likesHistoryBlock();
        local = true;
      } else html += ymBlock(b);
    }
    if (!local) html = likesHistoryBlock() + html;
    html += picks.map(ymBlock).join("");
    if (root.dataset.skin === "spotify" && S.playlists.length) html = shelf("Твои плейлисты", S.playlists, { cards: plCard, go: "collection" }) + html;
    // Yandex already gave its own waves → no second «waves by mood» shelf
    const ymWaves = blocks.some((b) => (b.items || []).some((x) => x.kind === "wave"));
    html +=
      (S.playlists.length && root.dataset.skin !== "spotify" ? shelf("Ваши плейлисты", S.playlists, { cards: plCard, go: "collection" }) : "") +
      (ymWaves ? "" : waveTiles()) +
      scShelves(true);
  } else {
    const blocks = ymTab(S.ymMain, "popular").filter((b) => b.type !== "LIKES_AND_HISTORY" && !isPickBlock(b));
    html = blocks.map(ymBlock).join("");
    if (!html.trim()) {
      const why = S.ymMain?.errors?.[0];
      html =
        `<p class="muted ynote">Тренды Яндекс Музыки недоступны${why ? ": " + esc(why.replace(/\.$/, "")) : ""}. Пока показываю тренды SoundCloud и Audius</p>` +
        scShelves(false);
    }
  }
  if (S.homeErr && !S.homeData) html += `<p class="err">Подборки SoundCloud не загрузились: ${esc(S.homeErr)}</p>`;
  else if (d.errors?.length) html += `<p class="err">Часть подборок не загрузилась: ${esc(d.errors.join("; "))}</p>`;
  box.innerHTML =
    html || '<div class="section empty"><b>Пока пусто</b>Проверьте интернет и источники в настройках</div>';
  lazyScan();
}
// «Мне нравится» + «Вы недавно слушали» (the Yandex «likes and history» block, from the local library)
function likesHistoryBlock() {
  const recent = S.history.slice(0, 6);
  if (!S.likes.length && !recent.length) return "";
  const lid = reg(recent),
    lc = S.likesCover;
  return `<section class="section"><div class="sec-head"><h2><button data-go="history">Вы недавно слушали<i class="arr">›</i></button></h2></div><div class="ylikes"><button class="ylk-cover likes" data-go="likes" ${lc ? bg(lc) : ""}>${lc ? "" : icon("heart")}<span><b>Мне нравится</b><small>${plural(S.likes.length, "трек", "трека", "треков")}</small></span></button>${recent.length ? `<div class="tracks cols ylk-list">${recent.map((t, i) => trackRow(t, lid, i)).join("")}</div>` : '<div class="empty">Здесь появятся треки, которые вы слушали</div>'}</div></section>`;
}
// quick waves by mood (own wave; with the Yandex account the station of Yandex is used)
function waveTiles() {
  const items = [
    ["", "Моя волна", "wave", ["#6d4ae6", "#c026d3"]],
    ["energetic", "Энергичное", "bolt", ["#f97316", "#db2777"]],
    ["fun", "Весёлое", "sun", ["#eab308", "#f97316"]],
    ["calm", "Спокойное", "moon", ["#0891b2", "#6366f1"]],
    ["sad", "Грустное", "notes", ["#334155", "#4f46e5"]],
  ];
  return shelfHtml(
    "Волны по настроению",
    items
      .map(
        ([m, t, ic, [a, b]]) =>
          `<button class="ywave" data-wave-mood="${m}" style="--wa:${a};--wb:${b}"><span class="yw-ic">${icon(ic)}</span><b>${esc(t)}</b><small>${m ? "Своя волна" : "По вашему вкусу"}</small></button>`,
      )
      .join(""),
    { cls: "ywaves" },
  );
}
/* ---------- Yandex landing blocks → shelves / chart / open playlist ---------- */
function ymItem(it) {
  if (it.kind === "playlist" || it.kind === "album") {
    const c = it.card;
    const sub = it.kind === "album" ? [c.kind || "Альбом", c.owner].filter(Boolean).join(" · ") : c.owner || "";
    return `<button class="card lcard" data-go="rplaylist:${esc(c.id)}"><div class="cv" ${lbg(c.cover)}>${c.cover ? "" : `<div class="cv-ph">${icon("note")}</div>`}<div class="hov"><span class="pbtn">${icon("right")}</span></div></div><b>${esc(c.title)}</b><small>${esc(sub)}</small>${c.likes ? `<span class="lc-likes">${icon("heart")}${fmtNum(c.likes)}</span>` : ""}</button>`;
  }
  if (it.kind === "artist") {
    const a = it.artist;
    const av = a.avatar || a.cover; // 4.9: the provider gives «avatar» (the avatars were empty in 4.8)
    return `<button class="ycirc" data-artist="${esc(a.id)}" data-name="${esc(a.name)}"><span class="yc-av" ${lbg(av, "s")}>${av ? "" : esc(a.name[0] || "?")}</span><b>${esc(a.name)}</b></button>`;
  }
  if (it.kind === "wave") {
    const w = it.wave;
    return `<button class="ywave img" data-station="${esc(w.station)}" style="--wa:${esc(w.color || "#6d4ae6")};--wb:#1d1350"><span class="yw-cv" ${lbg(w.cover, "s")}>${w.cover ? "" : icon("wave")}</span><b>${esc(w.title)}</b><small>Волна</small></button>`;
  }
  if (it.kind === "mix") {
    const m = it.mix;
    return `<button class="ytile ymix" data-go="ymtag:${esc(m.tag)}|${esc(encodeURIComponent(m.title))}" style="background:${esc(m.color || "#4c1d95")}${m.cover ? `;background-image:url('${esc(m.cover)}')` : ""}"><b>${esc(m.title)}</b><i></i></button>`;
  }
  if (it.kind === "track") {
    const lid = reg([it.track]);
    return trackCard(it.track, lid, 0);
  }
  return "";
}
function ymBlock(b) {
  if (!b) return "";
  const title = b.title || "";
  // 4.7: donation promo («Поддержите донатом») is not shown (also filtered in the provider; old caches)
  if (/донат|donat/i.test(`${title} ${b.description || ""} ${b.type || ""}`)) return "";
  if (b.view === "artistpick") return artistPickBlock(b);
  if (b.view === "chart" && b.tracks?.length) {
    const list = b.tracks.slice(0, 12),
      lid = reg(b.tracks);
    return `<section class="section"><div class="sec-head"><h2>${b.playlist ? `<button data-go="rplaylist:${esc(b.playlist.id)}">${esc(title || "Чарт")}<i class="arr">›</i></button>` : `<button data-go="chart">${esc(title || "Чарт")}<i class="arr">›</i></button>`}</h2><span class="sec-note">${esc(b.description || "Яндекс Музыка")}</span><button class="btn sm ghost yb-play" data-ymplay="${lid}">${icon("play")}Слушать</button></div><div class="tracks cols ychart" style="grid-template-rows:repeat(${Math.ceil(list.length / 2)},auto)">${list.map((t, i) => trackRow(t, lid, i, { num: true })).join("")}</div></section>`;
  }
  if (b.view === "playlist" && b.playlist) {
    const p = b.playlist,
      list = (b.tracks || []).slice(0, 8),
      lid = reg(b.tracks || []);
    return `<section class="section"><div class="sec-head"><h2><button data-go="rplaylist:${esc(p.id)}">${esc(title || p.title)}<i class="arr">›</i></button></h2>${b.description ? `<span class="sec-note">${esc(b.description)}</span>` : ""}</div><div class="yopen"><button class="yo-cover" data-go="rplaylist:${esc(p.id)}" ${bg(p.cover, "l")}><span class="yo-in"><small>Плейлист</small><b>${esc(p.title)}</b>${p.description ? `<i>${esc(p.description.slice(0, 120))}</i>` : ""}</span></button><div class="yo-side"><div class="yo-acts"><button class="pill-acc" data-ymplay="${lid}">${icon("play")}Слушать</button>${p.likes ? `<span class="muted">${icon("heart")} ${fmtNum(p.likes)}</span>` : ""}</div>${list.length ? `<div class="tracks cols ylk-list">${list.map((t, i) => trackRow(t, lid, i)).join("")}</div>` : ""}</div></div></section>`;
  }
  if (b.view === "tracks" && b.tracks?.length) {
    const lid = reg(b.tracks);
    return `<section class="section"><div class="sec-head"><h2>${esc(title)}</h2>${b.description ? `<span class="sec-note">${esc(b.description)}</span>` : ""}<button class="btn sm ghost yb-play" data-ymplay="${lid}">${icon("play")}Слушать</button></div><div class="tracks cols">${b.tracks
      .slice(0, 10)
      .map((t, i) => trackRow(t, lid, i))
      .join("")}</div></section>`;
  }
  const items = (b.items || []).map(ymItem).filter(Boolean);
  if (!items.length) return "";
  const kinds = new Set((b.items || []).map((x) => x.kind));
  const cls = kinds.size === 1 && kinds.has("artist") ? "ycircs" : kinds.size === 1 && kinds.has("mix") ? "ymixes" : "";
  return shelfHtml(title, items.join(""), { note: b.description || "", cls });
}
/* 4.13: «Артист рекомендует» like Yandex Music — three wide cards in a row: a photo of the artist, the cover of the
   recommended album at the bottom left, «Слушать» at the bottom right; under the card the album and the artist */
const isPickBlock = (b) =>
  b?.view === "artistpick" ||
  /ARTIST_(RECOMMENDATIONS_PROMO|PICK)/.test(b?.type || "") ||
  /артист рекомендует/i.test(b?.title || "");
function artistPickCard(x) {
  const al = x.album || {};
  const back = x.photo || x.avatar || al.cover || "";
  const artists = (x.artists || []).length
    ? x.artists
        .map((y) => `<a data-artist="${esc(y.id || "")}" data-name="${esc(y.name)}">${esc(y.name)}</a>`)
        .join(", ")
    : esc(al.owner || "");
  return `<div class="apick"><button class="ap-card${x.top ? " top" : ""}" data-go="rplaylist:${esc(al.id)}" title="${esc(al.title || "")}"><span class="ap-bg" ${lbg(back, "l")}></span><span class="ap-cv" ${lbg(al.cover, "m")}></span><span class="ap-play" data-pick-play="${esc(al.id)}">${icon("play")}Слушать</span></button><div class="ap-tx"><b>${esc(al.title || "")}${x.explicit ? '<i class="badge-e" title="Есть ненормативная лексика">E</i>' : ""}</b><small>${artists}</small></div></div>`;
}
function artistPickBlock(b) {
  const picks = (b.picks || []).filter((x) => x.album?.id);
  if (!picks.length) return "";
  return `<section class="section apicks"><div class="sec-head"><h2>${esc(b.title || "Артист рекомендует")}</h2>${b.description ? `<span class="sec-note">${esc(b.description)}</span>` : ""}</div><div class="ap-grid">${picks.slice(0, 6).map(artistPickCard).join("")}</div></section>`;
}
// «Слушать» on a card plays the album at once (the card itself opens it)
async function playPick(id) {
  try {
    const r = await api("remote-playlist", { id });
    if (!r.tracks?.length) throw new Error("В альбоме нет доступных треков");
    playList(r.tracks, 0, { title: r.playlist?.title || "Альбом", go: "rplaylist:" + id });
  } catch (e) {
    toast(e.message, 3000);
  }
}
document.addEventListener(
  "click",
  (e) => {
    const p = e.target.closest?.("[data-pick-play]");
    if (!p) return;
    e.preventDefault();
    e.stopPropagation();
    playPick(p.dataset.pickPlay);
  },
  true,
);

/* 4.13: «Книги и подкасты» — the page of the new Yandex client (non_music): the «Книги» / «Подкасты» tabs with their
   pictures, what the account follows («Ваши») and all sections of the tab. Without the account the sections still
   come; the episodes and books play with the Yandex sound, so listening needs the account */
const bookCard = (p) => podCard({ ...p, owner: p.owner || p.kind || "" });
function booksBlock(b) {
  if (b.view === "playlist" || b.view === "chart" || b.view === "tracks") return ymBlock(b);
  const items = (b.items || [])
    .map((it) => (it.kind === "album" && it.card ? bookCard(it.card) : ymItem(it)))
    .filter(Boolean);
  return items.length ? shelfHtml(b.title || "", items.join(""), { note: b.description || "", cls: "pods" }) : "";
}
function booksTab(tabs) {
  let t = S.booksTab;
  if (!t)
    try {
      t = localStorage.getItem("wave.booksTab");
    } catch {}
  return tabs.some((x) => x.id === t) ? t : tabs[0]?.id || "";
}
async function booksView(force) {
  const route = S.route;
  S.pageTitle = { route, title: "Книги и подкасты" };
  skelLater(6);
  const [land, mine] = await Promise.allSettled([
    api("ym-landing", { id: "non_music", force: !!force }),
    S.settings.ymToken ? api("ym-nonmusic") : Promise.resolve(null),
  ]);
  if (S.route !== route) return;
  S.ymBooks = land.status === "fulfilled" ? land.value : null;
  S.ymBooksMine = mine.status === "fulfilled" ? mine.value?.liked || [] : [];
  renderBooks(land.status === "rejected" ? land.reason?.message || "нет ответа" : "");
}
function renderBooks(err = "") {
  const tabs = (S.ymBooks?.tabs || []).filter((t) => t.blocks?.length);
  const cur = booksTab(tabs);
  const tab = tabs.find((t) => t.id === cur);
  const login = !S.settings.ymToken;
  const head = `<h1 class="page">Книги и подкасты</h1>`;
  if (!tab) {
    setContent(
      head +
        `<div class="ypod">${icon("book")}<div><b>Книги и подкасты не загрузились</b><span>${esc(err || S.ymBooks?.errors?.[0] || "Яндекс Музыка не вернула разделы")}. Раздел берётся из Яндекс Музыки — проверьте интернет (из-за границы Яндекс может не отвечать без VPN)</span></div><button class="btn sm" id="bk-retry">Повторить</button></div>`,
    );
    const rb = $("#bk-retry");
    if (rb) rb.onclick = () => booksView(true);
    return;
  }
  const isBook = (p) => p.pod === "book" || /книг/i.test(p.kind || "");
  const mine = (S.ymBooksMine || []).filter((p) =>
    cur === "audiobooks" ? isBook(p) : cur === "podcasts" ? !isBook(p) : true,
  );
  const tabsHtml =
    tabs.length > 1
      ? `<div class="bk-tabs" role="tablist">${tabs.map((t) => `<button class="bk-tab${t.id === cur ? " on" : ""}" data-btab="${esc(t.id)}" role="tab" aria-selected="${t.id === cur}"><span class="bk-cv" ${bg(t.cover, "s")}>${t.cover ? "" : icon(/pod/.test(t.id) ? "mic" : "book")}</span><span class="bk-tx"><b>${esc(t.title || "Раздел")}</b>${t.subtitle ? `<small>${esc(t.subtitle)}</small>` : ""}</span></button>`).join("")}</div>`
      : "";
  setContent(
    head +
      tabsHtml +
      (mine.length
        ? shelf(cur === "podcasts" ? "Ваши подкасты" : cur === "audiobooks" ? "Ваши книги" : "Ваши", mine, {
            cards: podCard,
            cls: "pods",
          })
        : "") +
      tab.blocks.map(booksBlock).join("") +
      (login
        ? '<p class="pod-note">Чтобы слушать выпуски и книги, войдите в Яндекс Музыку (Настройки → Подключения)</p>'
        : ""),
  );
  $$("[data-btab]").forEach(
    (b) =>
      (b.onclick = () => {
        if (b.classList.contains("on")) return;
        S.booksTab = b.dataset.btab;
        try {
          localStorage.setItem("wave.booksTab", S.booksTab);
        } catch {}
        renderBooks();
      }),
  );
  lazyScan();
}
// «ymtag:<tag>|<title>» — playlists of a Yandex mix (e.g. «Осенние»)
async function ymTagView(arg) {
  const [tag, ...n] = arg.split("|");
  const title = decodeURIComponent(n.join("|") || "") || "Подборка";
  S.pageTitle = { route: S.route, title };
  skelLater(8);
  const route = S.route;
  try {
    const r = await api("ym-tag", { tag });
    if (S.route !== route) return;
    const list = r.playlists || [];
    setContent(
      `<h1 class="page">${esc(r.title || title)}</h1><p class="page-sub">Подборка Яндекс Музыки · треки играют через полные версии с SoundCloud / Audius</p>` +
        (list.length
          ? `<div class="grid">${list.map(likeCard).join("")}</div>`
          : '<div class="empty"><b>Подборка пуста</b>Яндекс Музыка не вернула плейлистов</div>'),
    );
  } catch (e) {
    if (S.route === route) setContent(`<div class="empty"><b>Подборка недоступна</b>${esc(e.message)}</div>`);
  }
}
function bindWave() {
  const p = $("#wave-play");
  if (!p) return;
  p.onclick = () => {
    if (S.wave && S.current) togglePlay();
    else startWave();
  };
  $$("[data-mood]").forEach(
    (b) =>
      (b.onclick = async () => {
        S.settings.wave = await api("wave-settings", { ...S.settings.wave, mood: b.dataset.mood });
        $$("[data-mood]").forEach((x) => x.classList.toggle("on", x === b));
        if (S.wave) startWave();
      }),
  );
  $("#wave-tune").onclick = tuneWave;
  if (!(S.wave && S.current)) setTimeout(() => waveWarmup({}), 300);
}
const WAVE_SRC = [
  ["wave", "Wave"],
  ["likes", "По моим вкусам"],
  ["yandex", "Яндекс"],
  ["spotify", "Spotify"],
];
function tuneWave() {
  const w = S.settings.wave;
  dialog(
    `<h3>Настроить Мою волну</h3><p class="muted" style="margin-bottom:10px">Настроение</p><div class="tabs" id="dm">${MOODS.map(([k, v]) => `<button data-v="${k}" class="${w.mood === k ? "on" : ""}">${v}</button>`).join("")}</div>
  <p class="muted" style="margin-bottom:10px">Характер</p><div class="tabs" id="dd">${DIV.map(([k, v]) => `<button data-v="${k}" class="${w.diversity === k ? "on" : ""}">${v}</button>`).join("")}</div>
  <p class="muted" style="margin:16px 0 10px">Источник рекомендаций</p><div class="tabs" id="dsrc">${WAVE_SRC.map(([k, v]) => `<button data-v="${k}" class="${(S.settings.waveSource || "wave") === k ? "on" : ""}">${v}</button>`).join("")}</div>
  <div class="acts"><button class="btn" data-close>Отмена</button><button class="btn acc" id="dsave">Слушать</button></div>`,
    (dlg) => {
      let mood = w.mood,
        div = w.diversity,
        src = S.settings.waveSource || "wave";
      const tabs = (sel, set) =>
        dlg.querySelectorAll(sel + " button").forEach(
          (b) =>
            (b.onclick = () => {
              set(b.dataset.v);
              dlg.querySelectorAll(sel + " button").forEach((x) => x.classList.toggle("on", x === b));
            }),
        );
      tabs("#dm", (v) => (mood = v));
      tabs("#dd", (v) => (div = v));
      tabs("#dsrc", (v) => (src = v));
      dlg.querySelector("#dsave").onclick = async () => {
        if (src !== (S.settings.waveSource || "wave")) S.settings = await api("settings", { waveSource: src });
        S.settings.wave = await api("wave-settings", { mood, diversity: div });
        S.wavePreset = "";
        S.wavePresetInfo = null;
        markPresets();
        dlg.close();
        if (S.route === "home" && !isGlass()) home();
        startWave({});
      };
    },
  );
}
const GENRES = [
  ["rap", "Рэп", ["#7c3aed", "#c026d3"]],
  ["phonk", "Фонк", ["#4c1d95", "#db2777"]],
  ["pop", "Поп", ["#ec4899", "#f97316"]],
  ["electronic", "Электроника", ["#2563eb", "#7c3aed"]],
  ["rock", "Рок", ["#991b1b", "#7c2d12"]],
  ["lofi", "Lo-Fi", ["#0f766e", "#4338ca"]],
  ["house", "Хаус", ["#9333ea", "#2563eb"]],
  ["trap", "Трэп", ["#be123c", "#6d28d9"]],
  ["metal", "Метал", ["#334155", "#0f172a"]],
  ["indie", "Инди", ["#ca8a04", "#9333ea"]],
  ["drum & bass", "Drum & Bass", ["#16a34a", "#1d4ed8"]],
  ["ambient", "Эмбиент", ["#0891b2", "#6366f1"]],
  ["jazz", "Джаз", ["#b45309", "#7c2d12"]],
  ["r&b", "R&B", ["#a21caf", "#1e1b4b"]],
  ["russian rap", "Русский рэп", ["#6d28d9", "#0f172a"]],
  ["anime", "Аниме", ["#f43f5e", "#8b5cf6"]],
];
function searchView(q) {
  q = q ? decodeURIComponent(q) : S.lastSearch;
  setContent(`<form class="bigsearch" id="sform">${icon("search")}<input id="sq" placeholder="Трек, исполнитель или ссылка на плейлист Яндекс/Spotify/SoundCloud" value="${esc(q)}" autocomplete="off" spellcheck="false"></form>
  ${stabsHtml()}<div id="sres"></div>`);
  const inp = $("#sq");
  inp.focus();
  const run = () => {
    const v = inp.value.trim();
    S.lastSearch = v;
    $("#side-search").value = v;
    doSearch(v);
  };
  const later = debounce(run, 450);
  $("#sform").onsubmit = (e) => {
    e.preventDefault();
    run();
  };
  inp.oninput = later;
  bindStabs();
  doSearch(q);
}
/* ---------- 4.8: search like in Yandex Music — Топ / Исполнители / Треки / Альбомы / Плейлисты / Клипы ---------- */
const STABS = [
  ["top", "Топ"],
  ["artists", "Исполнители"],
  ["tracks", "Треки"],
  ["albums", "Альбомы"],
  ["playlists", "Плейлисты"],
  ["clips", "Клипы"],
];
const stabsHtml = () =>
  `<div class="tabs stabs" id="stabs">${STABS.map(([k, v]) => `<button data-st="${k}" class="${(S.searchType || "top") === k ? "on" : ""}">${v}</button>`).join("")}</div>`;
function bindStabs() {
  $$("#stabs button").forEach(
    (b) =>
      (b.onclick = () => {
        S.searchType = b.dataset.st;
        $$("#stabs button").forEach((x) => x.classList.toggle("on", x === b));
        const c = S.searchCache;
        if (c && c.q === S.lastSearch && c.r) renderSearch(c.q, c.r);
        else doSearch(S.lastSearch);
      }),
  );
}
const sArtistRow = (a) =>
  `<button class="s-arow" data-artist="${esc(a.id || "")}" data-name="${esc(a.name)}"><span class="s-av" ${lbg(a.avatar, "s")}>${a.avatar ? "" : esc((a.name || "?")[0])}</span><span class="s-am"><b>${esc(a.name)}</b><small>Исполнитель${a.genre ? " · " + esc(a.genre) : ""}</small></span>${icon("right")}</button>`;
function renderSearch(q, r) {
  const box = $("#sres");
  if (!box) return;
  const tab = S.searchType || "top";
  const miss = r.misspell
    ? `<p class="s-miss">Возможно, вы искали <a data-sq="${esc(r.misspell)}">${esc(r.misspell)}</a></p>`
    : "";
  const tracks = r.tracks || [],
    artists = r.artists || [],
    albums = r.albums || [],
    pls = r.playlists || [],
    clips = r.videos || [];
  let html = "";
  if (tab === "top") {
    // a 2-column list: the best artist first, then tracks, a second matching artist in between (Yandex style)
    const lid = reg(tracks);
    const best = r.best?.kind === "artist" ? artists.find((a) => a.id === r.best.id) : null;
    const rows = [];
    if (best) rows.push(sArtistRow(best));
    const more = artists.filter((a) => a !== best && nKey(a.name) === nKey(q)).slice(0, 1);
    tracks.slice(0, 10 - rows.length - more.length).forEach((t, i) => {
      if (i === 3 && more.length) rows.push(sArtistRow(more[0]));
      rows.push(trackRow(t, lid, i));
    });
    if (more.length && tracks.length <= 3) rows.push(sArtistRow(more[0]));
    if (rows.length) html += `<div class="s-top tracks">${rows.join("")}</div>`;
    html += shelf("Исполнители", artists.slice(0, 16), { cards: artistCard });
    if (tracks.length > 10)
      html += `<section class="section"><div class="sec-head"><h2><button data-st-go="tracks">Треки<i class="arr">›</i></button></h2></div>${tracksHtml(tracks.slice(10, 20), { cols: "cols" })}</section>`;
    html +=
      shelf("Альбомы", albums, { cards: albCard }) +
      shelf("Подкасты и книги", r.podcasts || [], { cards: podCard }) +
      shelf("Плейлисты", pls, { cards: plCard }) +
      shelf("Клипы", clips, { cards: clipCard });
  } else if (tab === "artists")
    html = artists.length ? `<div class="grid">${artists.map(artistCard).join("")}</div>` : "";
  else if (tab === "tracks") html = tracks.length ? tracksHtml(tracks, { cols: "cols" }) : "";
  else if (tab === "albums") html = albums.length ? `<div class="grid">${albums.map(albCard).join("")}</div>` : "";
  else if (tab === "playlists") html = pls.length ? `<div class="grid">${pls.map(plCard).join("")}</div>` : "";
  else if (tab === "clips") html = clips.length ? `<div class="grid clips">${clips.map(clipCard).join("")}</div>` : "";
  if (!html)
    html = `<div class="empty"><b>Ничего не нашлось</b>${tab === "top" ? "Попробуйте изменить запрос" : "В этом разделе пусто — загляните во вкладку «Топ»"}</div>`;
  if (r.errors?.length) html += `<p class="err">${esc(r.errors.join("; "))}</p>`;
  box.innerHTML = miss + html;
  box.querySelectorAll("[data-sq]").forEach(
    (a) =>
      (a.onclick = () => {
        const inp = $("#sq");
        if (inp) inp.value = a.dataset.sq;
        S.lastSearch = a.dataset.sq;
        doSearch(a.dataset.sq);
      }),
  );
  box
    .querySelectorAll("[data-st-go]")
    .forEach((b) => (b.onclick = () => $(`#stabs [data-st="${b.dataset.stGo}"]`)?.click()));
}
let searchSeq = 0;
async function doSearch(q) {
  const box = $("#sres");
  if (!box) return;
  if (!q) {
    box.innerHTML = `<div class="sec-head"><h2>Жанры и настроения</h2></div><div class="genres">${GENRES.map(([k, v, [a, b]]) => `<button class="genre" style="background:linear-gradient(135deg,${a},${b})" data-go="genre:${esc(encodeURIComponent(k))}">${esc(v)}</button>`).join("")}</div>`;
    return;
  }
  const my = ++searchSeq;
  // 4.8: coming back to the search page shows the same results at once (no new request for 10 minutes)
  const c = S.searchCache;
  if (c && c.q === q && Date.now() - c.at < 600e3) return renderSearch(q, c.r);
  box.innerHTML = skel(6);
  try {
    const r = await api("search", { q });
    if (my !== searchSeq || !box.isConnected) return;
    if (r.resolved) {
      box.innerHTML =
        `${r.note ? `<p class="muted" style="margin-bottom:12px">${esc(r.note)}</p>` : ""}<div class="sec-head"><h2>${esc(r.title || "По ссылке")}</h2><button class="btn acc sm" id="imp">${icon("plus")}Сохранить как плейлист</button></div>` +
        tracksHtml(r.tracks, { num: true });
      $("#imp").onclick = () => importUrl(q);
      return;
    }
    S.searchCache = { q, r, at: Date.now() };
    renderSearch(q, r);
  } catch (e) {
    if (my === searchSeq) box.innerHTML = `<div class="empty"><b>Ошибка поиска</b>${esc(e.message)}</div>`;
  }
}
async function genreView(tag) {
  tag = decodeURIComponent(tag);
  const g = GENRES.find((x) => x[0] === tag);
  S.pageTitle = { route: S.route, title: g ? g[1] : catTitle(tag) || tag };
  const grad = `background:linear-gradient(135deg,${g ? g[2][0] : "#7c3aed"},${g ? g[2][1] : "#c026d3"})`;
  setContent(
    listHero({ kind: "Жанр", title: g ? g[1] : tag, meta: "SoundCloud", actions: playActs("gp"), coverStyle: grad }) +
      `<div id="gtools"></div><div id="lt">${skel(8)}</div>`,
  );
  try {
    const list = await api("genre", { genre: tag });
    if (!$("#lt")) return;
    $("#gtools").outerHTML = listTools(list);
    $("#lt").innerHTML = tracksHtml(list, { num: true });
    bindPlay("gp", list);
    filterable(list, "#lt");
  } catch (e) {
    if ($("#lt")) $("#lt").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}
function collection() {
  const artists = new Map();
  for (const t of S.likes)
    for (const a of t.artists || [])
      if (a.id && !artists.has(a.id)) artists.set(a.id, { id: a.id, name: a.name, avatar: t.cover, followers: 0 });
  setContent(`<h1 class="page">Коллекция</h1><div class="ctiles">
   <button class="ctile likes" data-go="likes" ${S.likesCover ? bg(S.likesCover) : ""}>${icon("heart", "big")}<b>Мне нравится</b><small>${plural(S.likes.length, "трек", "трека", "треков")}</small></button>
   <button class="ctile" data-go="history">${icon("clock", "big")}<b>История</b><small>${plural(S.history.length, "трек", "трека", "треков")}</small></button>
   <button class="ctile" id="c-new">${icon("plus", "big")}<b>Новый плейлист</b><small>или импорт из Яндекс Музыки / Spotify</small></button></div>
   <div class="tabs" id="ctabs"><button class="on" data-t="pl">Плейлисты</button><button data-t="mx">Микс</button><button data-t="ar">Исполнители</button><button data-t="tr">Треки</button>${S.spotify.connected ? '<button data-t="sp">Spotify</button>' : ""}</div><div id="cbody"></div>`);
  $("#c-new").onclick = () => newPlaylistDialog();
  const tabs = {
    pl: () =>
      S.playlists.length
        ? `<div class="grid">${S.playlists.map(plCard).join("")}</div>`
        : `<div class="empty"><b>Плейлистов пока нет</b>Создайте свой или импортируйте плейлист/лайки SoundCloud по ссылке</div>`,
    ar: () =>
      artists.size
        ? `<div class="grid">${[...artists.values()].map(artistCard).join("")}</div>`
        : '<div class="empty"><b>Нет исполнителей</b>Лайкайте треки — исполнители появятся здесь</div>',
    tr: () => tracksHtml(S.likes, { cols: "cols" }),
    mx: () => mixCardsHtml(),
    sp: async () => {
      const r = await api("spotify-library");
      return (
        shelf("Плейлисты Spotify", r.playlists, { cards: plCard }) +
        `<section class="section"><div class="sec-head"><h2>Любимые треки Spotify</h2><button class="btn sm" id="spimp">Перенести в «Мне нравится»</button></div>${tracksHtml(r.liked, { cols: "cols" })}</section>`
      );
    },
  };
  const show = async (t) => {
    $("#cbody").innerHTML = skel(3);
    try {
      const html = await tabs[t]();
      if (!$("#cbody")) return;
      $("#cbody").innerHTML = html;
      const b = $("#spimp");
      if (b)
        b.onclick = async () => {
          const r = await api("spotify-import-likes");
          setLikes(r.likes);
          toast("Перенесено: " + r.added);
        };
    } catch (e) {
      if ($("#cbody")) $("#cbody").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
    }
  };
  $$("#ctabs button").forEach(
    (b) =>
      (b.onclick = () => {
        $$("#ctabs button").forEach((x) => x.classList.toggle("on", x === b));
        show(b.dataset.t);
      }),
  );
  show("pl");
}
/* ================= 4.3: «Поиск», «Коллекция», «Концерты» in the Yandex Music layout (new interface) ================= */
const fmtNum = (n) => {
  n = Number(n) || 0;
  if (n < 1000) return String(n);
  if (n < 1e6)
    return (
      (n / 1000)
        .toFixed(n < 1e4 ? 1 : 0)
        .replace(".0", "")
        .replace(".", ",") + "K"
    );
  return (n / 1e6).toFixed(1).replace(".0", "").replace(".", ",") + "M";
};
const SEASONS = [
  ["winter", "Зимняя", ["#5b8cff", "#1d2b6b"]],
  ["spring", "Весенняя", ["#38c98b", "#1f5f4a"]],
  ["summer", "Летняя", ["#ffb347", "#d9480f"]],
  ["autumn", "Осенняя", ["#f08a24", "#7c2d12"]],
];
const season = () => SEASONS[[0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 0][new Date().getMonth()]];
const CATS = {
  moods: {
    title: "Настроения",
    grad: ["#ff5fa2", "#6d28d9"],
    items: [
      ["happy", "Весёлое", ["#f59e0b", "#ef4444"]],
      ["sad", "Грустное", ["#6366f1", "#1e1b4b"]],
      ["chill", "Спокойное", ["#14b8a6", "#1e3a8a"]],
      ["energetic", "Энергичное", ["#ef4444", "#7c2d12"]],
      ["romantic", "Романтичное", ["#ec4899", "#7e22ce"]],
      ["dreamy", "Мечтательное", ["#a78bfa", "#312e81"]],
      ["dark", "Мрачное", ["#334155", "#020617"]],
      ["motivation", "Мотивация", ["#22c55e", "#14532d"]],
    ],
  },
  activities: {
    title: "Занятия",
    grad: ["#22d3ee", "#1d4ed8"],
    items: [
      ["workout", "Тренировка", ["#ef4444", "#9a3412"]],
      ["study", "Учёба", ["#0ea5e9", "#1e3a8a"]],
      ["focus", "Работа", ["#64748b", "#0f172a"]],
      ["sleep", "Сон", ["#4338ca", "#020617"]],
      ["party", "Вечеринка", ["#d946ef", "#6d28d9"]],
      ["driving", "В дороге", ["#f97316", "#7c2d12"]],
      ["gaming", "Игры", ["#22c55e", "#1e3a8a"]],
      ["relax", "Отдых", ["#2dd4bf", "#134e4a"]],
    ],
  },
  genres: { title: "Жанры", grad: ["#a855f7", "#be123c"], items: null },
  eras: {
    title: "Эпохи",
    grad: ["#facc15", "#b45309"],
    items: [
      ["70s", "70-е", ["#f59e0b", "#78350f"]],
      ["80s", "80-е", ["#ec4899", "#4c1d95"]],
      ["90s", "90-е", ["#06b6d4", "#312e81"]],
      ["2000s", "2000-е", ["#84cc16", "#14532d"]],
      ["2010s", "2010-е", ["#f43f5e", "#1e1b4b"]],
      ["2020s", "2020-е", ["#8b5cf6", "#0f172a"]],
    ],
  },
};
const catItems = (k) => (k === "genres" ? GENRES : CATS[k]?.items || []);
const catTitle = (tag) => {
  for (const k of Object.keys(CATS)) {
    const it = catItems(k).find((x) => x[0] === tag);
    if (it) return it[1];
  }
  const se = SEASONS.find((x) => x[0] === tag);
  return se ? se[1] + " музыка" : "";
};
const SEARCH_MOODS = [
  ["energetic", "Хочу энергии"],
  ["sad", "Грустно"],
  ["chill", "Спокойно"],
  ["happy", "Весело"],
  ["focus", "Для работы"],
  ["workout", "Для тренировки"],
  ["party", "Вечеринка"],
  ["romantic", "Романтика"],
  ["phonk", "Фонк"],
  ["russian rap", "Русский рэп"],
];
const tile = (go, title, [a, b], big = false) =>
  `<button class="ytile${big ? " big" : ""}" data-go="${esc(go)}" style="background:linear-gradient(135deg,${a},${b})"><b>${esc(title)}</b><i></i></button>`;
const likeCard = (p) =>
  `<button class="card lcard" data-go="rplaylist:${esc(p.id)}"><div class="cv" ${lbg(p.cover)}>${p.cover ? "" : `<div class="cv-ph">${icon("note")}</div>`}<div class="hov"><span class="pbtn">${icon("right")}</span></div></div><b>${esc(p.title)}</b><small>${esc(p.owner || "")}</small>${p.likes ? `<span class="lc-likes">${icon("heart")}${fmtNum(p.likes)}</span>` : ""}</button>`;
const SH_KEY = "wave.searchHistory";
const searchHist = () => {
  try {
    const a = JSON.parse(localStorage.getItem(SH_KEY) || "[]");
    return Array.isArray(a) ? a.filter((x) => typeof x === "string").slice(0, 20) : [];
  } catch {
    return [];
  }
};
const pushSearch = (q) => {
  q = String(q || "").trim();
  if (!q || /^https?:\/\//i.test(q)) return;
  try {
    localStorage.setItem(
      SH_KEY,
      JSON.stringify([q, ...searchHist().filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 20)),
    );
  } catch {}
};
async function landingData() {
  if (!S.landingJob)
    S.landingJob = api("search-landing").catch((e) => {
      S.landingJob = null;
      throw e;
    });
  return S.landingJob;
}
function gSearchView(q) {
  q = q ? decodeURIComponent(q) : S.lastSearch || "";
  S.lastSearch = q;
  S.searchTab = S.searchTab || "pop";
  setContent(`<h1 class="page">Поиск</h1><form class="ysearch" id="sform">${icon("search")}<input id="sq" placeholder="Что вы чувствуете или ищете?" value="${esc(q)}" autocomplete="off" spellcheck="false"><button type="button" class="ys-x" id="sx" title="Очистить"${q ? "" : " hidden"}>${icon("close")}</button></form>
  <div class="gchips ymoods">${SEARCH_MOODS.map(([k, v]) => `<button class="gchip" data-go="genre:${esc(encodeURIComponent(k))}">${esc(v)}</button>`).join("")}</div>
  <div id="sland"${q ? " hidden" : ""}><div class="ytabs" id="ytabs"><button data-t="pop" class="${S.searchTab === "pop" ? "on" : ""}">Популярное</button><button data-t="hist" class="${S.searchTab === "hist" ? "on" : ""}">История</button></div><div id="ybody"></div></div>
  <div id="sresw"${q ? "" : " hidden"}>${stabsHtml()}<div id="sres"></div></div>`);
  const inp = $("#sq");
  inp.focus();
  const mode = (v) => {
    $("#sland").hidden = !!v;
    $("#sresw").hidden = !v;
    $("#sx").hidden = !v;
  };
  const run = (push) => {
    const v = inp.value.trim();
    S.lastSearch = v;
    mode(v);
    if (push) pushSearch(v);
    if (v) doSearch(v);
    else renderLanding();
  };
  const later = debounce(() => run(false), 450);
  $("#sform").onsubmit = (e) => {
    e.preventDefault();
    run(true);
  };
  inp.oninput = () => {
    mode(inp.value.trim());
    later();
  };
  $("#sx").onclick = () => {
    inp.value = "";
    run(false);
    inp.focus();
  };
  bindStabs();
  $$("#ytabs button").forEach(
    (b) =>
      (b.onclick = () => {
        S.searchTab = b.dataset.t;
        $$("#ytabs button").forEach((x) => x.classList.toggle("on", x === b));
        renderLanding();
      }),
  );
  if (q) doSearch(q);
  else renderLanding();
}
async function renderLanding() {
  const box = $("#ybody");
  if (!box) return;
  if (S.searchTab === "hist") {
    const h = searchHist();
    const recent = S.history.slice(0, 12);
    const lid = reg(recent);
    box.innerHTML =
      (h.length
        ? `<section class="section"><div class="sec-head"><h2>Вы искали</h2><button class="btn sm ghost" id="shclear">Очистить</button></div><div class="gchips yhist">${h.map((x) => `<button class="gchip" data-q="${esc(x)}">${icon("clock")}${esc(x)}</button>`).join("")}</div></section>`
        : "") +
        (recent.length
          ? `<section class="section"><div class="sec-head"><h2><button data-go="history">Вы недавно слушали<i class="arr">›</i></button></h2></div><div class="tracks cols">${recent.map((t, i) => trackRow(t, lid, i)).join("")}</div></section>`
          : "") ||
      '<div class="empty"><b>История пуста</b>Здесь появятся ваши запросы и недавно прослушанные треки</div>';
    $$("[data-q]").forEach(
      (b) =>
        (b.onclick = () => {
          $("#sq").value = b.dataset.q;
          $("#sform").requestSubmit();
        }),
    );
    if ($("#shclear"))
      $("#shclear").onclick = () => {
        localStorage.removeItem(SH_KEY);
        renderLanding();
      };
    return;
  }
  const se = season();
  const tiles =
    `<section class="section"><div class="sec-head"><h2>Подборки музыки</h2></div><div class="ytiles">` +
    tile("genre:" + se[0], se[1], se[2], true) +
    Object.entries(CATS)
      .map(([k, c]) => tile("cat:" + k, c.title, c.grad))
      .join("") +
    `</div></section>`;
  box.innerHTML = tiles + `<div id="yrest">${'<div class="section">' + skel(4) + "</div>"}</div>`;
  const route = S.route;
  try {
    // 4.6: blocks of the Yandex «Поиск» page (mixes, new releases… when available) are added to ours
    const [d, ys] = await Promise.all([landingData(), api("ym-landing", { id: "Search" }).catch(() => null)]);
    if (S.route !== route || !$("#yrest")) return;
    S.landing = d;
    const extra = ymTab(ys, "Search")
      .filter((b) => b.view !== "chart" && !/HISTORY/.test(b.type || "") && !isPickBlock(b))
      .filter((b) => !/артист рекомендует|могли пропустить/i.test(b.title || ""))
      .map(ymBlock)
      .join("");
    const ym = d.source?.chart === "yandex";
    // 4.7: no «Артист рекомендует» and «Вы могли пропустить» on the search page
    const chartLid = reg(d.chart);
    const half = d.chart.slice(0, 20);
    $("#yrest").innerHTML =
      (d.playlists?.length
        ? `<section class="section"><div class="sec-head"><h2>Больше новой музыки</h2><span class="sec-note">${d.source?.playlists === "yandex" ? "Новые плейлисты · Яндекс Музыка" : "Плейлисты SoundCloud"}</span></div><div class="shelf" id="ypl">${d.playlists.map(likeCard).join("")}</div></section>`
        : "") +
      extra +
      (half.length
        ? `<section class="section"><div class="sec-head"><h2><button data-go="chart">Чарт<i class="arr">›</i></button></h2><span class="sec-note">${ym ? "Яндекс Музыка · обновляется при каждом запуске" : "Яндекс Музыка недоступна — тренды SoundCloud"}</span></div><div class="tracks cols ychart">${half.map((t, i) => trackRow(t, chartLid, i, { num: true })).join("")}</div></section>`
        : "") +
      (d.errors?.length && !ym ? `<p class="muted ynote">Яндекс Музыка: ${esc(d.errors[0])}</p>` : "");
    lazyScan();
  } catch (e) {
    if ($("#yrest"))
      $("#yrest").innerHTML = `<div class="empty"><b>Не удалось загрузить подборки</b>${esc(e.message)}</div>`;
  }
}
function catView(k) {
  const c = CATS[k];
  if (!c) return go("search", { push: false });
  S.pageTitle = { route: S.route, title: c.title };
  setContent(
    `<h1 class="page">${esc(c.title)}</h1><p class="page-sub">Музыка с SoundCloud по тегам — полные треки</p><div class="ytiles grid">${catItems(
      k,
    )
      .map(([tag, name, g]) => tile("genre:" + encodeURIComponent(tag), name, g || c.grad))
      .join("")}</div>`,
  );
}
async function chartView() {
  skelLater(10);
  try {
    const d = await landingData();
    if (S.route !== "chart") return;
    const ym = d.source?.chart === "yandex";
    S.pageTitle = { route: "chart", title: "Чарт" };
    setContent(
      listHero({
        kind: ym ? "Чарт Яндекс Музыки" : "Тренды SoundCloud",
        title: "Чарт",
        meta: `${plural(d.chart.length, "трек", "трека", "треков")} · ${ym ? "играем полные версии с SoundCloud/Audius" : "Яндекс Музыка недоступна"}`,
        actions: playActs("chp"),
        coverStyle: "background:linear-gradient(135deg,#ffd84a,#ff7a18 60%,#7c2d12)",
        iconName: "burst",
      }) + `<div id="lt">${tracksHtml(d.chart, { num: true })}</div>`,
    );
    bindPlay("chp", d.chart);
  } catch (e) {
    setContent(`<div class="empty"><b>Чарт недоступен</b>${esc(e.message)}</div>`);
  }
}

/* ---------- «Коллекция» ---------- */
// 4.6: «Любимые исполнители» are ranked by listening time (counted by Wave) plus likes and history:
// a like ≈ 1.5 min of listening, a history entry ≈ 30 s
const artKey = (n) =>
  String(n || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
function favArtists(limit = 20) {
  const m = new Map();
  for (const a of S.artistTime || []) {
    const key = artKey(a.name);
    if (key && a.sec > 0) m.set(key, { id: a.id || null, name: a.name, cover: a.cover || null, n: 0, sec: a.sec });
  }
  const add = (t, w) => {
    const list = t.artists?.length ? t.artists : [{ id: null, name: t.artist }];
    for (const a of list.slice(0, 2)) {
      const name = (a.name || "").trim();
      const key = artKey(name);
      if (!key) continue;
      const x = m.get(key) || { id: a.id, name, cover: null, n: 0, sec: 0 };
      x.n += w;
      if (!x.id && a.id) x.id = a.id;
      if (!x.cover && t.cover) x.cover = t.cover;
      m.set(key, x);
    }
  };
  S.likes.forEach((t) => add(t, 3));
  S.history.slice(0, 120).forEach((t) => add(t, 1));
  const score = (a) => a.sec + a.n * 30;
  return [...m.values()]
    .filter((a) => a.n >= 2 || a.sec >= 120 || S.likes.length < 6)
    .sort((a, b) => score(b) - score(a))
    .slice(0, limit);
}
// 4.9: the pictures of favourite artists are the avatars of their artist cards (not track covers), loaded in one
// batch and cached by the main process for a week
const AV = new Map();
const avK = (a) => (a.id || "") + "|" + artKey(a.name);
async function loadAvatars(list) {
  const need = list.filter((a) => !AV.has(avK(a))).slice(0, 60);
  if (need.length) {
    const r = await api("artist-avatars", { list: need.map((a) => ({ id: a.id || "", name: a.name })) }).catch(
      () => null,
    );
    if (!Array.isArray(r)) return;
    need.forEach((a, i) => AV.set(avK(a), r[i] || null));
  }
  $$(".ycirc[data-avk]").forEach((b) => {
    const u = AV.get(b.dataset.avk);
    const av = b.querySelector(".yc-av");
    if (!u || !av || av.dataset.av === u) return;
    av.dataset.av = u;
    av.removeAttribute("data-bg");
    av.style.backgroundImage = `url("${thumb(u, "s").replace(/"/g, "%22")}")`;
    av.textContent = "";
  });
}
const listenLbl = (sec) =>
  sec >= 3600
    ? Math.floor(sec / 3600) + " ч" + (sec % 3600 >= 60 ? " " + Math.floor((sec % 3600) / 60) + " мин" : "")
    : Math.max(1, Math.round(sec / 60)) + " мин";
const artCircle = (a) => {
  const av = AV.get(avK(a));
  return `<button class="ycirc" data-avk="${esc(avK(a))}" ${a.id ? `data-artist="${esc(a.id)}" data-name="${esc(a.name)}"` : `data-artist="" data-name="${esc(a.name)}"`}${a.sec >= 60 ? ` title="Слушали ${listenLbl(a.sec)}"` : ""}><span class="yc-av" ${av ? `data-av="${esc(av)}" ` + bg(av, "s") : ""}>${av ? "" : esc(a.name[0] || "?")}</span><b>${esc(a.name)}</b>${a.sec >= 60 ? `<small>${listenLbl(a.sec)}</small>` : ""}</button>`;
};
/* 4.13: «Любимые исполнители» of the collection like Yandex Music — five big circles: the place (1 — a crown) and the
   move since the last time (up / down / the same / NEW), the name and the listening time («6 часов», «3,5 часа»).
   With the Yandex account — its top of the month; without it — the own favourites by listening time, the moves
   against the own list of a week ago */
function ytime(sec) {
  const min = (Number(sec) || 0) / 60;
  const pr = new Intl.PluralRules("ru-RU");
  const word = (n, f) => f[pr.select(n)] || f.other;
  if (min <= 45) {
    const m = Math.max(1, Math.round(min));
    return m + " " + word(m, { one: "минута", few: "минуты", many: "минут", other: "минут" });
  }
  const h = Math.round((min / 60) * 2) / 2;
  return String(h).replace(".", ",") + " " + word(h, { one: "час", few: "часа", many: "часов", other: "часа" });
}
const TOP_N = 5;
// the own list: the moves against the list of the previous week (kept in localStorage, renewed weekly)
function topMoves(keys, now = Date.now()) {
  let snap = null;
  try {
    snap = JSON.parse(localStorage.getItem("wave.topSnap") || "null");
  } catch {}
  if (!snap || !Array.isArray(snap.cur)) snap = { at: now, prev: null, cur: keys };
  else if (now - snap.at > 7 * 864e5) snap = { at: now, prev: snap.cur, cur: keys };
  else snap.cur = keys;
  try {
    localStorage.setItem("wave.topSnap", JSON.stringify(snap));
  } catch {}
  return keys.map((k, i) => {
    if (!snap.prev) return "same";
    const j = snap.prev.indexOf(k);
    return j < 0 ? "new" : j > i ? "up" : j < i ? "down" : "same";
  });
}
function localTop() {
  const list = favArtists(TOP_N);
  const moves = topMoves(list.map((a) => artKey(a.name)));
  return list.map((a, i) => ({ ...a, pos: i + 1, progress: moves[i] }));
}
const TOP_ICON = { up: "tup", down: "tdown", same: "tsame", new: "tnew" };
function topCircle(a) {
  const av = a.avatar || AV.get(avK(a));
  const pos = a.pos
    ? `<span class="yt-pos"><b>${a.pos}</b>${a.pos === 1 ? icon("crown", "yt-crown") : a.progress ? icon(TOP_ICON[a.progress], "yt-mv " + a.progress) : ""}</span>`
    : "";
  return `<button class="ycirc ytop-i" data-avk="${esc(avK(a))}" data-artist="${esc(a.id || "")}" data-name="${esc(a.name)}"><span class="yc-av" ${av ? `data-av="${esc(av)}" ` + bg(av, "m") : ""}>${av ? "" : esc(a.name[0] || "?")}</span>${pos}<b>${esc(a.name)}</b><small>${a.sec >= 30 ? ytime(a.sec) : "&nbsp;"}</small></button>`;
}
function topArtistsHtml(list) {
  return list.slice(0, TOP_N).map(topCircle).join("");
}
// the Yandex top replaces the own list when it comes (the own one is shown at once)
async function loadTopArtists() {
  if (!S.settings.ymToken) return;
  const r = await api("ym-top-artists").catch(() => null);
  const box = $("#fav-arts");
  if (!box || !Array.isArray(r) || !r.length) return;
  S.ymTop = r;
  box.innerHTML = topArtistsHtml(r);
  box.classList.add("ym");
  $("#fav-sec")?.removeAttribute("hidden");
}
// 4.9: «Любимые исполнители» — the whole list on its own page
function favArtistsView() {
  const arts = favArtists(300);
  S.pageTitle = { route: S.route, title: "Любимые исполнители" };
  setContent(
    `<h1 class="page">Любимые исполнители</h1><p class="page-sub">По лайкам, истории и времени прослушивания · ${plural(arts.length, "исполнитель", "исполнителя", "исполнителей")}</p>${arts.length ? `<div class="fav-grid">${arts.map(artCircle).join("")}</div>` : '<div class="empty"><b>Пока пусто</b>Лайкайте треки и слушайте музыку — здесь появятся ваши исполнители</div>'}`,
  );
  loadAvatars(arts);
}
const newPlCard = () =>
  `<button class="card newpl" id="c-new"><div class="cv"><span>${icon("plus")}</span></div><b>Новый плейлист</b><small>или импорт по ссылке</small></button>`;
// 4.10: «Подкасты и книги» — what the Yandex account follows / saved + popular podcasts and audiobooks
const podCard = (p) =>
  `<button class="card pod" data-go="rplaylist:${esc(p.id)}"><div class="cv" ${lbg(p.cover)}>${p.cover ? "" : `<div class="cv-ph">${icon(p.pod === "book" ? "book" : "mic")}</div>`}<div class="hov"><span class="pbtn">${icon("right")}</span></div></div><b>${esc(p.title)}</b><small>${esc(p.owner || p.kind || "")}</small></button>`;
async function podShelf(force) {
  const box = $("#pod-box");
  if (!box) return;
  let d;
  try {
    d = await api("ym-nonmusic", { force: !!force });
  } catch (e) {
    d = { liked: [], podcasts: [], books: [], errors: [e.message] };
  }
  if (!box.isConnected) return;
  const tabs = [
    ["liked", "Ваши", d.liked || []],
    ["podcasts", "Подкасты", d.podcasts || []],
    ["books", "Книги", d.books || []],
  ].filter((x) => x[2].length);
  const login = !S.settings.ymToken;
  if (!tabs.length) {
    box.innerHTML = `<div class="ypod">${icon("book")}<div><b>${login ? "Войдите в Яндекс Музыку" : "Пока пусто"}</b><span>${login ? "Подкасты и аудиокниги в Wave берутся из Яндекс Музыки и играют её звуком: здесь появятся те, на которые вы подписаны, и популярные" : d.errors?.length ? esc(d.errors[0]) : "Подпишитесь на подкаст или добавьте книгу в Яндекс Музыке — они появятся здесь"}</span></div>${login ? '<button class="btn sm acc" id="pod-login">Войти через Яндекс</button>' : '<button class="btn sm" id="pod-retry">Обновить</button>'}</div>`;
    const lb = $("#pod-login");
    if (lb)
      lb.onclick = () => {
        try {
          localStorage.setItem("wave.setTab", "acc");
        } catch {}
        go("settings");
      };
    const rb = $("#pod-retry");
    if (rb) rb.onclick = () => ((box.innerHTML = skel(2)), podShelf(true));
    return;
  }
  if (!tabs.some((t) => t[0] === S.podTab)) S.podTab = tabs[0][0];
  const paint = () => {
    const list = tabs.find((t) => t[0] === S.podTab)[2];
    box.innerHTML = `<div class="ytabs sm" id="cpod">${tabs.map(([k, v]) => `<button data-t="${k}" class="${S.podTab === k ? "on" : ""}">${v}</button>`).join("")}</div><div class="shelf pods">${list.map(podCard).join("")}</div>${login ? '<p class="pod-note">Чтобы слушать выпуски, войдите в Яндекс Музыку (Настройки → Подключения)</p>' : ""}`;
    box.querySelectorAll("#cpod [data-t]").forEach(
      (b) =>
        (b.onclick = () => {
          S.podTab = b.dataset.t;
          paint();
        }),
    );
    lazyScan();
  };
  paint();
}
function gCollection() {
  if (!S.settings.ymToken) S.ymTop = null;
  const lid = reg(S.likes);
  const prev = S.likes.slice(0, 8);
  const arts = favArtists();
  const mine = S.playlists.filter((p) => !p.source && p.kind !== "album");
  const liked = S.playlists.filter((p) => p.source && p.kind !== "album");
  const albums = S.playlists.filter((p) => p.kind === "album");
  S.collTab = S.collTab === "mix" ? "mine" : S.collTab || "mine";
  S.albTab = S.albTab || "al";
  const lc = S.likesCover;
  setContent(`<h1 class="page">Коллекция</h1><p class="page-sub">Всё, что вы любите, — в одном месте</p>
  <section class="section"><div class="sec-head"><h2><button data-go="likes">Мне нравится<i class="arr">›</i></button></h2><span class="sec-note">${plural(S.likes.length, "трек", "трека", "треков")}</span></div>
    ${
      S.likes.length
        ? `<div class="ylikes"><button class="ylk-cover likes" data-go="likes" ${lc ? bg(lc) : ""}>${lc ? "" : icon("heart")}<span><b>Мне нравится</b><small>${plural(S.likes.length, "трек", "трека", "треков")}</small></span></button><div class="tracks cols ylk-list">${prev.map((t, i) => trackRow(t, lid, i)).join("")}</div></div>`
        : '<div class="empty"><b>Здесь будут любимые треки</b>Нажмите ♡ у трека — он появится в «Мне нравится»</div>'
    }</section>
  ${arts.length || S.settings.ymToken ? `<section class="section" id="fav-sec"${arts.length || S.ymTop?.length ? "" : " hidden"}><div class="sec-head"><h2><button data-go="favartists">Любимые исполнители<i class="arr">›</i></button></h2>${arts.length ? `<span class="sec-note">${plural(favArtists(500).length, "исполнитель", "исполнителя", "исполнителей")}</span>` : ""}</div><div class="ytop${S.ymTop?.length ? " ym" : ""}" id="fav-arts">${topArtistsHtml(S.ymTop?.length ? S.ymTop : localTop())}</div></section>` : ""}
  <section class="section"><div class="sec-head"><h2>Мои плейлисты<i class="arr">›</i></h2></div><div class="ytabs sm" id="cpt"><button data-t="mine" class="${S.collTab === "mine" ? "on" : ""}">Вы собрали</button><button data-t="liked" class="${S.collTab === "liked" ? "on" : ""}">Вам понравилось</button></div><div class="grid" id="cpl"></div></section>
  <section class="section"><div class="sec-head"><h2>Любимые альбомы<i class="arr">›</i></h2></div><div class="ytabs sm" id="cat"><button data-t="al" class="${S.albTab === "al" ? "on" : ""}">Альбомы</button><button data-t="up" class="${S.albTab === "up" ? "on" : ""}">Будущие релизы</button></div><div id="cal"></div></section>
  ${S.history.length ? shelf("Вы недавно слушали", S.history.slice(0, 18), { go: "history" }) : ""}
  <section class="section"><div class="sec-head"><h2>Подкасты и книги</h2><span class="sec-note">из Яндекс Музыки</span></div><div id="pod-box">${skel(2)}</div></section>
  ${S.spotify?.connected ? `<section class="section"><div class="sec-head"><h2>Spotify</h2><button class="btn sm" id="sp-load">Показать библиотеку Spotify</button></div><div id="spbox"></div></section>` : ""}`);
  if (arts.length && !S.ymTop?.length) loadAvatars(arts.slice(0, TOP_N));
  loadTopArtists();
  podShelf();
  const plTab = () => {
    // 4.14: «Микс» — the own playlists with their transitions
    $("#cpl").className = S.collTab === "mix" ? "mx-tab" : "grid";
    if (S.collTab === "mix") {
      $("#cpl").innerHTML = mixCardsHtml();
      return lazyScan();
    }
    const list = S.collTab === "mine" ? mine : liked;
    $("#cpl").innerHTML =
      (S.collTab === "mine" ? newPlCard() : "") +
      list.map(plCard).join("") +
      (S.collTab === "liked" && !list.length
        ? '<div class="empty wide"><b>Пока пусто</b>Импортированные по ссылке и сохранённые плейлисты (кнопка «В коллекцию») появятся здесь</div>'
        : "");
    const nb = $("#c-new");
    if (nb) nb.onclick = () => newPlaylistDialog();
    lazyScan();
  };
  const albTab = async () => {
    const box = $("#cal");
    if (S.albTab === "al") {
      box.innerHTML = albums.length
        ? `<div class="grid">${albums.map(plCard).join("")}</div>`
        : '<div class="empty"><b>Нет сохранённых альбомов</b>Откройте любой альбом (из поиска, страницы артиста или «Для вас») и нажмите «В коллекцию»</div>';
      return lazyScan();
    }
    box.innerHTML = skel(2);
    try {
      const d = await landingData();
      const names = new Set(arts.map((a) => a.name.toLowerCase()));
      const mineRel = (d.releases || []).filter((r) =>
        String(r.owner || "")
          .toLowerCase()
          .split(/,\s*/)
          .some((n) => names.has(n)),
      );
      if (!$("#cal")) return;
      box.innerHTML = mineRel.length
        ? `<div class="shelf">${mineRel.map(likeCard).join("")}</div>`
        : '<div class="empty"><b>Новых релизов любимых исполнителей пока нет</b>Свежие альбомы и синглы ваших артистов появятся здесь</div>';
      lazyScan();
    } catch (e) {
      if ($("#cal")) box.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
    }
  };
  const tabs = (sel, key, fn) =>
    $$(sel + " button").forEach(
      (b) =>
        (b.onclick = () => {
          S[key] = b.dataset.t;
          $$(sel + " button").forEach((x) => x.classList.toggle("on", x === b));
          fn();
        }),
    );
  tabs("#cpt", "collTab", plTab);
  tabs("#cat", "albTab", albTab);
  plTab();
  albTab();
  const spb = $("#sp-load");
  if (spb)
    spb.onclick = async () => {
      spb.disabled = true;
      $("#spbox").innerHTML = skel(2);
      try {
        const r = await api("spotify-library");
        $("#spbox").innerHTML =
          shelf("Плейлисты Spotify", r.playlists, { cards: plCard }) +
          `<section class="section"><div class="sec-head"><h2>Любимые треки Spotify</h2><button class="btn sm" id="spimp">Перенести в «Мне нравится»</button></div>${tracksHtml(r.liked, { cols: "cols" })}</section>`;
        $("#spimp").onclick = async () => {
          const x = await api("spotify-import-likes");
          setLikes(x.likes);
          toast("Перенесено: " + x.added);
        };
        lazyScan();
      } catch (e) {
        $("#spbox").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
      }
    };
}

/* ---------- «Концерты» (Яндекс Афиша) ---------- */
const MON = ["янв", "февр", "март", "апр", "май", "июнь", "июль", "авг", "сент", "окт", "нояб", "дек"];
const WD = ["вс", "пн", "вт", "ср", "чт", "пт", "сб"];
function evDate(s) {
  const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/);
  if (!m) return null;
  const d = new Date(+m[1], +m[2] - 1, +m[3]);
  return { mon: MON[d.getMonth()], day: d.getDate(), wd: WD[d.getDay()], time: m[4] ? `${m[4]}:${m[5]}` : "" };
}
const rub = (n) => (n == null ? "" : "от " + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " ₽");
function ticket(e, city, big) {
  const d = evDate(e.date);
  const meta = [e.kind || "Концерт", e.rating, city].filter(Boolean).join(" • ");
  return `<button class="tk${big ? " big" : ""}" data-ext="${esc(e.url)}" title="${esc(e.title + (e.place ? " — " + e.place : ""))}">
    <div class="tk-img" ${lbg(big ? e.image || e.poster : e.image)} style="background-color:${esc(/^#[0-9a-f]{3,8}$/i.test(e.color || "") ? e.color : "#1b1d33")}">${d ? `<span class="tk-date"><small>${d.mon}</small><b>${d.day}</b><small>${d.wd}</small></span>` : ""}${e.forYou ? `<span class="tk-you" title="Исполнитель из ваших лайков">${icon("heart")}Вы слушаете</span>` : ""}</div>
    <div class="tk-cut"></div>
    <div class="tk-info"><b>${esc(e.title)}</b><small>${esc(meta)}</small><small class="tk-pl">${esc([e.dateText, e.place].filter(Boolean).join(" · "))}</small>${e.price != null ? `<span class="tk-price">${rub(e.price)}</span>` : `<span class="tk-price ghost">Подробнее</span>`}</div></button>`;
}
async function concertsView() {
  const city = S.settings.concertCity || "";
  setContent(
    `<div class="cc-head"><h1 class="page">Концерты</h1><button class="cc-city" id="cc-city">${icon("pin")}<span>${esc(city ? S.concertCityName || "Город" : "Рядом")}</span>${icon("down")}</button></div><div id="ccb"><div class="tk-row">${'<div class="skel tk-skel"></div>'.repeat(4)}</div></div>`,
  );
  const route = S.route;
  const openCities = (e, cities) => {
    const cur = S.settings.concertCity || "";
    menu(e, [
      [(cur ? "" : "✓ ") + "Рядом — по вашему местоположению", "pin", () => setCity("")],
      "-",
      ...cities.map(([slug, name]) => [(slug === cur ? "✓ " : "") + name, "pin", () => setCity(slug, name)]),
    ]);
    $("#menu").classList.add("tall");
  };
  const setCity = async (slug, name) => {
    S.settings = await api("settings", { concertCity: slug });
    S.concertCityName = name || "";
    if (S.route === "concerts") concertsView();
  };
  $("#cc-city").onclick = (e) => openCities(e, S.concertCities || []);
  try {
    const d = await api("concerts", { city });
    if (S.route !== route) return;
    S.concertCities = d.cities || [];
    S.concertCityName = d.cityName;
    $("#cc-city span").textContent = city ? d.cityName : `Рядом · ${d.cityName}`;
    const top = d.events.slice(0, 8),
      rest = d.events.slice(8);
    $("#ccb").innerHTML =
      `<section class="section"><div class="sec-head"><h2>Топ для вас</h2><span class="sec-note">${esc(d.cityName)}${d.forYou ? " · " + plural(d.forYou, "концерт артиста из ваших лайков", "концерта артистов из ваших лайков", "концертов артистов из ваших лайков") : ""}</span><div class="shelf-nav"><button class="round-btn" data-scroll="tktop" data-dir="-1" title="Назад">${icon("left")}</button><button class="round-btn" data-scroll="tktop" data-dir="1" title="Вперёд">${icon("right")}</button></div></div><div class="shelf tk-row" id="tktop">${top.map((e) => ticket(e, d.cityName, true)).join("")}</div></section>` +
      (rest.length
        ? `<section class="section"><div class="sec-head"><h2>Концерты для вас</h2></div><div class="tk-grid">${rest.map((e) => ticket(e, d.cityName)).join("")}</div></section>`
        : "") +
      `<p class="muted ynote">Афиша и билеты — <a data-ext="${esc(d.url)}">Яндекс Афиша</a>. Нажмите на концерт, чтобы открыть его страницу и купить билет в браузере.</p>`;
    lazyScan();
  } catch (e) {
    if (S.route !== route) return;
    const slug = city || "moscow";
    $("#ccb").innerHTML =
      `<div class="empty"><b>Не удалось загрузить концерты</b>${esc(e.message)}<div style="margin-top:14px;display:flex;gap:10px;justify-content:center"><button class="btn sm" id="cc-retry">Повторить</button><button class="btn sm ghost" data-ext="https://afisha.yandex.ru/${esc(slug)}/concert">Открыть Яндекс Афишу</button></div></div>`;
    $("#cc-retry").onclick = () => concertsView();
    if (!S.concertCities?.length) S.concertCities = CITY_FALLBACK;
  }
}
const CITY_FALLBACK = [
  ["moscow", "Москва"],
  ["saint-petersburg", "Санкт-Петербург"],
  ["kazan", "Казань"],
  ["samara", "Самара"],
  ["yekaterinburg", "Екатеринбург"],
  ["novosibirsk", "Новосибирск"],
  ["nizhny-novgorod", "Нижний Новгород"],
  ["krasnodar", "Краснодар"],
];

/* ---------- playlist pages ---------- */
function listHero({ cover, cls = "", iconName = "", kind, title, meta, actions = "", edit = "", coverStyle = "" }) {
  const zoom = cover && !/^data:/.test(cover) ? ` data-zoom="${esc(cover)}" aria-label="${esc(title)}"` : "";
  const inner =
    (cover ? "" : iconName ? icon(iconName) : "") +
    (edit
      ? `<button class="hc-edit" data-cover-edit="${esc(edit)}" title="Сменить обложку">${icon("image")}</button>`
      : "");
  const st = cover ? bg(cover, isGlass() ? "m" : "m") : coverStyle ? `style="${coverStyle}"` : "";
  if (!isGlass())
    return `<div class="hero"><div class="hc ${cls}"${zoom} ${st}>${inner}</div><div style="min-width:0"><div class="kind">${esc(kind)}</div><h1>${esc(title)}</h1><div class="meta">${meta}</div><div class="acts">${actions}</div></div></div>`;
  if (spDesk()) return `<div class="sp-release"><div class="ghero"><div class="gh-cover ${cls}${cover ? " img" : ""}"${zoom} ${st}>${inner}</div><div class="gh-info"><div class="kind">${esc(kind)}</div><h1>${esc(title)}</h1><div class="meta">${meta}</div></div></div><div class="gh-acts sp-release-acts">${actions}</div></div>`;
  return `<div class="ghero"><div class="gh-cover ${cls}${cover ? " img" : ""}"${zoom} ${st}>${inner}</div><div class="gh-info"><div class="kind">${esc(kind)}</div><h1>${esc(title)}</h1><div class="meta">${meta}</div><div class="gh-acts">${actions}</div></div></div>`;
}
const gbtn = (id, ic, title) => `<button class="gbtn" id="${id}" title="${esc(title)}">${icon(ic)}</button>`;
const playActs = (id, extra = "", { noFilter = false } = {}) =>
  isGlass()
    ? `<button class="pill-acc" id="${id}">${icon("play")}Слушать</button>${gbtn(id + "-sh", "shuffle", "Перемешать")}${extra}`
    : `<button class="btn acc" id="${id}">${icon("play")}Слушать</button><button class="btn" id="${id}-sh">${icon("shuffle")}Перемешать</button>${noFilter ? "" : `<label class="filter">${icon("search")}<input id="flt" placeholder="Поиск по трекам"></label>`}${extra}`;
const moreBtn = (id) =>
  isGlass() ? gbtn(id, "more", "Ещё") : `<button class="icon-btn" id="${id}">${icon("more")}</button>`;
// genre chips of the new interface (screenshot: Всё · Бодрое · Рэп и хип-хоп · …)
const GENRE_CHIPS = [
  ["all", "Всё", null],
  ["up", "Бодрое", /energ|hard|phonk|drum|dnb|bass|trap|drill|edm|rock|metal|workout|бодр|энерг/i],
  ["rap", "Рэп и хип-хоп", /rap|hip.?hop|trap|drill|grime|рэп|хип/i],
  ["fun", "Весёлое", /happy|fun|party|disco|funk|summer|dance.?pop|весел|весёл/i],
  ["pop", "Поп", /pop|поп/i],
  ["el", "Электроника", /electr|edm|house|techno|trance|dubstep|drum|bass|synth|hyperpop|электр/i],
  ["sad", "Грустное", /sad|lo.?fi|ambient|piano|acoustic|ballad|emo|slowed|melanchol|грус/i],
  ["dance", "Танцевальная", /dance|house|disco|club|edm|garage|танц/i],
];
const genreText = (t) => `${t.genre || ""} ${S.matchedInfo?.[t.id]?.genre || ""} ${t.title || ""}`;
function listTools(list) {
  if (!isGlass()) return "";
  const chips = GENRE_CHIPS.map(([k, label, re]) => {
    const n = re ? list.reduce((a, t) => a + (re.test(genreText(t)) ? 1 : 0), 0) : list.length;
    return `<button class="gchip${k === "all" ? " on" : ""}${n ? "" : " dim"}" data-chip="${k}" title="${plural(n, "трек", "трека", "треков")}">${esc(label)}</button>`;
  }).join("");
  return `<label class="gsearch">${icon("search")}<input id="flt" placeholder="Поиск трека" autocomplete="off" spellcheck="false"></label><div class="gchips" id="gchips">${chips}</div>`;
}
function filterable(list, boxSel) {
  const inp = $("#flt");
  let chip = "all";
  const apply = () => {
    const box = $(boxSel);
    if (!box) return;
    const q = (inp?.value || "").toLowerCase().trim();
    const re = GENRE_CHIPS.find((c) => c[0] === chip)?.[2];
    let l = list;
    if (q) l = l.filter((t) => (t.title + " " + t.artist).toLowerCase().includes(q));
    if (re) l = l.filter((t) => re.test(genreText(t)));
    box.innerHTML = tracksHtml(l, { num: true });
  };
  if (inp) inp.oninput = debounce(apply, 120);
  $$("#gchips [data-chip]").forEach(
    (b) =>
      (b.onclick = () => {
        chip = b.dataset.chip;
        $$("#gchips [data-chip]").forEach((x) => x.classList.toggle("on", x === b));
        apply();
      }),
  );
}
function bindPlay(id, list) {
  const p = $("#" + id);
  if (p) p.onclick = () => list.length && playList(list, 0);
  const s = $("#" + id + "-sh");
  if (s)
    s.onclick = () => {
      if (!list.length) return;
      S.shuffle = true;
      syncModes();
      playList(list, Math.floor(Math.random() * list.length));
    };
}
async function pickCover(id, remove = false) {
  try {
    const url = await api("playlist-cover", { id, remove });
    if (id === "likes") S.likesCover = url;
    await reloadLib();
    if (S.route === (id === "likes" ? "likes" : "playlist:" + id)) reroute();
    if (!remove && url) toast("Обложка обновлена", 1800);
  } catch (e) {
    toast(e.message);
  }
}
function coverMenu(e, id) {
  const custom = id === "likes" ? !!S.likesCover : S.playlists.find((p) => p.id === id)?.customCover;
  const items = [["Выбрать обложку…", "image", () => pickCover(id)]];
  if (custom)
    items.push([
      id === "likes" ? "Вернуть стандартную обложку" : "Вернуть исходную обложку",
      "close",
      () => pickCover(id, true),
    ]);
  menu(e, items);
}
function likes() {
  const dur = S.likes.reduce((a, t) => a + (t.duration || 0), 0);
  setContent(
    listHero({
      cls: "likes",
      iconName: "heart",
      cover: S.likesCover,
      edit: "likes",
      kind: "Плейлист",
      title: "Мне нравится",
      meta: `${esc(S.settings.profile.nick)} · ${plural(S.likes.length, "трек", "трека", "треков")} · ${Math.round(dur / 60)} мин`,
      actions: playActs("lp", moreBtn("lmenu")),
    }) +
      listTools(S.likes) +
      `<div id="lt">${tracksHtml(S.likes, { num: true })}</div>`,
  );
  bindPlay("lp", S.likes);
  filterable(S.likes, "#lt");
  $("#lmenu").onclick = (e) => coverMenu(e, "likes");
}
function historyView() {
  setContent(
    listHero({
      cls: "likes hist",
      iconName: "clock",
      kind: "Коллекция",
      title: "История",
      meta: plural(S.history.length, "трек", "трека", "треков"),
      actions: playActs(
        "hp",
        isGlass()
          ? gbtn("hclear", "close", "Очистить историю")
          : `<button class="btn ghost" id="hclear">Очистить</button>`,
      ),
    }) +
      listTools(S.history) +
      `<div id="lt">${tracksHtml(S.history, { num: true })}</div>`,
  );
  bindPlay("hp", S.history);
  filterable(S.history, "#lt");
  $("#hclear").onclick = async () => {
    S.history = await api("clear-history");
    historyView();
  };
}
function matchHtml(m) {
  if (!m || !m.total) return "";
  const run = m.running;
  const txt = run
    ? `Подбираю версии без цензуры… ${m.found} из ${m.total}`
    : m.stopped
      ? `Подбор остановлен · найдено ${m.found} из ${m.total}`
      : `Подобрано без цензуры: ${m.found} из ${m.total}`;
  const pct = Math.round(((m.done != null && m.todo ? m.total - m.todo + m.done : m.found) / m.total) * 100);
  const btn = run
    ? `<button class="mbtn stop" data-match="stop" title="Остановить подбор — играть оригинальные версии">${icon("stop")}Остановить подбор</button>`
    : m.found < m.total
      ? `<button class="mbtn" data-match="resume">${icon("wave")}${m.stopped ? "Продолжить подбор" : "Подобрать заново"}</button>`
      : "";
  return `<span class="dot${run ? " run" : ""}"></span><span class="mtxt">${txt}</span>${run ? `<span class="mbar"><i style="width:${Math.min(100, pct)}%"></i></span>` : ""}${btn}`;
}
// 4.6: switching between own playlists does not flash a skeleton — the last copy of the playlist is shown at
// once (the fresh one replaces it only if something changed), a skeleton appears only for slow loads
const PL_CACHE = new Map();
async function localPlaylist(id) {
  const route = S.route,
    cached = PL_CACHE.get(id);
  if (cached) renderLocalPlaylist(id, cached);
  else skelLater(8);
  let p;
  try {
    p = await api("playlist-get", { id });
  } catch (e) {
    if (S.route === route) setContent(`<div class="empty">${esc(e.message)}</div>`);
    PL_CACHE.delete(id);
    return;
  }
  const same = cached && JSON.stringify(cached) === JSON.stringify(p);
  PL_CACHE.delete(id);
  PL_CACHE.set(id, same ? cached : p);
  if (PL_CACHE.size > 24) PL_CACHE.delete(PL_CACHE.keys().next().value);
  if (S.route !== route || same) return;
  const top = cached ? $("#content").scrollTop : 0;
  renderLocalPlaylist(id, p);
  if (top) $("#content").scrollTop = top;
}
function renderLocalPlaylist(id, p) {
  S.matchedInfo = p.matched || {};
  S.openPlaylist = p.id;
  S.pageTitle = { route: S.route, title: p.title };
  setContent(
    listHero({
      cover: p.cover || p.tracks.find((t) => t.cover)?.cover,
      edit: id,
      iconName: "note",
      kind: "Плейлист",
      title: p.title,
      meta: `${esc(S.settings.profile.nick)} · ${plural(p.tracks.length, "трек", "трека", "треков")}${p.description ? " · " + esc(p.description) : ""}<div id="mstat" class="mstat">${matchHtml(p.match)}</div>`,
      actions: playActs("pp", moreBtn("pmenu")),
    }) +
      listTools(p.tracks) +
      `<div id="lt" class="reorder"${p.kind === "album" ? ' data-album-tracks="true"' : ""}>${tracksHtml(p.tracks, { num: true })}</div>`,
  );
  bindPlay("pp", p.tracks);
  filterable(p.tracks, "#lt");
  reorderable($("#lt"), p);
  const mb = $("#pmix");
  if (mb) mb.onclick = () => go("mix:" + id);
  $("#pmenu").onclick = (e) => {
    const m = S.lastMatch?.id === id ? S.lastMatch : p.match;
    const items = [
      [
        "Переименовать",
        "edit",
        () =>
          promptDialog("Название плейлиста", p.title, async (v) => {
            await api("playlist-rename", { id, title: v });
            await reloadLib();
            if (S.route === "playlist:" + id) reroute();
          }),
      ],
      ["Сменить обложку…", "image", () => pickCover(id)],
    ];
    if (S.playlists.find((x) => x.id === id)?.customCover)
      items.push(["Вернуть исходную обложку", "close", () => pickCover(id, true)]);
    items.push("-", ["Добавить свои аудиофайлы…", "upload", () => uploadFiles(id)]);
    if (m && m.total) {
      items.push(["Где искать версии без цензуры…", "tune", () => matchSourceDialog(p)]);
      if (m.running) items.push(["Остановить подбор без цензуры", "stop", () => matchAction("stop")]);
      else if (m.found < m.total) items.push(["Подобрать версии без цензуры", "wave", () => matchAction("resume")]);
    }
    items.push("-", [
      "Удалить плейлист",
      "close",
      async () => {
        const yes = await confirmDialog({
          title: "Удалить плейлист?",
          text: "«" + p.title + (root.hasAttribute("data-mobile") ? "» исчезнет из коллекции. Это действие нельзя отменить." : "» исчезнет из коллекции и боковой панели. Это действие нельзя отменить."),
          ok: "Удалить",
          danger: true,
        });
        if (!yes) return;
        await api("playlist-delete", { id });
        await reloadLib();
        go("collection");
      },
    ]);
    menu(e, items);
  };
}
// 4.14: «Микс» of an own playlist (lit when its transitions sound on this page too)
function mixBtn(p) {
  if (!mixable(p)) return "";
  const on = !!p.mix?.on;
  return isGlass()
    ? `<button class="gbtn mx-gbtn${on ? " on" : ""}" id="pmix" title="${on ? "Микс включён — настроить переходы" : "Микс: переходы между треками, как у диджея"}">${icon("mix")}</button>`
    : `<button class="btn${on ? " acc" : ""}" id="pmix">${icon("mix")}Микс</button>`;
}
/* ---------- 4.14: «Микс» pages — Коллекция → Мои плейлисты → «Микс» (the list) and «mix:<id>» (a playlist) ----------
   The playlist page of a mix: «Слушать микс», the style and the length of its transitions, «Микс в плейлисте» (the
   transitions sound when the playlist plays from its own page too) and every transition between two neighbours:
   its own style / length, «Убрать конец трека» (seconds cut from the end of A), «Начать следующий с» (B starts
   later) and «Прослушать переход» (A from a few seconds before the transition). Saved in library.json (p.mix). */
// A separate, local mix can contain tracks from any source; old playlist mixes remain intact.
const GLOBAL_MIX_KEY = "wave.globalMix";
let GLOBAL_MIX;
function globalMix() {
  if (GLOBAL_MIX) return GLOBAL_MIX;
  try {
    GLOBAL_MIX = JSON.parse(localStorage.getItem(GLOBAL_MIX_KEY) || "null");
  } catch {}
  if (!GLOBAL_MIX || !Array.isArray(GLOBAL_MIX.tracks)) GLOBAL_MIX = { tracks: [], mix: {} };
  Object.assign(GLOBAL_MIX, { id: "@all", title: "Микс", global: true });
  return GLOBAL_MIX;
}
function saveGlobalMix() {
  try {
    localStorage.setItem(GLOBAL_MIX_KEY, JSON.stringify(globalMix()));
  } catch {
    toast("Не удалось сохранить микс", 3000);
  }
}
function addGlobalMix(t) {
  const p = globalMix();
  if (p.tracks.some((x) => x.id === t.id)) return toast("Этот трек уже в миксе");
  p.tracks.push(t);
  saveGlobalMix();
  toast("Трек добавлен в «Микс»");
}
function globalMixView() {
  globalMixEditor();
}
const mixable = (p) => !!p && !p.source && p.kind !== "album";
const mixOf = (p) => ({ on: false, style: "auto", len: 8, ...(p?.mix || {}), tr: p?.mix?.tr || {} });
const mixSec = (v) => String(Math.round(v * 10) / 10).replace(".", ",") + " с";
const mixName = (k) => (k === "custom" ? "Свой" : (MIX_ST.find((x) => x[0] === k) || MIX_ST[0])[1]);
const mixDesc = (k) => (MIX_ST.find((x) => x[0] === k) || MIX_ST[0])[2];
const mixVal = (k, v) =>
  k === "len" ? mixSec(v) : k === "out" ? (v ? "−" + mixSec(v) : "нет") : v ? "с " + fmt(v) : "с начала";
function mixCard(p) {
  const m = mixOf(p),
    own = Object.keys(m.tr).length;
  const sub = [
    plural(p.count || 0, "трек", "трека", "треков"),
    mixName(m.style) + (m.style === "cut" ? "" : " · " + mixSec(m.len)),
    own ? plural(own, "свой переход", "своих перехода", "своих переходов") : "",
  ]
    .filter(Boolean)
    .join(" · ");
  return `<button class="card mx-card${m.on ? " on" : ""}" data-go="mix:${esc(p.id)}"><div class="cv" ${lbg(p.cover)}>${p.cover ? "" : `<div class="cv-ph">${icon("mix")}</div>`}<div class="hov"><span class="pbtn">${icon("mix")}</span></div>${m.on ? `<span class="mx-badge">${icon("mix")}В плейлисте</span>` : ""}</div><b>${esc(p.title)}</b><small>${esc(sub)}</small></button>`;
}
function mixCardsHtml() {
  const mine = S.playlists.filter(mixable);
  const intro = `<div class="mx-intro"><span class="mx-ic">${icon("mix")}</span><div><b>Микс — переходы как у диджея</b><small>Треки перетекают друг в друга без пауз: концовка и начало накладываются, фильтры и бас двигаются, как на пульте. Откройте плейлист, чтобы выбрать стиль и настроить каждый переход.</small></div></div>`;
  return mine.length
    ? intro + `<div class="grid">${mine.map(mixCard).join("")}</div>`
    : intro +
        '<div class="empty wide"><b>Пока нечего сводить</b>Создайте свой плейлист — и его можно будет превратить в микс</div>';
}
// the curves of a style: the level of the current (A) and of the next (B) track over the transition
function mixCurveSvg(style) {
  const sh = MIX_SHAPE[style] || MIX_SHAPE.fade,
    W = 240,
    H = 64,
    n = 61;
  const pts = (f) =>
    Array.from({ length: n }, (_, k) => {
      const x = k / (n - 1);
      return `${(x * W).toFixed(1)},${(5 + (1 - Math.max(0, Math.min(1, f(x)))) * (H - 10)).toFixed(1)}`;
    }).join(" ");
  const fx =
    style === "rise"
      ? "фильтры: B из высоких, A под воду"
      : style === "blend"
        ? "бас меняется в середине"
        : style === "echo"
          ? "эхо на текущем треке"
          : style === "auto"
            ? "бас A уступает B"
            : "";
  return `<div class="mx-cv"><svg class="mx-curve" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><polyline class="a" points="${pts(sh.a)}"/><polyline class="b" points="${pts(sh.b)}"/></svg><div class="mx-leg"><span><i class="a"></i>Текущий</span><span><i class="b"></i>Следующий</span>${fx ? `<span class="fx">${esc(fx)}</span>` : ""}</div></div>`;
}
const mixSlider = (k, label, min, max, step, v, off = false) =>
  `<label class="mx-s${off ? " off" : ""}"><span class="mx-s-l">${esc(label)}<b data-mxv="${k}">${off ? "—" : mixVal(k, v)}</b></span><input type="range" class="sndp-range" data-mxk="${k}" min="${min}" max="${max}" step="${step}" value="${v}" style="--p:${(((v - min) / (max - min)) * 100).toFixed(1)}%"${off ? " disabled" : ""} aria-label="${esc(label)}"></label>`;
function mixSetHtml(m) {
  return `<div class="mx-set-top"><div class="mx-set-t"><b>Переходы</b><small>${esc(mixDesc(m.style))}</small></div><div class="mx-on"><span>Микс в плейлисте<small>Переходы звучат и на странице плейлиста</small></span><button class="switch${m.on ? " on" : ""}" data-mxa="on" aria-label="Микс в плейлисте"></button></div></div>
  <div class="mx-chips">${MIX_ST.map(([k, n]) => `<button class="gchip${m.style === k ? " on" : ""}" data-mxd="${k}" title="${esc(MIX_ST.find((x) => x[0] === k)[2])}">${esc(n)}</button>`).join("")}</div>
  <div class="mx-set-b">${mixCurveSvg(m.style)}<div class="mx-sl">${mixSlider("len", "Длина перехода", 1, 16, 0.5, m.len, m.style === "cut")}</div></div>`;
}
// the transition between the track i and i + 1
function mixTrHtml(p, i, open = false) {
  const a = p.tracks[i],
    b = p.tracks[i + 1];
  const pr = mixPair(a, b, mixOf(p));
  return `<div class="mx-tr${pr.own ? " own" : ""}${open ? " open" : ""}" data-mx="${i}"><i class="mx-tr-l"></i><button class="mx-tr-chip" data-mxa="edit" title="Настроить переход">${icon("mix")}<b>${esc(mixName(pr.style))}</b>${pr.style === "cut" ? "" : `<small>${mixSec(pr.len)}</small>`}${pr.out ? `<small>−${mixSec(pr.out)}</small>` : ""}${pr.in ? `<small>B ${fmt(pr.in)}</small>` : ""}${pr.own ? "<em>свой</em>" : ""}</button><button class="mx-tr-play" data-mxa="hear" title="Прослушать переход">${icon("play")}</button><i class="mx-tr-l"></i></div>`;
}
function mixEdHtml(p, i) {
  const a = p.tracks[i],
    b = p.tracks[i + 1];
  const m = mixOf(p),
    h = m.tr[mixKey(a, b)] || {},
    pr = mixPair(a, b, m);
  return `<div class="mx-ed" data-mxe="${i}">
  <div class="mx-ed-h"><span><small>Текущий</small><b>${esc(a.title)}</b></span>${icon("right")}<span><small>Следующий</small><b>${esc(b.title)}</b></span></div>
  <div class="mx-chips">${[["", "Как в миксе"], ...MIX_ST]
    .map(
      ([k, n]) =>
        `<button class="gchip${(h.style || "") === k ? " on" : ""}" data-mxs="${k}">${esc(n)}${k ? "" : ` · ${esc(mixName(m.style))}`}</button>`,
    )
    .join("")}</div>
  <p class="mx-desc">${esc(mixDesc(pr.style))}</p>
  <div class="mx-set-b">${mixCurveSvg(pr.style)}<div class="mx-sl">${mixSlider("len", "Длина перехода", 1, 16, 0.5, pr.len || m.len, pr.style === "cut")}${mixSlider("out", "Убрать конец трека", 0, 30, 1, pr.out)}${mixSlider("in", "Начать следующий", 0, 30, 1, pr.in)}</div></div>
  <div class="mx-ed-f"><button class="pill-acc mx-hear" data-mxa="hear">${icon("play")}Прослушать переход</button>${h && Object.keys(h).length ? '<button class="btn sm ghost" data-mxa="reset">Сбросить</button>' : ""}<button class="btn sm ghost" data-mxa="close">Готово</button></div></div>`;
}
// changes apply at once (the page and the playback read p.mix) and are saved 350 ms after the last one
const MXQ = { id: null, patch: null, t: 0, job: null };
function mixPatch(p, patch) {
  const cur = mixOf(p);
  const tr = { ...cur.tr };
  for (const [k, v] of Object.entries(patch.tr || {})) {
    const o = { ...(tr[k] || {}), ...v };
    for (const f of Object.keys(o)) if (o[f] === "" || o[f] == null || o[f] === 0) delete o[f];
    if (Object.keys(o).length) tr[k] = o;
    else delete tr[k];
  }
  p.mix = { ...cur, ...patch, tr };
  if (p.global) {
    saveGlobalMix();
    return;
  }
  for (const x of [S.playlists.find((y) => y.id === p.id), PL_CACHE.get(p.id)]) if (x && x !== p) x.mix = p.mix;
  if (MXQ.id && MXQ.id !== p.id) mixFlush();
  const q = MXQ.patch || {};
  const qtr = { ...(q.tr || {}) };
  for (const [k, v] of Object.entries(patch.tr || {})) qtr[k] = { ...(qtr[k] || {}), ...v };
  MXQ.id = p.id;
  MXQ.patch = { ...q, ...patch };
  if (Object.keys(qtr).length) MXQ.patch.tr = qtr;
  else delete MXQ.patch.tr;
  clearTimeout(MXQ.t);
  MXQ.t = setTimeout(mixFlush, 350);
}
function mixFlush() {
  clearTimeout(MXQ.t);
  const { id, patch } = MXQ;
  MXQ.id = MXQ.patch = null;
  if (!id || !patch) return MXQ.job || Promise.resolve();
  MXQ.job = api("playlist-mix", { id, mix: patch })
    .then((mix) => {
      const x = S.playlists.find((y) => y.id === id);
      if (x && !MXQ.id) x.mix = mix;
    })
    .catch((e) => toast("Микс: " + e.message, 4000));
  return MXQ.job;
}
async function mixView(id) {
  const route = S.route;
  const cached = PL_CACHE.get(id);
  if (cached) renderMix(id, cached);
  else skelLater(8);
  let p;
  try {
    await mixFlush();
    p = await api("playlist-get", { id });
  } catch (e) {
    if (S.route === route) setContent(`<div class="empty">${esc(e.message)}</div>`);
    return;
  }
  const same = cached && JSON.stringify(cached) === JSON.stringify(p);
  PL_CACHE.delete(id);
  PL_CACHE.set(id, same ? cached : p);
  if (S.route !== route || same) return;
  const top = cached ? $("#content").scrollTop : 0;
  renderMix(id, p);
  if (top) $("#content").scrollTop = top;
}
// «Прослушать переход»: A from 6 s before the transition, then B (and the rest of the playlist)
function mixHear(p, i) {
  const a = p.tracks[i],
    b = p.tracks[i + 1];
  if (!a || !b) return;
  const pr = mixPair(a, b, mixOf(p));
  S.wave = false;
  S.ctx = { title: "Микс · " + p.title, go: "mix:" + p.id, preview: true, pair: mixKey(a, b) };
  S.queue = p.tracks.slice(i);
  S.lists.q = S.queue;
  S.index = -1;
  S.startAt = { id: a.id, end: pr.out + pr.len + 6 };
  playAt(0);
  toast(`Прослушивание перехода «${mixName(pr.style)}»`, 2400);
}
function renderMix(id, p) {
  if (!mixable(p))
    return setContent(
      '<div class="empty"><b>Микс недоступен</b>Переходы настраиваются только в своих плейлистах</div>',
    );
  S.matchedInfo = p.matched || {};
  S.openPlaylist = p.id;
  S.pageTitle = { route: S.route, title: "Микс · " + p.title };
  const list = p.tracks,
    lid = reg(list);
  const mins = Math.round(list.reduce((a, t) => a + (t.duration || 0), 0) / 60);
  const glass = isGlass();
  const hero = listHero({
    cover: p.cover || list.find((t) => t.cover)?.cover,
    iconName: "mix",
    kind: "Микс",
    title: p.title,
    meta: `${plural(list.length, "трек", "трека", "треков")} · ${plural(Math.max(0, list.length - 1), "переход", "перехода", "переходов")}${mins ? " · " + mins + " мин" : ""}`,
    actions: glass
      ? `<button class="pill-acc" id="mxp">${icon("play")}Слушать микс</button>${gbtn("mxp-sh", "shuffle", "Перемешать")}${gbtn("mxpl", "note", "Открыть плейлист")}`
      : `<button class="btn acc" id="mxp">${icon("play")}Слушать микс</button><button class="btn" id="mxp-sh">${icon("shuffle")}Перемешать</button><button class="btn" id="mxpl">${icon("note")}Плейлист</button>`,
  });
  let rows = "";
  list.forEach((t, i) => {
    rows += trackRow(t, lid, i, { num: true });
    if (i < list.length - 1) rows += mixTrHtml(p, i);
  });
  setContent(
    hero +
      (p.global
        ? `<p class="page-sub">Добавляйте любые треки через меню «Микс». Выберите переход между соседними треками.</p><div class="mx-manage">${list.map((t, i) => `<button class="btn sm ghost" data-mx-remove="${i}" title="Убрать из микса">✕ ${esc(t.title)}</button>`).join("")}</div>`
        : "") +
      `<section class="mx-set" id="mxset">${mixSetHtml(mixOf(p))}</section>` +
      (list.length > 1
        ? `<div class="tracks mx-list" id="mxl">${rows}</div>`
        : `${list.length ? `<div class="tracks mx-list">${rows}</div>` : ""}<div class="empty"><b>Нужно хотя бы два трека</b>${p.global ? "Добавьте треки через меню «Микс»" : "Добавьте треки в плейлист"} — между ними появятся переходы</div>`),
  );
  const play = (shuffle) => {
    if (!list.length) return;
    if (shuffle) {
      S.shuffle = true;
      syncModes();
    }
    playList(list, shuffle ? Math.floor(Math.random() * list.length) : 0, {
      title: "Микс · " + p.title,
      go: "mix:" + id,
    });
  };
  $("#mxp").onclick = () => play(false);
  $("#mxp-sh").onclick = () => play(true);
  $("#mxpl").onclick = () => (p.global ? go("search") : go("playlist:" + id));
  if (p.global) {
    $("#mxpl").title = "Найти треки";
    $("#mxset .mx-on")?.remove();
    $$("[data-mx-remove]").forEach(
      (b) =>
        (b.onclick = () => {
          p.tracks.splice(+b.dataset.mxRemove, 1);
          saveGlobalMix();
          globalMixView();
        }),
    );
  }
  const set = $("#mxset"),
    box = $("#mxl");
  const rowsAgain = () => {
    if (!box) return;
    for (const r of box.querySelectorAll(".mx-tr"))
      r.outerHTML = mixTrHtml(p, +r.dataset.mx, r.classList.contains("open"));
    const ed = box.querySelector(".mx-ed");
    if (ed) ed.outerHTML = mixEdHtml(p, +ed.dataset.mxe);
  };
  const slide = (r) => {
    const v = +r.value,
      k = r.dataset.mxk;
    r.style.setProperty("--p", (((v - +r.min) / (+r.max - +r.min)) * 100).toFixed(1) + "%");
    const lbl = r.closest(".mx-s")?.querySelector("[data-mxv]");
    if (lbl) lbl.textContent = mixVal(k, v);
    return v;
  };
  set.addEventListener("click", (e) => {
    const sw = e.target.closest('[data-mxa="on"]');
    if (sw) {
      const on = !mixOf(p).on;
      sw.classList.toggle("on", on);
      mixPatch(p, { on });
      return toast(
        on
          ? "Микс в плейлисте включён — переходы звучат и на странице плейлиста"
          : "Микс в плейлисте выключен — переходы звучат только в «Слушать микс»",
        3200,
      );
    }
    const d = e.target.closest("[data-mxd]");
    if (!d) return;
    mixPatch(p, { style: d.dataset.mxd });
    set.innerHTML = mixSetHtml(mixOf(p));
    rowsAgain();
  });
  set.addEventListener("input", (e) => {
    const r = e.target.closest('[data-mxk="len"]');
    if (!r) return;
    mixPatch(p, { len: slide(r) });
    rowsAgain.pending = rowsAgain.pending || requestAnimationFrame(() => ((rowsAgain.pending = 0), rowsAgain()));
  });
  if (!box) return;
  const edit = (i, open) => {
    const ed = box.querySelector(".mx-ed"),
      was = ed ? +ed.dataset.mxe : -1;
    ed?.remove();
    box.querySelectorAll(".mx-tr.open").forEach((r) => r.classList.remove("open"));
    if (open === false || (open == null && was === i)) return;
    const row = box.querySelector(`.mx-tr[data-mx="${i}"]`);
    if (!row) return;
    row.classList.add("open");
    row.insertAdjacentHTML("afterend", mixEdHtml(p, i));
  };
  box.addEventListener("click", (e) => {
    const host = e.target.closest(".mx-tr, .mx-ed");
    if (!host) return;
    const i = +(host.dataset.mx ?? host.dataset.mxe);
    const a = p.tracks[i],
      b = p.tracks[i + 1];
    if (!a || !b) return;
    const act = e.target.closest("[data-mxa]")?.dataset.mxa;
    const st = e.target.closest("[data-mxs]");
    const k = mixKey(a, b);
    if (act === "edit") return edit(i);
    if (act === "close") return edit(i, false);
    if (act === "hear") return mixHear(p, i);
    if (act === "reset") {
      mixPatch(p, { tr: { [k]: { style: "", len: null, out: 0, in: 0 } } });
      return rowsAgain();
    }
    if (st) {
      mixPatch(p, { tr: { [k]: { style: st.dataset.mxs } } });
      rowsAgain();
    }
  });
  box.addEventListener("input", (e) => {
    const r = e.target.closest(".mx-ed [data-mxk]");
    if (!r) return;
    const i = +r.closest(".mx-ed").dataset.mxe;
    const a = p.tracks[i],
      b = p.tracks[i + 1];
    if (!a || !b) return;
    mixPatch(p, { tr: { [mixKey(a, b)]: { [r.dataset.mxk]: slide(r) } } });
    const row = box.querySelector(`.mx-tr[data-mx="${i}"]`);
    if (row) row.outerHTML = mixTrHtml(p, i, true);
  });
}

/* ---------- 4.6: drag-and-drop order of tracks in own playlists (works with virtual lists too) ---------- */
function reorderable(box, p) {
  if (!box) return;
  box.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const row = e.target.closest(".tr[data-l]");
    if (!row || e.target.closest("button, a, input, .c")) return;
    const from = +row.dataset.i,
      list = S.lists[row.dataset.l],
      sy = e.clientY,
      pid = e.pointerId;
    let d = null;
    const rowsNow = () => [...box.querySelectorAll(".tr[data-l]")].sort((a, b) => a.dataset.i - b.dataset.i);
    const place = (y) => {
      // insertion point: before the first row whose middle is below the pointer
      const rows = rowsNow();
      let ins = rows.length ? +rows[rows.length - 1].dataset.i + 1 : 0,
        ref = null;
      for (const r of rows) {
        const b = r.getBoundingClientRect();
        if (y < b.top + b.height / 2) {
          ins = +r.dataset.i;
          ref = b;
          break;
        }
      }
      const tb = (d.tracks.isConnected ? d.tracks : box).getBoundingClientRect();
      const last = rows.length ? rows[rows.length - 1].getBoundingClientRect() : tb;
      d.ins = ins;
      d.line.style.top = (ref ? ref.top : last.bottom) - tb.top - 1 + "px";
      rowsNow().forEach((r) => r.classList.toggle("drag-src", +r.dataset.i === from));
    };
    const scrollLoop = () => {
      if (!d) return;
      const c = $("#content").getBoundingClientRect(),
        edge = 70;
      const v = d.y < c.top + edge ? -(c.top + edge - d.y) : d.y > c.bottom - edge ? d.y - (c.bottom - edge) : 0;
      if (v) {
        $("#content").scrollTop += Math.max(-24, Math.min(24, v / 3));
        place(d.y);
      }
      d.raf = requestAnimationFrame(scrollLoop);
    };
    const start = (ev) => {
      const tracks = row.closest(".tracks") || box;
      const r = row.getBoundingClientRect();
      const ghost = row.cloneNode(true);
      ghost.classList.add("drag-ghost");
      ghost.querySelector("wave-ripple")?.remove();
      ghost.style.cssText = `position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
      document.body.appendChild(ghost);
      const line = document.createElement("i");
      line.className = "drop-line";
      tracks.appendChild(line);
      row.querySelectorAll("wave-ripple").forEach((x) => x.remove());
      document.body.classList.add("dnd");
      try {
        box.setPointerCapture(pid);
      } catch {}
      d = { ghost, line, tracks, dy: ev.clientY - r.top, y: ev.clientY, ins: from, raf: 0 };
      d.raf = requestAnimationFrame(scrollLoop);
    };
    const move = (ev) => {
      if (ev.pointerId !== pid) return;
      if (!d) {
        if (Math.abs(ev.clientY - sy) < 6) return;
        if (list !== p.tracks) {
          end();
          return toast("Сбросьте поиск и фильтр по жанру, чтобы менять порядок треков", 2600);
        }
        start(ev);
      }
      d.y = ev.clientY;
      d.ghost.style.transform = `translateY(${ev.clientY - d.dy - parseFloat(d.ghost.style.top)}px)`;
      place(ev.clientY);
    };
    const end = (ev) => {
      removeEventListener("pointermove", move, true);
      removeEventListener("pointerup", end, true);
      removeEventListener("pointercancel", end, true);
      if (!d) return;
      const { ins } = d;
      cancelAnimationFrame(d.raf);
      d.ghost.remove();
      d.line.remove();
      box.querySelectorAll(".drag-src").forEach((r) => r.classList.remove("drag-src"));
      document.body.classList.remove("dnd");
      d = null;
      // the click that ends a drag must not open the track panel
      const eat = (c) => {
        c.stopPropagation();
        c.preventDefault();
      };
      addEventListener("click", eat, { capture: true, once: true });
      setTimeout(() => removeEventListener("click", eat, true), 50);
      if (ev?.type !== "pointerup") return;
      const to = ins > from ? ins - 1 : ins;
      if (to === from || to < 0 || to >= p.tracks.length) return;
      const t = p.tracks[from];
      p.tracks.splice(from, 1);
      p.tracks.splice(to, 0, t);
      const top = $("#content").scrollTop;
      box.innerHTML = tracksHtml(p.tracks, { num: true });
      $("#content").scrollTop = top;
      api("playlist-move", { id: p.id, track: t.id, to })
        .then(() => {
          PL_CACHE.delete(p.id);
          if (S.ctx?.go === "playlist:" + p.id) syncQueueOrder(p);
        })
        .catch((err) => {
          toast(err.message);
          if (S.route === "playlist:" + p.id) reroute();
        });
    };
    addEventListener("pointermove", move, true);
    addEventListener("pointerup", end, true);
    addEventListener("pointercancel", end, true);
  });
}
// the playing queue that came from this playlist follows the new order (the current track keeps playing)
function syncQueueOrder(p) {
  if (S.shuffle || !S.current || S.queue.length !== p.tracks.length) return;
  const ids = new Set(S.queue.map((t) => t.id));
  if (!p.tracks.every((t) => ids.has(t.id))) return;
  S.queue = p.tracks.slice();
  S.index = S.queue.findIndex((t) => t.id === S.current.id);
  S.lists.q = S.queue;
  renderQList();
}
// own audio files (mp3, flac, wav, ogg, m4a…) — copied into the app folder, tags and covers are read
async function uploadFiles(id) {
  try {
    const r = await api("playlist-upload", { id });
    if (!r.added && !r.errors?.length) return;
    if (r.added) toast(`Добавлено: ${plural(r.added, "файл", "файла", "файлов")}`);
    if (r.errors?.length) toast("Не добавлены: " + r.errors.slice(0, 3).join("; "), 7000);
    await reloadLib();
    if (S.route === "playlist:" + id) reroute();
    probeDurations(r.tracks || [], r.urls || {});
  } catch (e) {
    toast(e.message, 5000);
  }
}
// the length of an own file is read by the browser (metadata only) and saved
function probeDurations(list, urls = {}) {
  const todo = list.filter((t) => t.id.startsWith("lf:") && !t.duration && urls[t.id]);
  if (!todo.length) return;
  let chain = Promise.resolve();
  for (const t of todo)
    chain = chain.then(
      () =>
        new Promise((done) => {
          const a = new Audio();
          let over = false;
          const fin = () => {
            if (over) return;
            over = true;
            a.removeAttribute("src");
            a.load();
            done();
          };
          a.preload = "metadata";
          a.onloadedmetadata = () => {
            if (isFinite(a.duration) && a.duration > 0)
              api("local-meta", { id: t.id, duration: a.duration }).catch(() => {});
            fin();
          };
          a.onerror = fin;
          setTimeout(fin, 8000);
          a.src = urls[t.id];
        }),
    );
  chain.then(() => S.route?.startsWith("playlist:") && reroute());
}
const MATCH_SRC = [
  ["auto", "Авто", "SoundCloud и Audius — берётся лучшее совпадение"],
  ["soundcloud", "SoundCloud", "Больше всего полных версий без цензуры и ремиксов"],
  ["audius", "Audius", "Независимые артисты, всё бесплатно и целиком"],
  [
    "spotify",
    "Spotify",
    "Недоступно: Spotify не отдаёт полный звук сторонним приложениям (только 30-секундные превью без ключа и Premium SDK)",
    true,
  ],
  ["vk", "VK Музыка", "Недоступно: у VK нет открытого API для аудио — его закрыли в 2016 году", true],
];
function matchSourceDialog(p) {
  const cur = p.matchSource || "auto";
  dialog(
    `<h3>Где искать версии без цензуры</h3><p class="muted" style="margin-bottom:12px">Для плейлиста «${esc(p.title)}». Найденные раньше версии из другого источника будут подобраны заново (выбранные вручную останутся).</p><div class="msrc">${MATCH_SRC.map(
      ([k, name, hint, off]) =>
        `<button class="pin${k === cur ? " cur" : ""}${off ? " off" : ""}" data-ms="${k}"${off ? " disabled" : ""}><span><b>${esc(name)}</b><small>${esc(hint)}</small></span>${k === cur ? `<i class="cur-mark">${icon("check")}</i>` : ""}</button>`,
    ).join("")}</div><div class="acts"><button class="btn" data-close>Закрыть</button></div>`,
    (d) =>
      d.querySelectorAll("[data-ms]:not([disabled])").forEach(
        (b) =>
          (b.onclick = async () => {
            d.close();
            try {
              const r = await api("playlist-set", { id: p.id, matchSource: b.dataset.ms });
              await reloadLib();
              toast(
                r.matchSource === "auto"
                  ? "Версии ищутся в SoundCloud и Audius"
                  : "Версии ищутся только в " + (r.matchSource === "audius" ? "Audius" : "SoundCloud"),
              );
              if (S.route === "playlist:" + p.id) reroute();
            } catch (e) {
              toast(e.message, 5000);
            }
          }),
      ),
  );
}
async function matchAction(kind) {
  const id = S.openPlaylist;
  if (!id) return;
  try {
    const m = kind === "stop" ? await api("match-stop", { id }) : await api("match-playlist", { id, retry: true });
    if (m) {
      S.lastMatch = { ...m, id };
      const el = $("#mstat");
      if (el) el.innerHTML = matchHtml(m);
    }
    if (kind === "stop")
      toast("Подбор остановлен. Уже найденные версии сохранены, остальные треки играют как есть", 4200);
  } catch (e) {
    toast(e.message);
  }
}
// 4.10: «14 марта 2025» (without «г.»)
const MONTHS_GEN = [
  "января",
  "февраля",
  "марта",
  "апреля",
  "мая",
  "июня",
  "июля",
  "августа",
  "сентября",
  "октября",
  "ноября",
  "декабря",
];
function ruDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ""));
  if (!m || +m[2] < 1 || +m[2] > 12) return "";
  return `${+m[3]} ${MONTHS_GEN[+m[2] - 1]} ${m[1]}`;
}
// «Дата выхода: 14 марта 2025 · Лейбл: VHQ» under an album / a track (Yandex Music data)
function releaseHtml(a) {
  if (!a) return "";
  const parts = [];
  const d = ruDate(a.releaseDate);
  if (d) parts.push(`<span>Дата выхода: ${esc(d)}</span>`);
  else if (a.year) parts.push(`<span>Год выхода: ${esc(String(a.year))}</span>`);
  const labels = (a.labels || []).filter(Boolean);
  if (labels.length) parts.push(`<span>${labels.length > 1 ? "Лейблы" : "Лейбл"}: ${esc(labels.join(", "))}</span>`);
  return parts.length ? `<div class="rel-foot">${parts.join("")}</div>` : "";
}
// 4.10: the artists of an album as links with a small round photo (like Yandex Music)
function albumArtistsHtml(p) {
  const list = (p.artists || []).filter((a) => a && a.name);
  if (!list.length) return esc(p.owner || "");
  return `<span class="al-arts">${list
    .map(
      (a) =>
        `<a class="al-art" data-artist="${esc(a.id || "")}" data-name="${esc(a.name)}">${a.cover ? `<i class="al-av" ${bg(a.cover, "s")}></i>` : `<i class="al-av ph">${esc((a.name || "?")[0])}</i>`}${esc(a.name)}</a>`,
    )
    .join(", ")}</span>`;
}
// 4.10: the pin on an album / Yandex playlist page: pinned = saved to the collection (and shown in the sidebar)
function pinnedOf(id, p = {}) {
  return (
    S.playlists.find((x) => x.remote === id) ||
    S.playlists.find(
      (x) => !x.remote && x.source === "saved" && x.title === p.title && (x.owner || "") === (p.owner || ""),
    ) ||
    null
  );
}
function pinBtnHtml(on) {
  const ic = on ? "pushpin-on" : "pushpin",
    t = on ? "Открепить" : "Закрепить";
  return isGlass()
    ? `<button class="gbtn rpin${on ? " on" : ""}" id="rpin" title="${t}" aria-pressed="${on}">${icon(ic)}</button>`
    : `<button class="btn ghost rpin${on ? " on" : ""}" id="rpin" aria-pressed="${on}">${icon(ic)}${t}</button>`;
}
async function remotePlaylist(id) {
  skelLater(8);
  try {
    const r = await api("remote-playlist", { id });
    if (S.route !== "rplaylist:" + id) return;
    const p = r.playlist || {};
    const album = id.startsWith("yma:");
    S.spShowPlays = isSpotify() && album && r.tracks.some(t => Number.isFinite(t.plays));
    S.pageTitle = { route: S.route, title: p.title || "Плейлист" };
    setContent(
      listHero({
        cover: p.cover || r.tracks[0]?.cover,
        iconName: "note",
        kind: album
          ? `${p.kind || "Альбом"}${p.year ? " · " + p.year : ""}`
          : p.kind || (id.startsWith("spp:") ? "Плейлист Spotify" : "Плейлист SoundCloud"),
        title: p.title || "Плейлист",
        meta: `${album ? albumArtistsHtml(p) : esc(p.owner || "")} · ${plural(r.tracks.length, p.pod ? "выпуск" : "трек", p.pod ? "выпуска" : "трека", p.pod ? "выпусков" : "треков")}${p.likes ? ` · ${icon("heart", "meta-ic")} ${fmtNum(p.likes)}` : ""}`,
        actions: playActs("rp", pinBtnHtml(!!pinnedOf(id, p)), { noFilter: album }),
      }) +
        // 4.10: no track search / genre chips on an album page (an album is short and of one genre)
        (album ? "" : listTools(r.tracks)) +
        `<div id="lt"${album ? ' data-album-tracks="true"' : ""}>${tracksHtml(r.tracks, { num: true })}</div>` +
        (album ? releaseHtml(p) : ""),
    );
    if (album && isSpotify()) {
      $("#lt").classList.add("sp-album-list");
      $("#lt").classList.toggle("has-plays", S.spShowPlays);
      $("#lt").insertAdjacentHTML("afterbegin", `<div class="sp-table-head"><span>#</span><span>Название</span>${S.spShowPlays ? '<span>Прослушивания</span>' : ''}<span>Время</span></div>`);
      spotifyReleaseColor(p.cover || r.tracks[0]?.cover, p.colors);
    }
    bindPlay("rp", r.tracks);
    filterable(r.tracks, "#lt");
    hlAlbumTrack(id, r.tracks);
    const onPin = async () => {
      const pin = $("#rpin");
      if (!pin || pin.disabled) return;
      pin.disabled = true;
      try {
        const cur = pinnedOf(id, p);
        if (cur) {
          await api("playlist-delete", { id: cur.id });
          await reloadLib();
          toast("«" + (p.title || "Плейлист") + "» откреплён и убран из коллекции");
        } else {
          await api("playlist-create", {
            title: p.title,
            tracks: r.tracks,
            cover: p.cover || null,
            source: "saved",
            kind: album ? "album" : "playlist",
            owner: p.owner || "",
            remote: id,
          });
          await reloadLib();
          toast("«" + (p.title || "Плейлист") + (root.hasAttribute("data-mobile") ? "» сохранён в коллекции" : "» закреплён — он в коллекции и в боковой панели"));
        }
      } catch (e) {
        toast(e.message);
      }
      const nb = $("#rpin");
      if (!nb) return;
      nb.outerHTML = pinBtnHtml(!!pinnedOf(id, p));
      $("#rpin").onclick = onPin;
    };
    $("#rpin").onclick = onPin;
  } catch (e) {
    if (S.route !== "rplaylist:" + id) return;
    // 4.9.1: the album of a track did not open → its track page
    if (S.hlTrack?.route === "rplaylist:" + id) return void hlAlbumTrack(id, []);
    setContent(`<div class="empty"><b>Не удалось открыть плейлист</b>${esc(e.message)}</div>`);
  }
}
// 4.9.1: the album opened from a track — scroll to the track (highlighted by trackRow); an album of one track
// (a single) or an album without this track → the track page instead
function hlAlbumTrack(id, tracks) {
  const h = S.hlTrack;
  if (!h || h.route !== "rplaylist:" + id) return;
  const i = tracks.findIndex((x) => x.id === h.id);
  if (i < 0 || tracks.length < 2) {
    S.hlTrack = null;
    TRACKS.set(h.t.id, h.t);
    return void go("track:" + h.t.id, { push: false });
  }
  requestAnimationFrame(() => {
    const sc = $("#content"),
      box = $("#lt .tracks");
    if (!sc || !box) return;
    const row = box.querySelector(`.tr[data-i="${i}"]`);
    const top = row ? row.getBoundingClientRect().top : box.getBoundingClientRect().top + i * (box._vl?.h || rowH());
    const y = top - sc.getBoundingClientRect().top + sc.scrollTop - sc.clientHeight / 3;
    if (y > 0) sc.scrollTo({ top: y, behavior: "smooth" });
  });
}
// 4.8: the card comes from Yandex Music first (bio, popular tracks, albums, similar artists), then SoundCloud /
// Audius; «Похожие исполнители» fall back to Deezer, «Видеоклипы» come from YouTube only
const OPEN_IN = { yandex: "Яндекс Музыке", audius: "Audius", soundcloud: "SoundCloud" };
async function artistView(arg) {
  const [id, ...n] = arg.split("|");
  skelLater(8);
  try {
    const r = await api("artist", { id, name: decodeURIComponent(n.join("|")) });
    if (S.route !== "artist:" + arg) return;
    const a = r.artist;
    const route = S.route;
    S.pageTitle = { route: S.route, title: a.name };
    const all = [...r.top, ...r.tracks.filter((t) => !r.top.some((x) => x.id === t.id))];
    const kind = ["Исполнитель", ...(a.genres || []).slice(0, 2)].join(" · ");
    const back = a.banner || (a.source === "yandex" ? a.avatar : null);
    // 4.9: photos of the artist (Yandex: all its pictures; SoundCloud / Audius: the avatar and the banner)
    const seen = new Set();
    const gal = [...(r.photos || []), a.avatar, a.banner]
      .filter((u) => u && /^https:/.test(u) && !seen.has(thumb(u, "x")) && seen.add(thumb(u, "x")))
      .slice(0, 40);
    S.gallery = { artist: gal };
    // 4.11: «Популярные треки ›» and the hero «N треков» open all tracks of the artist (the most popular first)
    const tgo = "artist-tracks:" + (a.id || id) + "|" + encodeURIComponent(a.name || decodeURIComponent(n.join("|")));
    setContent(
      `<div class="artist-hero${back ? " has-bg" : ""}${a.source === "yandex" && !r.bannerReal ? " soft" : ""}">${back ? `<div class="ah-bg" ${bg(back, "x")}></div>` : ""}<div class="hero"><div class="hc round${gal.length ? " zoomable" : ""}" ${bg(a.avatar)}${gal.length ? ` data-zoom="${esc(gal[0])}" data-gal="artist" aria-label="${esc(a.name)}" title="${gal.length > 1 ? "Фото исполнителя · " + gal.length : "Открыть фото"}"` : ""}>${gal.length > 1 ? `<i class="hc-cnt">${icon("image")}${gal.length}</i>` : ""}</div><div><div class="kind">${esc(kind)}</div><h1>${esc(a.name)}</h1>${a.bio ? `<p class="ah-bio">${esc(a.bio)}</p>` : ""}<div class="a-statrow"><div class="a-stat" id="a-stat"></div><button class="a-tracks" data-go="${esc(tgo)}" title="Все треки — от популярных к менее популярным">${icon("note")}${plural(a.tracks || all.length, "трек", "трека", "треков")}</button></div><div class="acts"><button class="btn acc" id="ap">${icon("play")}Слушать</button>${a.link ? `<button class="btn" data-ext="${esc(a.link)}">${icon("link")}Открыть в ${OPEN_IN[a.source] || "SoundCloud"}</button>` : ""}</div></div></div></div>
      ${artistTopHtml(r, tgo)}
      ${shelf("Альбомы", r.albums || [], { cards: albCard })}
      <div id="a-sim">${shelf("Похожие исполнители", r.similar || [], { cards: artistCard })}</div>
      <div id="a-clips"></div>
      <div id="a-sc"><section class="section sc-artist"><h2>Треки SoundCloud</h2><p class="page-sub">Загрузка…</p></section></div>`,
      { flush: false },
    );
    const topListId = $(".ar-pop [data-l]")?.dataset.l;
    if (topListId) S.popularQueue = { lid: topListId, list: all, id: a.id || id, name: a.name, route: tgo };
    $("#ap").onclick = () => playList(all, 0);
    artistBanner(a, route);
    api("artist-soundcloud", { id: a.id || id, name: a.name })
      .then((x) => {
        if (S.route !== route) return;
        const host = $("#a-sc");
        if (!host) return;
        const list = x?.tracks || [];
        if (!list.length || !x?.artist?.id) {
          const message = x?.reason === "disabled" ? "SoundCloud отключён в настройках" : "Треки SoundCloud не найдены";
          host.innerHTML = `<section class="section sc-artist"><h2>Треки SoundCloud</h2><p class="page-sub">${message}</p></section>`;
          return;
        }
        const scGo = "artist-tracks:" + x.artist.id + "|" + encodeURIComponent(x.artist.name || a.name);
        host.innerHTML = `<section class="section sc-artist"><div class="sec-head"><h2><button data-go="${esc(scGo)}">Треки SoundCloud<i class="arr">›</i></button></h2><button data-go="${esc(scGo)}">Показать все</button></div><p class="page-sub sc-source">Профиль SoundCloud: ${esc(x.artist.name || a.name)}</p>${tracksHtml(list.slice(0, 5), { hot: false })}</section>`;
        lazyScan();
      })
      .catch(() => {
        if (S.route === route && $("#a-sc")) $("#a-sc").innerHTML = '<section class="section sc-artist"><h2>Треки SoundCloud</h2><p class="page-sub">Не удалось загрузить треки SoundCloud</p></section>';
      });
    const want = decodeURIComponent(n.join("|")) || a.name;
    const yid = /^yar:/.test(a.id) ? a.id : /^yar:/.test(id) ? id : "";
    artistStats(want, yid, S.settings.artistStats || "yandex");
    api("artist-extra", { name: a.name, similar: !(r.similar || []).length })
      .then((x) => {
        if (S.route !== route) return;
        if (x?.similar?.length && !(r.similar || []).length)
          $("#a-sim").innerHTML = shelf("Похожие исполнители", x.similar, { cards: artistCard });
        if (x?.clips?.length) $("#a-clips").innerHTML = shelf("Видеоклипы", x.clips, { cards: clipCard });
      })
      .catch(() => {});
  } catch (e) {
    setContent(`<div class="empty"><b>Страница исполнителя недоступна</b>${esc(e.message)}</div>`);
  }
}

/* 4.13: the banner of the artist page from Spotify (the header picture of its artist page) or SoundCloud (the profile
   banner) — Настройки → Моя волна → «Баннер на странице артиста»; the avatar stays from Yandex Music. Nothing found
   (or «Яндекс») — the Yandex picture stays */
function artistBanner(a, route) {
  let src = S.settings.artistBanner || "spotify";
  // 4.20: Spotify gives no artist banners to Wave — on the phone the option is gone, SoundCloud takes its place
  if (src === "spotify" && root.hasAttribute("data-mobile")) src = "soundcloud";
  if (src === "yandex" || !a?.name) return;
  api("artist-banner", { name: a.name, source: src })
    .then((b) => {
      if (!b?.url || S.route !== route) return;
      const img = new Image();
      img.onload = () => {
        const hero = $(".artist-hero");
        if (!hero || S.route !== route) return;
        let el = hero.querySelector(".ah-bg");
        if (!el) {
          el = document.createElement("div");
          el.className = "ah-bg";
          hero.prepend(el);
        }
        el.style.backgroundImage = cssUrl(b.url);
        hero.classList.add("has-bg", "real");
        hero.classList.remove("soft");
        hero.dataset.banner = b.source || "";
        // the banner opens in the photo viewer too
        const gal = S.gallery?.artist;
        if (Array.isArray(gal) && !gal.includes(b.url)) gal.push(b.url);
      };
      img.src = b.url;
    })
    .catch(() => {});
}
/* 4.11: the artist card like Yandex Music — «Популярные треки ›» (5 tracks; the title opens all tracks of the artist
   sorted by popularity) and «Новый релиз» beside them; the long «Все треки» list at the bottom is gone */
const POP_N = 5;
function popTop(r) {
  const top = r.top?.length ? r.top : [...(r.tracks || [])].sort((x, y) => (y.plays || 0) - (x.plays || 0));
  return top.slice(0, POP_N);
}
// a release of the last 12 months is «новый», an older one — «последний»
function relFresh(rel, now = Date.now()) {
  const ms = Date.parse(rel?.date || "") || (rel?.year ? Date.UTC(+rel.year, 0, 1) : 0);
  return !!ms && now - ms < 365 * 864e5;
}
function releaseHtml411(rel) {
  if (!rel || !rel.title) return "";
  const when = rel.date ? ruDate(rel.date) : "";
  const date = when ? when + " г." : rel.year ? rel.year + " г." : "";
  let attrs;
  if (rel.track) {
    TRACKS.set(rel.track.id, rel.track);
    attrs = `data-trk="${esc(rel.track.id)}"`;
  } else attrs = `data-go="rplaylist:${esc(rel.id)}"`;
  const names = artistsHtml(rel.track || { artist: rel.owner, artists: rel.artists });
  return `<section class="ar-new"><h2>${relFresh(rel) ? "Новый релиз" : "Последний релиз"}</h2><div class="card ar-rel"><button class="ar-rel-cover" ${attrs} title="${esc(rel.title)}"><div class="cv" ${lbg(rel.cover)}>${rel.cover ? "" : `<div class="cv-ph">${icon("note")}</div>`}<div class="hov"><span class="pbtn">${icon("right")}</span></div></div></button><button class="ar-rel-title" ${attrs}>${esc(rel.title)}</button>${names ? `<small class="ar-rel-artists">${names}</small>` : ""}${date || rel.kind ? `<small class="ar-when">${esc([date, rel.kind].filter(Boolean).join(" · "))}</small>` : ""}</div></section>`;
}
function artistTopHtml(r, tgo) {
  const top = popTop(r);
  const rel = releaseHtml411(r.release);
  if (!top.length && !rel) return "";
  const pop = top.length
    ? `<section class="ar-pop"><div class="sec-head"><h2><button data-go="${esc(tgo)}" title="Все треки — от популярных к менее популярным">Популярные треки<i class="arr">›</i></button></h2></div>${tracksHtml(top, { hot: false })}</section>`
    : "";
  return `<div class="ar-top${rel ? " has-rel" : ""}${pop ? "" : " no-pop"}">${pop}${rel}</div>`;
}
// 4.11: all tracks of the artist, from the most popular to the least popular
async function artistTracksView(arg) {
  const [id, ...n] = arg.split("|");
  const name = decodeURIComponent(n.join("|"));
  const route = S.route;
  S.pageTitle = { route, title: "Все треки" + (name ? " · " + name : "") };
  skelLater(10);
  try {
    const r = await api("artist-tracks", { id, name });
    if (S.route !== route) return;
    const a = r.artist || {};
    const nm = a.name || name || "Исполнитель";
    const list = r.tracks || [];
    const more = r.truncated ? " (список может быть неполным)" : r.total > list.length ? ` (первые ${list.length} из ${r.total})` : "";
    setContent(
      `<div class="at-head">${a.avatar ? `<span class="at-av" ${bg(a.avatar, "s")}></span>` : ""}<div class="at-tx"><h1 class="page">Все треки</h1><p class="page-sub"><a class="al-art" data-artist="${esc(a.id || id)}" data-name="${esc(nm)}">${esc(nm)}</a> · ${plural(list.length, "трек", "трека", "треков")}${more} · от популярных к менее популярным</p></div>${list.length ? `<button class="btn acc" id="atp">${icon("play")}Слушать</button>` : ""}</div>
      ${tracksHtml(list, { num: true, hot: false })}`,
    );
    const p = $("#atp");
    if (p) p.onclick = () => playList(list, 0, { title: nm + " · популярные треки", go: route });
  } catch (e) {
    if (S.route === route) setContent(`<div class="empty"><b>Список треков недоступен</b>${esc(e.message)}</div>`);
  }
}

const STAT_SRC = [
  ["yandex", "Яндекс Музыка"],
  ["spotify", "Spotify"],
  ["soundcloud", "SoundCloud"],
  ["audius", "Audius"],
];
const fmtBig = (n) =>
  n >= 1e6
    ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(".", ",") + " млн"
    : n >= 1e4
      ? Math.round(n / 1e3) + " тыс."
      : String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
async function artistStats(name, id, src, save = false) {
  const box = $("#a-stat");
  if (!box) return;
  const route = S.route;
  const label = Object.fromEntries(STAT_SRC)[src];
  box.innerHTML = `<button class="a-chip" id="a-chip">${icon("user")}<span>…</span><small>${esc(label)}</small>${icon("down")}</button>`;
  const bind = () =>
    ($("#a-chip").onclick = (e) =>
      menu(
        e,
        STAT_SRC.map(([k, v]) => [(k === src ? "✓ " : "") + v, "user", () => artistStats(name, id, k, true)]),
      ));
  bind();
  try {
    const r = await api("artist-stats", { name, id, source: src, save });
    if (save) S.settings.artistStats = src;
    if (S.route !== route || !$("#a-chip")) return;
    $("#a-chip span").textContent = r ? `${fmtBig(r.value)} ${r.label}` : "нет данных";
  } catch (e) {
    if (S.route !== route || !$("#a-chip")) return;
    $("#a-chip span").textContent = "недоступно";
    $("#a-chip").title = e.message;
  }
}

/* ---------- profile, banner editor ---------- */
function avatarHtml(cls, id = "") {
  const p = S.settings.profile;
  return `<span class="avatar ${cls}"${id ? ` id="${id}"` : ""} ${bg(p.avatar)}>${p.avatar ? "" : esc((p.nick || "W")[0].toUpperCase())}</span>`;
}
const BL_DEF = { height: 300, x: 50, y: 50, zoom: 100 };
const bannerLayout = () => ({ ...BL_DEF, ...(S.settings.profile.bannerLayout || {}) });
const bannerImg = (src, L) =>
  `<img src="${esc(src)}" alt="" draggable="false" style="object-position:${L.x}% ${L.y}%;transform:scale(${L.zoom / 100});transform-origin:${L.x}% ${L.y}%">`;
function profilePrivacy() {
  try {
    return JSON.parse(localStorage.getItem("wave.profilePrivacy") || "{}");
  } catch {
    return {};
  }
}
function showcase() {
  try {
    return JSON.parse(localStorage.getItem("wave.showcase") || "{}");
  } catch {
    return {};
  }
}
function showcaseHtml() {
  const show = showcase();
  return `<section class="section showcase"><div class="sec-head"><h2>Витрина</h2></div><div class="showcase-grid">${[
    ["artist", "Любимый артист"],
    ["track", "Любимый трек"],
    ["album", "Любимый альбом"],
  ]
    .map(([k, label]) => {
      const v = show[k];
      return `<div class="showcase-card"><small>${label}</small>${v ? `<button class="showcase-item" data-showcase-open="${k}"><span class="showcase-cover" ${bg(v.cover || v.avatar, "s")}></span><span><b>${esc(v.title || v.name)}</b><small>${esc(v.artist || v.owner || "")}</small></span></button>` : "<p>Ничего не выбрано</p>"}<button class="btn sm" data-showcase="${k}">${v ? "Изменить" : "Выбрать"}</button>${v ? `<button class="btn sm ghost" data-showcase-clear="${k}">Убрать</button>` : ""}</div>`;
    })
    .join("")}</div></section>`;
}
function showcasePick(kind) {
  const label = { artist: "исполнителя", track: "трек", album: "альбом" }[kind];
  dialog(
    `<h3>Выберите ${label}</h3><form id="showcase-search"><input id="showcase-query" placeholder="Поиск" aria-label="Поиск"><button class="btn acc">Найти</button></form><div id="showcase-results"><p class="muted">Введите название или имя исполнителя.</p></div><div class="acts"><button class="btn" data-close>Закрыть</button></div>`,
    (d) => {
      const form = d.querySelector("#showcase-search"),
        box = d.querySelector("#showcase-results");
      let request = 0;
      form.onsubmit = async (e) => {
        e.preventDefault();
        const q = d.querySelector("#showcase-query").value.trim();
        if (!q) return;
        const n = ++request;
        box.textContent = "Поиск…";
        try {
          const r = await api("search", { q });
          if (n !== request || !d.open) return;
          const items = (r[kind === "artist" ? "artists" : kind === "album" ? "albums" : "tracks"] || [])
            .filter((x) => x && x.id && (x.title || x.name))
            .slice(0, 20);
          box.innerHTML = items.length
            ? items
                .map(
                  (v, i) =>
                    `<button class="pin" data-pick="${i}"><span class="pc" ${bg(v.cover || v.avatar, "s")}></span><span><b>${esc(v.title || v.name)}</b><small>${esc(v.artist || v.owner || "")}</small></span></button>`,
                )
                .join("")
            : '<p class="muted">Ничего не найдено</p>';
          box.querySelectorAll("[data-pick]").forEach(
            (b) =>
              (b.onclick = () => {
                const v = items[+b.dataset.pick],
                  data = showcase();
                data[kind] = v;
                localStorage.setItem("wave.showcase", JSON.stringify(data));
                d.close();
                profile();
              }),
          );
        } catch {
          if (n === request) box.textContent = "Поиск недоступен. Попробуйте ещё раз.";
        }
      };
    },
  );
}
function profile() {
  window.WaveSocial?.scheduleProfileSync();
  const p = S.settings.profile,
    L = bannerLayout();
  setContent(`<div class="pbanner${p.banner ? " has" : ""}" style="height:${L.height}px">${p.banner ? bannerImg(p.banner, L) : ""}<button class="pb-edit" data-banner-edit title="Изменить баннер">${icon("edit")}${p.banner ? "Положение и размер" : "Добавить баннер"}</button></div><div class="phead">${avatarHtml("")}<div><div class="kind muted">Профиль</div><h1>${esc(p.nick)}</h1><div class="stats"><span><b>${profilePrivacy().profile !== false && profilePrivacy().likes !== false ? S.likes.length : "—"}</b>лайков</span><span><b>${profilePrivacy().profile !== false && profilePrivacy().playlists !== false ? S.playlists.length : "—"}</b>плейлистов</span><span><b>${profilePrivacy().profile !== false && profilePrivacy().history !== false ? S.history.length : "—"}</b>в истории</span></div></div><div style="flex:1"></div><button class="btn" data-go="settings">${icon("settings")}Редактировать</button></div>
  ${profilePrivacy().profile === false ? '<p class="muted">Разделы профиля скрыты на этом устройстве. Изменить это можно в настройках приватности.</p>' : `${showcaseHtml()}${profilePrivacy().likes === false ? "" : shelf("Мне нравится", S.likes.slice(0, 24), { go: "likes" })}${profilePrivacy().playlists === false ? "" : shelf("Плейлисты", S.playlists, { cards: plCard })}${profilePrivacy().history === false ? "" : shelf("Недавно слушали", S.history.slice(0, 24), { go: "history" })}`}`);
  $$("[data-showcase-open]").forEach(
    (b) =>
      (b.onclick = () => {
        const kind = b.dataset.showcaseOpen,
          v = showcase()[kind];
        if (!v) return;
        if (kind === "artist") openArtist(v.id, v.name);
        else if (kind === "album") go("rplaylist:" + v.id);
        else {
          TRACKS.set(v.id, v);
          openTrack(v);
        }
      }),
  );
  // 4.20.1: a tap on the round avatar of the profile picks a new picture (same as «Аватар» in the settings)
  const pav = $(".phead > .avatar");
  if (pav) {
    pav.classList.add("pick");
    pav.setAttribute("role", "button");
    pav.setAttribute("aria-label", "Сменить аватар");
    pav.onclick = async () => {
      if (await pickProfileImage("avatar")) {
        window.WaveSocial?.scheduleProfileSync?.();
        if (S.route === "profile") profile();
        toast("Аватар обновлён", 1800);
      }
    };
  }
  $$("[data-showcase]").forEach((b) => (b.onclick = () => showcasePick(b.dataset.showcase)));
  $$("[data-showcase-clear]").forEach(
    (b) =>
      (b.onclick = () => {
        const data = showcase();
        delete data[b.dataset.showcaseClear];
        localStorage.setItem("wave.showcase", JSON.stringify(data));
        profile();
      }),
  );
}
async function pickProfileImage(kind) {
  try {
    const u = await api("pick-image", { kind });
    if (u) {
      S.settings.profile[kind] = u;
      if (kind === "banner") S.settings.profile.bannerLayout = { ...BL_DEF };
      applySettings();
      if (kind === "banner") await api("settings", { profile: { bannerLayout: BL_DEF } });
    }
    return u;
  } catch (e) {
    toast(e.message);
    return null;
  }
}
async function bannerEditor() {
  let p = S.settings.profile;
  if (!p.banner) {
    if (!(await pickProfileImage("banner"))) return;
    if (S.route === "profile" || S.route === "settings") reroute();
    p = S.settings.profile;
  }
  const L = bannerLayout();
  const cw = Math.max(600, $("#content").clientWidth || 1000);
  dialog(
    `<h3>Баннер профиля</h3><p class="muted" style="margin-bottom:12px">${root.hasAttribute("data-mobile") ? "Перетащите картинку пальцем. Масштаб и положение можно изменить ползунками." : "Перетащите картинку мышью, колесо — масштаб."} Так баннер будет выглядеть на странице профиля.</p>
    <div class="be-stage" id="be-stage">${bannerImg(p.banner, L)}</div>
    <div class="be-grid">
      <label>Высота<input type="range" id="be-height" min="140" max="600" step="10" value="${L.height}"><b id="be-height-v"></b></label>
      <label>Масштаб<input type="range" id="be-zoom" min="100" max="400" step="5" value="${L.zoom}"><b id="be-zoom-v"></b></label>
      <label>По горизонтали<input type="range" id="be-x" min="0" max="100" step="1" value="${L.x}"><b id="be-x-v"></b></label>
      <label>По вертикали<input type="range" id="be-y" min="0" max="100" step="1" value="${L.y}"><b id="be-y-v"></b></label>
    </div>
    <div class="acts"><button class="btn ghost" id="be-pick">Другая картинка</button><button class="btn ghost" id="be-rm">Убрать</button><span style="flex:1"></span><button class="btn ghost" id="be-reset">Сбросить</button><button class="btn" data-close>Отмена</button><button class="btn acc" id="be-save">Сохранить</button></div>`,
    (d) => {
      d.classList.add("wide");
      const stage = d.querySelector("#be-stage"),
        img = stage.querySelector("img");
      const draw = () => {
        const w = stage.clientWidth || 640;
        stage.style.height = Math.round((w * L.height) / cw) + "px";
        img.style.objectPosition = `${L.x}% ${L.y}%`;
        img.style.transformOrigin = `${L.x}% ${L.y}%`;
        img.style.transform = `scale(${L.zoom / 100})`;
        for (const k of ["height", "zoom", "x", "y"]) {
          d.querySelector("#be-" + k).value = L[k];
          d.querySelector("#be-" + k + "-v").textContent = k === "height" ? L[k] + " px" : Math.round(L[k]) + "%";
        }
      };
      for (const k of ["height", "zoom", "x", "y"])
        d.querySelector("#be-" + k).oninput = (e) => {
          L[k] = +e.target.value;
          draw();
        };
      stage.onpointerdown = (e) => {
        stage.setPointerCapture(e.pointerId);
        let px = e.clientX,
          py = e.clientY;
        stage.onpointermove = (ev) => {
          const w = stage.clientWidth,
            h = stage.clientHeight,
            z = L.zoom / 100;
          const ratio = img.naturalWidth && img.naturalHeight ? img.naturalWidth / img.naturalHeight : w / h;
          const cwid = Math.max(w, h * ratio) * z,
            chei = Math.max(h, w / ratio) * z;
          const rx = Math.max(40, cwid - w),
            ry = Math.max(30, chei - h);
          L.x = Math.max(0, Math.min(100, L.x - ((ev.clientX - px) / rx) * 100));
          L.y = Math.max(0, Math.min(100, L.y - ((ev.clientY - py) / ry) * 100));
          px = ev.clientX;
          py = ev.clientY;
          draw();
        };
        stage.onpointerup = () => (stage.onpointermove = stage.onpointerup = null);
      };
      stage.onwheel = (e) => {
        e.preventDefault();
        L.zoom = Math.max(100, Math.min(400, L.zoom - Math.sign(e.deltaY) * 10));
        draw();
      };
      d.querySelector("#be-reset").onclick = () => {
        Object.assign(L, BL_DEF);
        draw();
      };
      d.querySelector("#be-pick").onclick = async () => {
        d.close();
        if (await pickProfileImage("banner")) {
          if (S.route === "profile" || S.route === "settings") reroute();
          bannerEditor();
        }
      };
      d.querySelector("#be-rm").onclick = async () => {
        d.close();
        S.settings = await api("settings", { profile: { banner: null } });
        applySettings();
        if (S.route === "profile" || S.route === "settings") reroute();
      };
      d.querySelector("#be-save").onclick = async () => {
        S.settings = await api("settings", { profile: { bannerLayout: L } });
        d.close();
        applySettings();
        if (S.route === "profile" || S.route === "settings") reroute();
      };
      requestAnimationFrame(draw);
      img.onload = draw;
    },
  );
}
/* ---------------- settings ---------------- */
const segHtml = (key, opts, cur) =>
  `<div class="seg" data-seg="${key}">${opts.map(([v, label, ic]) => `<button data-v="${v}" class="${cur === v ? "on" : ""}">${ic ? icon(ic) : ""}${esc(label)}</button>`).join("")}</div>`;
// 4.6: settings are split into tabs (the last one is remembered)
const SET_TABS = [
  ["main", "Основные"],
  ["play", "Воспроизведение"],
  ["look", "Кастомизация"],
  ["acc", "Подключения"],
  ["privacy", "Приватность"],
];
function setTab() {
  let t = "";
  try {
    t = localStorage.getItem("wave.setTab") || "";
  } catch {}
  // 4.21: на телефоне только «Основные» и «Дополнительно» — прежние вкладки и мусор в localStorage сворачиваются на «Основные»
  if (root.hasAttribute("data-mobile")) return ({ play: "more", privacy: "main" })[t] || (["main", "look", "acc", "more"].includes(t) ? t : "main");
  return SET_TABS.some(([k]) => k === t) ? t : "main";
}
function showSetTab(tab, user) {
  $$(".stab").forEach((b) => {
    b.classList.toggle("on", b.dataset.stab === tab);
    b.setAttribute("aria-selected", b.dataset.stab === tab);
  });
  $$(".settings > .scard").forEach((c) => (c.hidden = (c.dataset.tab || "main") !== tab));
  if (!user) return;
  try {
    localStorage.setItem("wave.setTab", tab);
  } catch {}
  $("#content").scrollTop = 0;
}
function settingsView() {
  const s = S.settings,
    p = s.profile;
  const mob = root.hasAttribute("data-mobile");
  const sw = (k, on) => `<button class="switch${on ? " on" : ""}" data-sw="${k}"></button>`;
  const tab = setTab();
  const wf = s.waveFx || WFX_DEF;
  const lq = liquidOpts();
  const lqRow = (k, name, hint) =>
    `<div class="row"><div class="lbl"><b>${name}</b><small>${hint}</small></div><input type="range" class="range" data-lq="${k}" min="0" max="100" step="1" value="${lq[k]}"><span class="range-val" id="lq-${k}">${lq[k]} %</span></div>`;
  const gf = glowOpts();
  const gfRow = (k, name, hint, min, max) =>
    `<div class="row"><div class="lbl"><b>${name}</b><small>${hint}</small></div><input type="range" class="range" data-wgf="${k}" min="${min}" max="${max}" step="1" value="${gf[k]}"><span class="range-val" id="wgf-${k}">${gf[k]} %</span></div>`;
  const wfRow = (k, name, hint, min, max) =>
    `<div class="row"><div class="lbl"><b>${name}</b><small>${hint}</small></div><input type="range" class="range" data-wfx="${k}" min="${min}" max="${max}" step="1" value="${wf[k]}"><span class="range-val" id="wfx-${k}">${wf[k]} %</span></div>`;
  const tabs = mob ? [["main", "Основные"], ["look", "Кастомизация"], ["acc", "Подключения"], ["more", "Дополнительно"]] : SET_TABS;
  setContent(`<h1 class="page">Настройки</h1><div class="stabs" role="tablist">${tabs.map(([k, v]) => `<button class="stab${k === tab ? " on" : ""}" data-stab="${k}" role="tab" aria-selected="${k === tab}">${v}</button>`).join("")}</div><div class="settings">
  <div class="scard" data-tab="look"><h2>Интерфейс</h2><p>Новый интерфейс и классический (как в 4.1) полностью независимы — переключайтесь в любой момент, библиотека и настройки общие.</p>
    <div class="row"><div class="lbl"><b>Интерфейс</b><small>«Новый» — Liquid Glass, «Классический» — прежний вид Wave</small></div>${segHtml(
      "ui",
      [
        ["glass", "Новый"],
        ["classic", "Классический"],
      ],
      s.ui,
    )}</div>
    <div class="row"><div class="lbl"><b>Полноэкранный плеер</b><small>${root.hasAttribute("data-mobile") ? "Открывается нажатием на обложку или мини-плеер. Закрыть — смахнуть вниз или нажать стрелку" : "Открывается кликом по обложке в плеере. Esc — свернуть"}</small></div>${segHtml(
      "player",
      [
        ["cover", "Яндекс"],
        ["nowplaying", "Wave"],
        ["classic", "Классический"],
      ],
      s.player,
    )}</div>
    <div class="row only-glass"><div class="lbl"><b>Акцентный цвет</b><small>«Из обложки» — цвет берётся из обложки текущего трека. «Аркейн» — красно-чёрная тема всего интерфейса, «Изумруд» — зелёная, «Сакура» — розовая</small></div>${segHtml(
      "accent",
      [
        ["violet", "Фиолетовый"],
        ["yellow", "Жёлтый"],
        ["arcane", "Аркейн"],
        ["emerald", "Изумруд"],
        ["sakura", "Сакура"],
        ["cover", "Из обложки"],
      ],
      s.accent,
    )}</div>
    <div class="row only-glass"><div class="lbl"><b>Оформление</b><small>${root.hasAttribute("data-mobile") ? "«Wave» — фирменный вид: глубокий фиолетовый фон с сиянием, стеклянные панели и градиентные кнопки в акцентном цвете. «Яндекс Музыка» — как в Яндекс Музыке: чёрный фон и жёлтые кнопки. «Spotify» — чёрный фон и зелёные кнопки. Акцентный цвет действует в оформлении «Wave»" : "«Яндекс Музыка» — в стиле нового клиента Яндекс Музыки: чёрная панель слева, тёмная область со скруглёнными углами, плеер в цвет обложки, жёлтые кнопки «Слушать». «Spotify» — как Spotify для компьютера: чёрный фон, панели #121212, библиотека слева, поиск по центру сверху, зелёные кнопки. Цвет акцента и «жидкое стекло» в этих темах не действуют"}</small></div>${segHtml(
      "skin",
      [
        ["wave", "Wave"],
        ["yandex", "Яндекс Музыка"],
        ["spotify", "Spotify"],
      ],
      s.skin || "wave",
    )}</div>
    <div class="row only-glass"><div class="lbl"><b>Эффект стекла</b><small>Если интерфейс подтормаживает на ${root.hasAttribute("data-mobile") ? "телефоне" : "слабой видеокарте"} — выберите «Лёгкий» или «Выкл»</small></div>${segHtml(
      "glassFx",
      [
        ["full", "Полный"],
        ["lite", "Лёгкий"],
        ["off", "Выкл"],
      ],
      s.glassFx,
    )}</div>
    <div class="row"><div class="lbl"><b>Шрифт</b><small>«YS Text» — шрифт Яндекс Музыки, загружается с yastatic.net (без интернета — Onest). «Onest» — встроенный открытый шрифт</small></div>${segHtml(
      "font",
      [
        ["ys", "YS Text"],
        ["onest", "Onest"],
      ],
      s.font || "ys",
    )}</div>
    <div class="row only-classic"><div class="lbl"><b>Тема</b></div>${segHtml(
      "theme",
      [
        ["dark", "Тёмная", "moon"],
        ["light", "Светлая", "sun"],
      ],
      s.theme,
    )}</div>
    <div class="row"><div class="lbl"><b>Ширина боковой панели</b><small>Можно и просто потянуть за правый край панели. Двойной клик по краю — вернуть 250 px</small></div><input type="range" class="range" id="sbw" min="200" max="380" step="2" value="${s.sidebarWidth || 250}"><span class="range-val" id="sbw-v">${s.sidebarWidth || 250} px</span></div>
    <div class="row"><div class="lbl"><b>GIF на ползунке</b><small>Анимация движется вместе с ползунком мини-плеера. GIF до 4 МБ</small></div>${s.progressGif ? `<img class="gif-prev" src="${esc(s.progressGif)}" alt="">` : ""}<button class="btn sm" id="pick-gif">${s.progressGif ? "Сменить" : "Выбрать GIF"}</button>${s.progressGif ? '<button class="btn sm ghost" id="rm-gif">Убрать</button>' : ""}</div>
    ${s.progressGif ? `<div class="row"><div class="lbl"><b>Размер GIF</b></div><input type="range" class="range" id="gifsz" min="24" max="120" step="2" value="${s.progressGifSize || 44}"><span class="range-val" id="gifsz-v">${s.progressGifSize || 44} px</span></div>` : ""}
    <div class="row"><div class="lbl"><b>Анимации</b><small>Живой фон Моей волны, плавное открытие плеера и волна от нажатия на кнопки</small></div>${sw("animation", s.animation)}</div>
    <div class="row only-glass"><div class="lbl"><b>Проценты громкости</b><small>Цифра над вертикальным ползунком громкости</small></div>${sw("volPct", s.volPct !== false)}</div>
    ${!root.hasAttribute("data-mobile") ? `<div class="row"><div class="lbl"><b>Запускать вместе с Windows</b><small>Wave откроется сам после входа в систему</small></div>${sw("autostart", s.autostart === true)}</div>` : ""}
    <div class="row"><div class="lbl"><b>Аппаратное ускорение</b><small>Выключите, если окно чёрное, мигает или приложение вылетает. Применится после перезапуска</small></div>${sw("gpu", s.gpu !== false)}</div></div>
  <div class="scard only-glass" data-tab="look" id="lq-card"><h2>Жидкое стекло</h2><p>${root.hasAttribute("data-mobile") ? "Кнопки, плеер и меню с полупрозрачным размытием и бликами. На телефоне используется облегчённый эффект без преломления; его можно настроить или выключить." : "Кнопки, плеер, меню и окна как в iOS 26: стекло преломляет то, что под ним, по краям, на нём играют блики. Всё настраивается, эффект можно выключить целиком."}</p>
    <div class="row"><div class="lbl"><b>Жидкое стекло</b><small>${(s.glassFx || "full") === "off" ? "Сейчас не работает: выше выбран «Эффект стекла — Выкл»" : (root.hasAttribute("data-mobile") ? "Если интерфейс подтормаживает на телефоне — выключите его или уменьшите размытие" : "Если интерфейс подтормаживает на слабой видеокарте — выключите или уменьшите преломление")}</small></div>${sw("lq:on", lq.on)}</div>
    <div class="lq-more${lq.on ? "" : " off"}">
    ${lqRow("refract", "Преломление", "Насколько сильно стекло изгибает фон у краёв")}
    ${lqRow("blur", "Размытие", "Матовость стекла: 0 — совсем прозрачное, как линза")}
    ${lqRow("shine", "Блики", "Яркость светлой кромки и отблеска")}
    ${lqRow("clear", "Прозрачность", "Насколько сквозь плеер, меню и окна видно то, что под ними")}
    <div class="row"><div class="lbl"><b>Блик за курсором</b><small>Отблеск на стекле двигается вслед за мышью</small></div>${sw("lq:follow", lq.follow)}</div>
    <div class="row"><div class="lbl"><b>Плеер</b><small>Мини-плеер внизу ${root.hasAttribute("data-mobile") ? "экрана" : "окна"}</small></div>${sw("lq:player", lq.player)}</div>
    <div class="row"><div class="lbl"><b>Кнопки</b><small>Круглые кнопки Моей волны, страниц и полноэкранного плеера</small></div>${sw("lq:buttons", lq.buttons)}</div>
    <div class="row"><div class="lbl"><b>Меню и окна</b><small>Контекстные меню, диалоги, настройки звука и громкость</small></div>${sw("lq:menus", lq.menus)}</div>
    <div class="row"><div class="lbl"><b>По умолчанию</b><small>${root.hasAttribute("data-mobile") ? "Размытие 30 %, блики 60 %, прозрачность 35 %" : "Преломление 60 %, размытие 30 %, блики 60 %, прозрачность 35 %, всё включено"}</small></div><button class="btn sm ghost" id="lq-reset">Сбросить</button></div></div></div>
  <div class="scard" data-tab="main"><h2>Профиль</h2><p>Аватар, ник и баннер видны ${root.hasAttribute("data-mobile") ? "" : "в боковой панели и "}на странице профиля. Хранятся только на этом ${root.hasAttribute("data-mobile") ? "телефоне" : "компьютере"}.</p>
    <div class="prof-edit">${avatarHtml("")}<div class="banner-prev" id="bprev">${p.banner ? bannerImg(p.banner, bannerLayout()) : ""}<div class="bp-acts"><button class="btn sm" id="pick-banner">${p.banner ? "Сменить баннер" : "Добавить баннер"}</button>${p.banner ? `<button class="btn sm" data-banner-edit>Положение и размер</button><button class="btn sm" id="rm-banner">Убрать</button>` : ""}</div></div></div>
    <div class="row" style="margin-top:14px"><div class="lbl"><b>Ник</b><small>До 40 символов</small></div><input type="text" id="nick" maxlength="40" value="${esc(p.nick)}"></div>
    <div class="row"><div class="lbl"><b>Аватар</b><small>PNG, JPG, WEBP или GIF (анимированный до 6 МБ)</small></div><button class="btn sm" id="pick-avatar">Выбрать</button>${p.avatar ? '<button class="btn sm ghost" id="rm-avatar">Убрать</button>' : ""}</div></div>
  <div class="scard" data-tab="privacy"><h2>Приватность профиля</h2><p>Эти настройки только скрывают разделы на этом ${document.documentElement.hasAttribute("data-mobile") ? "телефоне" : "компьютере"}. Wave не публикует профиль и не управляет приватностью Яндекс Музыки или Spotify.</p>${[
    ["profile", "Профиль"],
    ["likes", "Мне нравится"],
    ["playlists", "Плейлисты"],
    ["history", "Недавно слушали"],
  ]
    .map(
      ([k, name]) =>
        `<div class="row"><div class="lbl"><b>${name}</b><small>Показывать на странице профиля</small></div><button class="switch${profilePrivacy()[k] !== false ? " on" : ""}" data-privacy="${k}" aria-label="Показывать: ${name}"></button></div>`,
    )
    .join("")}</div>
  ${root.hasAttribute("data-mobile") ? "" : `<div class="scard" data-tab="play"><h2>Звук</h2><p>Скорость, эквалайзер и плавные переходы между треками. Всё это есть и в панели «Настройки звука» — кнопка с ползунками в плеере.</p>
    <div class="row"><div class="lbl"><b>Плавный переход между треками</b><small>Следующий трек вступает, пока текущий затихает. Работает, когда трек доигрывает до конца. «Выкл» — без перехода</small></div><input type="range" class="range" id="xf" min="0" max="12" step="1" value="${SND.xf}"><span class="range-val" id="xf-v">${xfLbl(SND.xf)}</span></div>
    <div class="row"><div class="lbl"><b>Скорость воспроизведения</b><small id="set-speed"></small></div><button class="btn sm" data-snd-open>Настроить</button></div>
    <div class="row"><div class="lbl"><b>Сохранять тон при смене скорости</b><small>Если выключить — эффект slowed / sped up: голос станет ниже или выше</small></div>${sw("keepPitch", SND.pitch)}</div>
    <div class="row"><div class="lbl"><b>Эквалайзер</b><small id="set-eq"></small></div><button class="btn sm" data-snd-open>Открыть эквалайзер</button></div></div>`}
  <div class="scard" data-tab="main"><h2>Источники музыки</h2><p>Треки берутся напрямую из открытых каталогов, без фильтров Яндекса. Можно отключить любой источник.</p>
    <div class="row"><div class="lbl"><b>SoundCloud</b><small>Полные треки (HLS AAC 160 кбит/с). client_id получается автоматически ${s.scAuto ? '— <span style="color:#3ecf8e">получен</span>' : ""}</small></div>${sw("sc", s.sources.soundcloud)}</div>
    <div class="row"><div class="lbl"><b>Свой client_id SoundCloud</b><small>Необязательно. Оставьте пустым для автоматического режима</small></div><input type="text" id="scid" placeholder="авто" value="${esc(s.scClientId)}"><button class="btn sm" id="sctest">Проверить</button></div>
    <div class="row"><div class="lbl"><b>Audius</b><small>Открытый каталог, полные треки, без ключей</small></div>${sw("au", s.sources.audius)}</div>
    <div class="row"><div class="lbl"><b>Заменять превью полной версией</b><small>Если на SoundCloud доступно только 30 сек (Go+) или трек защищён DRM, искать полную загрузку</small></div>${sw("autoMatch", s.autoMatch)}</div>
    <div class="row"><div class="lbl"><b>Лучшее качество</b><small>Если у загрузки на SoundCloud только AAC 96 кбит/с (частое у slowed / sped up), Wave ищет ту же запись в лучшем качестве — другую загрузку AAC 160 или Audius MP3 320. Качество видно в плеере рядом с источником</small></div>${sw("hq", s.hq !== false)}</div>
    <div class="row"><div class="lbl"><b>YouTube Music для треков с DRM</b><small>Экспериментально. Если SoundCloud отдаёт трек только с DRM, а на Audius/SoundCloud другой полной версии нет — играет официальная запись с YouTube Music (Opus ~130 / AAC 128 кбит/с). Сначала пробуется Яндекс Музыка с Плюсом, YouTube Music — последним</small></div>${sw("ytFallback", s.ytFallback !== false)}</div>
    ${root.hasAttribute("data-mobile") ? "" : `<div class="row"><div class="lbl"><b>Тексты с Genius</b><small>Порядок поиска: Яндекс Музыка → LRCLib → Genius (последним, без синхронизации)</small></div>${sw("genius", s.genius !== false)}</div>`}
</div>
  <div class="scard" data-tab="play"><h2>Моя волна</h2><p>Откуда берутся рекомендации. Настроение и характер работают для любого источника.</p>
    <div class="row"><div class="lbl"><b>Источник рекомендаций</b><small>«Wave» — персональные рекомендации Яндекса при подключённом аккаунте; иначе подходящие треки по вашим лайкам и истории. «По моим вкусам» — похожее на ваши лайки и любимых исполнителей. «Яндекс» — Моя волна вашего аккаунта (нужен вход). «Spotify» — по вашим топ-трекам и последним лайкам (Spotify закрыл API рекомендаций, поэтому похожие треки ищутся на SoundCloud). Треки Яндекса и Spotify играют через полные версии с SoundCloud/Audius</small></div>${segHtml(
      "waveSource",
      [
        ["wave", "Wave"],
        ["likes", "По моим вкусам"],
        ["yandex", "Яндекс"],
        ["spotify", "Spotify"],
      ],
      s.waveSource || "wave",
    )}</div>
    <div class="row"><div class="lbl"><b>Настроение и характер</b><small>Сейчас: ${esc((MOOD_LABEL[s.wave?.mood] || "Любое") + " · " + (Object.fromEntries(DIV)[s.wave?.diversity] || "Всё вперемешку"))}</small></div><button class="btn sm" id="wave-tune2">Настроить</button></div>
    <div class="row"><div class="lbl"><b>Слушатели на странице артиста</b><small>Откуда брать цифру: Яндекс — слушатели за месяц, Spotify / SoundCloud / Audius — подписчики</small></div>${segHtml(
      "artistStats",
      [
        ["yandex", "Яндекс"],
        ["spotify", "Spotify"],
        ["soundcloud", "SoundCloud"],
        ["audius", "Audius"],
      ],
      s.artistStats || "yandex",
    )}</div>
    <div class="row"><div class="lbl"><b>Баннер на странице артиста</b><small>${root.hasAttribute("data-mobile") ? "Широкая картинка в шапке артиста — из Яндекс Музыки или SoundCloud. Если у артиста на SoundCloud нет баннера — остаётся картинка Яндекса" : "Широкая картинка в шапке артиста — из Spotify (как в его приложении) или SoundCloud. Аватар остаётся из Яндекс Музыки. Если у артиста там нет баннера — берётся из другого источника, потом остаётся картинка Яндекса"}</small></div>${segHtml(
      "artistBanner",
      [
        ["yandex", "Яндекс"],
        ["soundcloud", "SoundCloud"],
        ...(root.hasAttribute("data-mobile") ? [] : [["spotify", "Spotify"]]),
      ],
      root.hasAttribute("data-mobile") && (s.artistBanner || "spotify") === "spotify" ? "soundcloud" : s.artistBanner || "spotify",
    )}</div></div>
  <div class="scard only-glass" data-tab="look"><h2>Анимация Моей волны</h2><p>Живое пятно на странице Моей волны: оно всё время перетекает и вздрагивает в такт музыке.</p>
    <div class="row"><div class="lbl"><b>Вид</b><small>«Wave» — своё пятно Wave. «Яндекс» — оригинальная анимация Моей волны из Яндекс Музыки. «Аура» — светящееся пятно из нескольких слоёв с тонкими сияющими краями, они колышутся в такт. Все настройки ниже работают для любого вида</small></div>${segHtml(
      "waveStyle",
      [
        ["classic", "Wave"],
        ["yandex", "Яндекс"],
        ["aura", "Аура"],
      ],
      s.waveStyle || "classic",
    )}</div>
    ${wfRow("shake", "Тряска", "Насколько сильно пятно вздрагивает на ударах", 0, 100)}
    ${wfRow("react", "Реакция на музыку", "Как сильно пятно растёт и ускоряется вместе с громкостью трека", 0, 100)}
    ${wfRow("size", "Размер", "Размер пятна", 60, 140)}
    <div class="row"><div class="lbl"><b>Тонкие светлые линии</b><small>Линии, которые летают вокруг пятна</small></div>${sw("wfxLines", wf.lines !== false)}</div>
    <div class="row"><div class="lbl"><b>Свои цвета на паузе</b><small>Пока трек играет, пятно в цветах его обложки (у треков Яндекс Музыки — из её палитры). На паузе волна возвращается к своим цветам и двигается спокойнее, как в Яндекс Музыке</small></div>${sw("waveColorPause", s.waveColorPause !== false)}</div>
    ${root.hasAttribute("data-mobile") ? "" : `<div class="row"><div class="lbl"><b>Фото артиста во время игры</b><small>Пока трек играет, на Моей волне — артист, вырезанный из фото (без фона). Берётся только аватар из карточки артиста, вырезается на этом компьютере и сохраняется. На паузе — как обычно</small></div>${sw("waveCutout", s.waveCutout !== false)}</div>
    <div class="row"><div class="lbl"><b>Строгость отбора фото</b><small>Фото без лица целиком, крупные планы во весь кадр, тёмные силуэты и фото, где человек упирается в края кадра, пропускаются. «Строгая» — только чистые портреты, «Мягкая» — вырезается почти всё, где есть человек</small></div>${segHtml(
      "cutStrict",
      [
        ["soft", "Мягкая"],
        ["normal", "Обычная"],
        ["strict", "Строгая"],
      ],
      s.cutStrict || "strict",
    )}</div>`}
    <div class="row"><div class="lbl"><b>Свечение справа</b><small>Мягкий свет, который освещает правую часть Моей волны в её цветах — а значит, в цветах играющего трека, как в Яндекс Музыке</small></div>${sw("waveGlow", s.waveGlow !== false)}</div>
    <div class="wgf-more${s.waveGlow !== false ? "" : " off"}">
    ${gfRow("power", "Яркость свечения", "0 — почти не видно, 100 — как в Яндекс Музыке, выше — ярче", 0, 150)}
    ${gfRow("reach", "Дальность", `Насколько далеко свет заходит от правого края ${root.hasAttribute("data-mobile") ? "на экран" : "в окно"}`, 30, 120)}
    ${gfRow("height", "Высота", `Какую часть ${root.hasAttribute("data-mobile") ? "экрана" : "окна"} по высоте занимает свет`, 60, 140)}
    ${gfRow("pulse", "Пульсация", "Как сильно и быстро свет «дышит». 0 — ровный свет", 0, 100)}</div>
    <div class="row"><div class="lbl"><b>По умолчанию</b><small>Вид Wave, тряска 0 %, реакция 0 %, размер 60 %, линии выключены, свои цвета на паузе${root.hasAttribute("data-mobile") ? "" : ", фото артиста, строгий отбор"}, свечение справа: яркость 100 %, дальность 86 %, высота 100 %, пульсация 50 %</small></div><button class="btn sm ghost" id="wfx-reset">Сбросить</button></div></div>
  <div class="scard" data-tab="acc"><h2>Яндекс Музыка</h2><p>Вход нужен для Моей волны вашего аккаунта, переноса лайков и плейлистов и текстов песен из Яндекса. По умолчанию треки играют через полные версии без цензуры с SoundCloud/Audius, а звук самой Яндекс Музыки (с Плюсом) — запасной; ниже можно поставить Яндекс первым и выбрать качество, вплоть до FLAC без потерь. Токен хранится зашифрованным только на этом ${root.hasAttribute("data-mobile") ? "телефоне" : "компьютере"}.</p>
    <div class="row"><div class="lbl"><b>${s.ymToken ? "Подключено" + (s.ymUser ? ": " + esc(s.ymUser) : "") : "Не подключено"}</b><small>${s.ymToken ? "Можно перенести лайки и плейлисты — повторный перенос добавит только новое" : "Откроется окно входа Яндекса (ID, пароль, QR или Яндекс Ключ)"}</small></div>${s.ymToken ? '<button class="btn sm acc" id="ym-import">Перенести лайки и плейлисты</button><button class="btn sm ghost" id="ym-out">Выйти</button>' : '<button class="btn sm acc" id="ym-login">Войти через Яндекс</button>'}</div>
    <div class="row"><div class="lbl"><b>Звук из Яндекс Музыки</b><small>Для треков, которые SoundCloud отдаёт только с DRM или которых нет на SoundCloud/Audius, а также для настроек ниже. Нужна подписка Плюс (без неё Яндекс отдаёт только 30 секунд — такие не используются)</small></div>${sw("ymStream", s.ymStream !== false)}</div>
    <div class="row"><div class="lbl"><b>Что играть сначала</b><small>«SoundCloud/Audius» — полные версии без цензуры, звук Яндекса только запасной. «Яндекс» — сразу официальный звук Яндекс Музыки (быстрее старт, точная версия), SoundCloud/Audius — если Яндекс не отдал</small></div>${segHtml(
      "ymPrefer",
      [
        ["free", "SoundCloud/Audius"],
        ["ym", "Яндекс"],
      ],
      s.ymPrefer || "free",
    )}</div>
    <div class="row"><div class="lbl"><b>Моя волна — сразу из Яндекса</b><small>Треки Моей волны аккаунта играют звуком Яндекс Музыки, даже если выше выбрано «SoundCloud/Audius». Лайки и пропуски по-прежнему учат волну</small></div>${sw("ymWaveDirect", s.ymWaveDirect === true)}</div>
    <div class="row"><div class="lbl"><b>Качество звука Яндекса</b><small>Lossless — FLAC без потерь, если он есть у трека (иначе MP3 320). Высокое — MP3 320. Экономия — около 192 кбит/с</small></div>${segHtml(
      "ymQuality",
      [
        ["lossless", "Lossless"],
        ["hq", "Высокое"],
        ["nq", "Экономия"],
      ],
      s.ymQuality || "hq",
    )}</div>
    <div class="row"><div class="lbl"><b>Синхронизировать лайки</b><small>Лайки, поставленные в Яндекс Музыке (в телефоне, на сайте), сами появляются в «Мне нравится» в Wave — проверка каждые 3 минуты. Снятые в Яндексе лайки убираются, если они пришли отсюда. Только в одну сторону: Wave ничего не меняет в аккаунте Яндекса — ни лайков, ни плейлистов, ни истории</small></div>${sw("ymLikesSync", s.ymLikesSync !== false)}</div>
    ${`<details class="row-more"><summary>${s.ymToken ? "Заменить токен вручную" : "Вставить токен вручную"}</summary><div class="row"><div class="lbl"><b>Токен OAuth</b><small>Если окно входа не открывается: «Получить» → войдите → скопируйте адрес из адресной строки целиком или только значение после access_token= (начинается с y0_)</small></div><input type="password" id="ymtok" placeholder="y0_…" autocomplete="off"><button class="btn sm" id="ym-save">Сохранить</button><button class="btn sm ghost" data-ext="https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d">Получить</button></div></details>`}</div>
  <div class="scard" data-tab="acc"><h2>Spotify</h2><p>Spotify не отдаёт сторонним приложениям сам аудиопоток, поэтому он используется как <b>библиотека</b>: ваши лайки, плейлисты и поиск. При воспроизведении Wave сам находит полную версию трека на SoundCloud/Audius.</p>
    <details class="row-more" id="spguide"><summary>Как подключить Spotify: инструкция</summary>
      <div class="row"><div class="lbl"><b>1. Откройте Spotify Developer</b><small>Войдите в свой Spotify и нажмите Create app. Название и описание можно выбрать самостоятельно. Для нового приложения Spotify требует Premium у владельца.</small></div><button class="btn sm ghost" type="button" data-ext="https://developer.spotify.com/dashboard/">Открыть сайт</button></div>
      <div class="row"><div class="lbl"><b>2. Укажите Redirect URI</b><small>Вставьте адрес ниже в Redirect URI, нажмите Add, выберите Web API и примите условия Spotify. Затем создайте приложение.</small><small class="code">${esc(s.spotifyRedirect)}</small></div><button class="btn sm ghost" type="button" id="sp-copy">Скопировать адрес</button></div>
      <div class="row"><div class="lbl"><b>3. Скопируйте Client ID</b><small>Откройте созданное приложение → Settings → Client ID. Вставьте 32 символа в поле ниже. Client Secret не нужен — никому его не отправляйте.</small></div></div>
      <div class="row"><div class="lbl"><b>4. Войдите и разрешите доступ</b><small>Используйте аккаунт владельца приложения. Для другого аккаунта добавьте его в Users and Access на сайте Spotify. Development Mode ограничен пятью пользователями.</small></div></div>
    </details>
    <div class="row"><div class="lbl"><b>Client ID</b><small>Нужен один раз. После входа Wave перенесёт ваши сохранённые треки в «Мне нравится».</small></div><input type="text" id="spid" placeholder="32 символа Client ID" value="${esc(s.spotifyClientId)}" autocomplete="off" autocapitalize="none" spellcheck="false"></div>
    <div class="row"><div class="lbl"><b>${S.spotify.connected ? "Подключено" + (S.spotify.name ? ": " + esc(S.spotify.name) : "") : "Не подключено"}</b><small>${S.spotify.product && S.spotify.product !== "premium" ? "Для Development Mode владельцу приложения нужен Premium" : ""}</small></div>
      ${S.spotify.connected ? '<button class="btn sm" id="spimport">Перенести лайки</button><button class="btn sm ghost" id="spout">Отключить</button>' : '<button class="btn sm acc" id="spin">Войти и перенести лайки</button>'}<button class="btn sm ghost" data-ext="https://developer.spotify.com/dashboard">Dashboard</button></div>
    <div class="row"><div class="lbl"><b>Показывать Spotify в поиске</b></div>${sw("sp", s.sources.spotify)}</div></div>
  <div class="scard" data-tab="acc"><h2>Импорт плейлистов</h2><p>Вставьте ссылку — Wave создаст плейлист в коллекции и для каждого трека подберёт полную версию <b>без цензуры</b> на SoundCloud (или Audius). Неверную версию можно заменить: ${root.hasAttribute("data-mobile") ? "удерживайте трек и выберите «Выбрать версию»" : "правый клик → «Выбрать версию»"}.</p>
    <div class="row"><div class="lbl"><b>Подбирать версии без цензуры при импорте</b><small>Подбор идёт в фоне и останавливается кнопкой «Остановить подбор» на странице плейлиста. Если выключить — треки играют как есть, подбор можно запустить вручную</small></div>${sw("autoMatchImport", s.autoMatchImport !== false)}</div>
    <div class="row"><div class="lbl"><b>Яндекс Музыка</b><small><span class="code">music.yandex.ru/users/ЛОГИН/playlists/3</span>, <span class="code">music.yandex.ru/playlists/lk.…</span>, альбом или трек. Плейлист должен быть публичным; «Мне нравится» — сделайте публичным в настройках Яндекса</small></div></div>
    <div class="row"><div class="lbl"><b>Spotify</b><small><span class="code">open.spotify.com/playlist/…</span>, альбом или трек. Без входа — первые 100 треков, с подключённым Spotify — ваши плейлисты целиком</small></div></div>
    <div class="row"><div class="lbl"><b>SoundCloud</b><small>Трек, плейлист, профиль или <span class="code">soundcloud.com/user/likes</span></small></div></div>
    <button class="btn acc" id="imp-btn" style="margin-top:8px">${icon("link")}Импорт по ссылке</button></div>
  <div class="scard" data-tab="main"><h2>О программе</h2><p>${root.hasAttribute("data-mobile") ? `Wave для Android ${esc(S.version || "")}. Независимый клиент, не связан с Яндексом, SoundCloud, Audius или Spotify.` : `Wave Desktop ${esc(S.version || "")} · независимый клиент. Не связан с Яндексом, SoundCloud, Audius или Spotify.`}${root.hasAttribute("data-mobile") ? "" : " Горячие клавиши: Пробел — пауза, ←/→ — перемотка, ↑/↓ — громкость, Ctrl+←/→ — трек, Ctrl+F — поиск, Shift+, / Shift+. — скорость, Esc — свернуть плеер."}</p></div></div>`);
  const save = async (patch) => {
    S.settings = await api("settings", patch);
    applySettings();
  };
  // 4.21: меньше настроек на телефоне — «Основные» держат оформление и пару переключателей,
  // всё остальное переезжает во вкладку «Дополнительно». Карточки не переписываются: строки
  // переносятся в новые карточки до навешивания обработчиков ниже, десктоп не затронут.
  if (mob) {
    const st = $(".settings");
    if (st) {
      const rowOf = (sel) => [...st.querySelectorAll(".scard .row")].find((r) => r.querySelector(sel));
      const grab = (name, hint, ...sels) => {
        const card = document.createElement("div");
        card.className = "scard";
        card.dataset.tab = "main";
        card.innerHTML = `<h2>${name}</h2><p>${hint}</p>`;
        for (const sel of sels) {
          const r = rowOf(sel);
          if (r) card.appendChild(r);
        }
        st.prepend(card);
        return card;
      };
      // качество звука: два ключевых переключателя источников
      grab(
        "Качество звука",
        "Полные версии вместо 30-секундных превью и лучший битрейт.",
        '[data-sw="autoMatch"]',
        '[data-sw="hq"]',
      );
      // оформление: интерфейс, полноэкранный плеер, акцент, вид и тема (классы only-glass/only-classic сохраняются)
      grab(
        "Оформление",
        "Как выглядит Wave: оформление, интерфейс, цвет акцента и полноэкранный плеер.",
        '[data-seg="ui"]',
        '[data-seg="player"]',
        '[data-seg="accent"]',
        '[data-seg="skin"]',
        '[data-seg="theme"]',
      );
      // 4.20.2: четыре вкладки — Основные · Кастомизация · Подключения · Дополнительно
      const TAB_OF = { main: "main", look: "look", acc: "acc", play: "more", privacy: "main" };
      const cards = [...st.querySelectorAll(".scard")];
      const known = new Set(cards);
      const nameOf = (c) => (c.querySelector("h2")?.textContent || "").trim();
      const byName = (n) => [...st.querySelectorAll(".scard")].find((c) => nameOf(c) === n);
      for (const c of cards) {
        const h = nameOf(c);
        if (h === "Оформление") c.dataset.tab = "look";
        else if (h === "Качество звука") c.dataset.tab = "main";
        else if (h === "О программе") c.dataset.tab = "more";
        else c.dataset.tab = TAB_OF[c.dataset.tab] || "more";
      }
      // профиль и его приватность — в самом верху «Основных»
      const prof = byName("Профиль"), priv = byName("Приватность профиля");
      if (priv) st.prepend(priv);
      if (prof) st.prepend(prof);
      // строки «Сообщить об ошибке» и «Проверить обновления» (report.js)
      if (window.waveExtraSettings) try { window.waveExtraSettings(st) } catch {}
      // «О программе» и служебные карточки — в самом низу «Дополнительно»
      const about = byName("О программе");
      if (about) st.appendChild(about);
      for (const c of [...st.querySelectorAll(".scard")]) {
        if (known.has(c)) continue;
        c.dataset.tab = "more";
        st.appendChild(c);
      }
    }
  }
  showSetTab(tab);
  $$("[data-privacy]").forEach(
    (b) =>
      (b.onclick = () => {
        const privacy = profilePrivacy();
        privacy[b.dataset.privacy] = privacy[b.dataset.privacy] === false;
        localStorage.setItem("wave.profilePrivacy", JSON.stringify(privacy));
        b.classList.toggle("on", privacy[b.dataset.privacy]);
        window.WaveSocial?.privacyChanged();
      }),
  );
  window.WaveSocial?.mountSettings();
  $$("[data-stab]").forEach((b) => (b.onclick = () => showSetTab(b.dataset.stab, true)));
  $$("[data-wfx]").forEach((r) => {
    const paint = () => {
      $("#wfx-" + r.dataset.wfx).textContent = r.value + " %";
      WaveFx.setOpts({ ...S.settings.waveFx, [r.dataset.wfx]: +r.value });
    };
    r.oninput = paint;
    r.onchange = () => save({ waveFx: { [r.dataset.wfx]: +r.value } });
  });
  $$("[data-wgf]").forEach((r) => {
    r.oninput = () => {
      $("#wgf-" + r.dataset.wgf).textContent = r.value + " %";
      applyWaveGlow({ ...glowOpts(), [r.dataset.wgf]: +r.value });
    };
    r.onchange = () => save({ waveGlowFx: { [r.dataset.wgf]: +r.value } });
  });
  $$("[data-lq]").forEach((r) => {
    r.oninput = () => {
      $("#lq-" + r.dataset.lq).textContent = r.value + " %";
      applyLiquid({ ...liquidOpts(), [r.dataset.lq]: +r.value });
    };
    r.onchange = () => save({ liquid: { [r.dataset.lq]: +r.value } });
  });
  $("#lq-reset").onclick = async () => {
    await save({ liquid: LIQUID_DEF });
    const top = $("#content").scrollTop;
    settingsView();
    $("#content").scrollTop = top;
  };
  $("#wfx-reset").onclick = async () => {
    await save({
      waveFx: { ...WFX_DEF },
      waveStyle: "classic",
      waveColorPause: true,
      waveCutout: true,
      cutStrict: "strict",
      waveGlow: true,
      waveGlowFx: { ...GLOW_DEF },
    });
    CUT.cache.clear();
    waveCut(true);
    waveRamp(true);
    applyWaveGlow();
    const top = $("#content").scrollTop;
    settingsView();
    $("#content").scrollTop = top;
  };
  $("#nick").onchange = (e) => save({ profile: { nick: e.target.value.trim() || "Слушатель" } });
  const xfEl = $("#xf");
  if (xfEl) {
    xfEl.oninput = (e) => {
      SND.xf = +e.target.value;
      $("#xf-v").textContent = xfLbl(SND.xf);
    };
    xfEl.onchange = (e) => save({ crossfade: +e.target.value });
  }
  $$("[data-snd-open]").forEach((b) => (b.onclick = () => openSound(b)));
  syncSndBtn();
  $("#pick-avatar").onclick = async () => {
    if (await pickProfileImage("avatar")) settingsView();
  };
  $("#pick-banner").onclick = async () => {
    if (await pickProfileImage("banner")) settingsView();
  };
  const rm = (k) => async () => {
    await save({ profile: { [k]: null } });
    settingsView();
  };
  if ($("#rm-avatar")) $("#rm-avatar").onclick = rm("avatar");
  if ($("#rm-banner")) $("#rm-banner").onclick = rm("banner");
  $$("[data-seg] button").forEach(
    (b) =>
      (b.onclick = async () => {
        const k = b.parentElement.dataset.seg;
        b.parentElement.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
        await save({ [k]: b.dataset.v });
        if (k === "cutStrict") {
          CUT.cache.clear();
          waveCut(true);
        }
        if (k === "glassFx") {
          const top = $("#content").scrollTop;
          settingsView();
          $("#content").scrollTop = top;
        }
      }),
  );
  $$("[data-sw]").forEach(
    (b) =>
      (b.onclick = async () => {
        const k = b.dataset.sw,
          on = !b.classList.contains("on");
        b.classList.toggle("on", on);
        if (k === "sc") await save({ sources: { soundcloud: on } });
        else if (k === "au") await save({ sources: { audius: on } });
        else if (k === "sp") await save({ sources: { spotify: on } });
        else if (k === "wfxLines") await save({ waveFx: { lines: on } });
        else if (k.startsWith("lq:")) {
          await save({ liquid: { [k.slice(3)]: on } });
          if (k === "lq:on") $(".lq-more")?.classList.toggle("off", !on);
        } else await save({ [k]: on });
        if (k === "waveCutout") waveCut(true);
        if (k === "waveColorPause") waveRamp(true);
        if (k === "waveGlow") {
          applyWaveGlow();
          $(".wgf-more")?.classList.toggle("off", !on);
        }
        if (k === "autostart") toast(on ? "Wave будет запускаться вместе с Windows" : "Автозапуск выключен");
        if (k === "gpu")
          toast("Аппаратное ускорение " + (on ? "включится" : "отключится") + " после перезапуска Wave", 5000);
      }),
  );
  $("#scid").onchange = (e) => save({ scClientId: e.target.value.trim() });
  $("#sctest").onclick = async () => {
    try {
      await save({ scClientId: $("#scid").value.trim() });
      const r = await api("sc-test");
      toast("SoundCloud работает, client_id " + r.clientId);
    } catch (e) {
      toast("SoundCloud: " + e.message);
    }
  };
  $("#sp-copy").onclick = async () => {
    const ok = await api("copy-text", { text: s.spotifyRedirect }).catch(() => false);
    toast(ok ? "Адрес скопирован" : "Не удалось скопировать адрес");
  };
  $("#spid").onchange = (e) => save({ spotifyClientId: e.target.value.trim() });
  if ($("#spin"))
    $("#spin").onclick = async () => {
      const id = $("#spid").value.trim();
      if (!/^[a-f0-9]{32}$/i.test(id)) {
        $("#spguide").open = true;
        $("#spguide").scrollIntoView({ block: "start", behavior: "smooth" });
        toast("Сначала создайте приложение Spotify и вставьте Client ID по инструкции", 6500);
        return;
      }
      const btn = $("#spin"); btn.disabled = true;
      try {
        await save({ spotifyClientId: id });
        S.spotify = await api("spotify-login");
        toast("Spotify подключён. Переношу лайки…", 3500);
        try {
          const r = await api("spotify-import-likes");
          setLikes(r.likes);
          toast("Spotify подключён. Добавлено треков: " + r.added, 6500);
        } catch (err) {
          toast("Spotify подключён, но лайки не перенесены: " + err.message, 9000);
        }
        settingsView();
      } catch (e) {
        toast(e.message, 7000);
      } finally { btn.disabled = false; }
    };
  if ($("#spout"))
    $("#spout").onclick = async () => {
      S.spotify = await api("spotify-logout");
      settingsView();
    };
  if ($("#spimport"))
    $("#spimport").onclick = async () => {
      toast("Загружаю лайки Spotify…");
      try {
        const r = await api("spotify-import-likes");
        setLikes(r.likes);
        toast("Перенесено треков: " + r.added);
      } catch (e) {
        toast(e.message);
      }
    };
  $("#imp-btn").onclick = () => promptDialog("Ссылка на плейлист (Яндекс Музыка, Spotify, SoundCloud)", "", importUrl);
  const sbw = $("#sbw");
  sbw.oninput = () => {
    setSidebar(+sbw.value);
    $("#sbw-v").textContent = sbw.value + " px";
  };
  sbw.onchange = () => save({ sidebarWidth: +sbw.value });
  $("#pick-gif").onclick = async () => {
    try {
      const r = await api("pick-gif");
      if (r) {
        S.settings = r;
        applySettings();
        settingsView();
      }
    } catch (e) {
      toast(e.message);
    }
  };
  if ($("#rm-gif"))
    $("#rm-gif").onclick = async () => {
      await save({ progressGif: null });
      settingsView();
    };
  const gs = $("#gifsz");
  if (gs) {
    gs.oninput = () => {
      root.style.setProperty("--gif", gs.value + "px");
      $("#gifsz-v").textContent = gs.value + " px";
    };
    gs.onchange = () => save({ progressGifSize: +gs.value });
  }
  $("#wave-tune2").onclick = tuneWave;
  if ($("#ym-login"))
    $("#ym-login").onclick = async () => {
      try {
        const r = await api("ym-login");
        S.settings = await api("settings", {});
        LY.cache.clear();
        toast("Яндекс подключён" + (r.user ? ": " + r.user : "") + (r.warn ? " (" + r.warn + ")" : ""), 5000);
        settingsView();
      } catch (e) {
        toast(e.message, 5000);
      }
    };
  if ($("#ym-import"))
    $("#ym-import").onclick = async (e) => {
      const b = e.currentTarget;
      b.disabled = true;
      b.textContent = "Переношу…";
      try {
        const r = await api("ym-import", {});
        await reloadLib();
        toast(
          `Перенесено: ${plural(r.likes, "новый лайк", "новых лайка", "новых лайков")}, ${plural(r.playlists, "плейлист", "плейлиста", "плейлистов")}` +
            (r.errors?.length ? ". Ошибки: " + r.errors.slice(0, 2).join("; ") : "") +
            (S.settings.autoMatchImport !== false && r.playlists ? ". Версии без цензуры подбираются в фоне" : ""),
          8000,
        );
      } catch (err) {
        toast("Яндекс: " + err.message, 6000);
      }
      b.disabled = false;
      b.textContent = "Перенести лайки и плейлисты";
    };
  if ($("#ym-save"))
    $("#ym-save").onclick = async () => {
      try {
        const r = await api("ym-token", { token: $("#ymtok").value.trim() });
        S.settings = await api("settings", {});
        LY.cache.clear();
        toast(
          r.warn
            ? "Токен сохранён, но Яндекс ответил: " + r.warn
            : "Токен сохранён" +
                (r.user ? " — " + r.user : "") +
                (r.plus === false ? ". Плюса нет — звук Яндекса будет недоступен" : ""),
          5000,
        );
        settingsView();
      } catch (e) {
        toast(e.message);
      }
    };
  if ($("#ym-out"))
    $("#ym-out").onclick = async () => {
      await api("ym-logout");
      S.settings = await api("settings", {});
      settingsView();
    };
}
async function importUrl(url) {
  toast("Импортирую плейлист…", 30000);
  try {
    const r = await api("import-url", { url });
    await reloadLib();
    const auto = S.settings.autoMatchImport !== false;
    toast(
      r.note ||
        "Импортировано " +
          plural(r.count, "трек", "трека", "треков") +
          (r.kind !== "soundcloud"
            ? auto
              ? ". Подбираю версии без цензуры… (можно остановить)"
              : ". Подбор без цензуры выключен в настройках"
            : ""),
      r.note ? 9000 : 5000,
    );
    go("playlist:" + r.id);
  } catch (e) {
    toast("Импорт не удался: " + e.message, 7000);
  }
}
// «Выбрать версию»: any full SoundCloud/Audius upload, or back to the original («Исходный вариант»)
function chooseVersion(t) {
  const own = /^(sc|au):/.test(t.id);
  const applied = (match) => {
    if (S.route?.startsWith("playlist:")) reroute();
    if (S.current?.id === t.id) switchVersion(t, match);
    else toast("Версия сохранена");
  };
  const select = async (d, match) => {
    d.querySelectorAll("button").forEach((b) => (b.disabled = true));
    try {
      await api("set-match", { track: t, match });
      d.close();
      applied(match);
    } catch (e) {
      d.querySelectorAll("button").forEach((b) => (b.disabled = false));
      toast("Не удалось сохранить версию: " + e.message, 5000);
    }
  };
  dialog(
    `<h3>Выбрать версию</h3><p class="muted" style="margin-bottom:12px">${esc(t.artist + " — " + t.title)}</p><button class="pin orig" id="c-orig"><span class="pc" ${bg(t.cover, "s")}>${t.cover ? "" : icon("note")}</span><span><b>Исходный вариант</b><small>${own ? "Играть сам трек, без замены" : "Подбирать полную версию автоматически"}</small></span><i class="cur-mark" hidden>${icon("check")}</i></button><div id="cands">${skel(4)}</div><div class="acts"><button class="btn" data-close>Закрыть</button></div>`,
    async (d) => {
      d.querySelector("#c-orig").blur(); // the dialog focuses the first button, which looked like a selection
      d.querySelector("#c-orig").onclick = () => select(d, null);
      try {
        const r = await api("match-candidates", { track: t });
        const list = Array.isArray(r) ? r : r.list || [];
        const current = Array.isArray(r) ? null : r.current;
        const box = d.querySelector("#cands");
        const orig = d.querySelector("#c-orig .cur-mark");
        orig.hidden = !(own ? !current || r.original : !r.picked);
        if (!list.length) {
          box.innerHTML = '<div class="empty">Ничего не нашлось</div>';
          return;
        }
        // 4.15: versions of Yandex Music (YM) — they play through the account with Plus
        const ymLock = (c) => c.source === "yandex" && r.ymReady === false;
        const ymNote = (c) =>
          c.source !== "yandex"
            ? ""
            : ymLock(c)
              ? " · нужен вход в Яндекс"
              : c.id === t.id
                ? " · из Яндекс Музыки"
                : "";
        box.innerHTML =
          list
            .map(
              (c, i) =>
                `<button class="pin${c.id === current ? " cur" : ""}${ymLock(c) ? " ym-lock" : ""}" data-ci="${i}"><span class="pc" ${bg(c.cover, "s")}></span><span><b>${esc(c.title)}</b><small><span class="src ${c.source}">${SRC[c.source] || ""}</span>${esc(c.artist)} · ${fmt(c.duration)}${ymNote(c)}${c.id === current ? " · сейчас" : ""}</small></span>${c.id === current ? `<i class="cur-mark">${icon("check")}</i>` : ""}</button>`,
            )
            .join("") +
          (list.some(ymLock)
            ? '<p class="cv-hint">Версии из Яндекс Музыки (YM) играют после входа в Яндекс с Плюсом — Настройки → Подключения</p>'
            : "");
        box.querySelectorAll("[data-ci]").forEach(
          (b) =>
            (b.onclick = async () => {
              const c = list[+b.dataset.ci];
              if (ymLock(c)) return toast("Нужен вход в Яндекс Музыку с Плюсом: Настройки → Подключения", 5000);
              await select(d, c);
            }),
        );
      } catch (e) {
        d.querySelector("#cands").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
      }
    },
  );
}

/* ---------------- dialogs & menus ---------------- */
// 4.15: a click on the free area around any window (the backdrop) closes it — the press and the release
// both have to be outside, so selecting text in a field and letting go outside does not close it
const DLG = { out: false, armed: false };
function dialogOutside(d, e) {
  if (e.target !== d) return false;
  const r = d.getBoundingClientRect();
  return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom;
}
function dialogArm(d) {
  if (DLG.armed) return;
  DLG.armed = true;
  d.addEventListener("pointerdown", (e) => (DLG.out = dialogOutside(d, e)));
  d.addEventListener("click", (e) => {
    const out = DLG.out && dialogOutside(d, e);
    DLG.out = false;
    if (out && d.open) d.close();
  });
}
function dialog(html, bind) {
  const d = $("#dialog");
  dialogArm(d);
  d.className = "dialog";
  d.innerHTML = html;
  d.querySelectorAll("[data-close]").forEach((b) => (b.onclick = () => d.close()));
  if (!d.open) d.showModal();
  bind && bind(d);
}
// 4.10: a confirmation in the style of Wave instead of the system window → Promise<boolean>
function confirmDialog({ title, text = "", ok = "OK", cancel = "Отмена", danger = false } = {}) {
  return new Promise((res) => {
    let done = false;
    const fin = (v) => {
      if (done) return;
      done = true;
      res(v);
    };
    dialog(
      `<div class="cf-head">${danger ? `<span class="cf-ic">${icon("trash")}</span>` : ""}<h3>${esc(title)}</h3></div>${text ? `<p class="cf-text">${esc(text)}</p>` : ""}<div class="acts"><button class="btn" data-close>${esc(cancel)}</button><button class="btn ${danger ? "danger" : "acc"}" id="cf-ok">${esc(ok)}</button></div>`,
      (d) => {
        d.classList.add("confirm");
        const b = d.querySelector("#cf-ok");
        b.onclick = () => {
          fin(true);
          d.close();
        };
        d.addEventListener("close", () => fin(false), { once: true });
        b.focus();
      },
    );
  });
}
function promptDialog(title, value, cb) {
  dialog(
    `<h3>${esc(title)}</h3><input class="field" id="pv" value="${esc(value)}"><div class="acts"><button class="btn" data-close>Отмена</button><button class="btn acc" id="pok">Готово</button></div>`,
    (d) => {
      const i = d.querySelector("#pv");
      i.focus();
      i.select();
      const ok = () => {
        const v = i.value.trim();
        if (v) {
          d.close();
          cb(v);
        }
      };
      d.querySelector("#pok").onclick = ok;
      i.onkeydown = (e) => {
        if (e.key === "Enter") ok();
      };
    },
  );
}
function newPlaylistDialog(tracks = []) {
  dialog(
    `<h3>Новый плейлист</h3><input class="field" id="pv" placeholder="Название"><p class="muted" style="margin:14px 0 8px">или вставьте ссылку на плейлист Яндекс Музыки, Spotify или SoundCloud</p><input class="field" id="pu" placeholder="https://music.yandex.ru/users/…/playlists/…"><div class="acts"><button class="btn" data-close>Отмена</button><button class="btn acc" id="pok">Создать</button></div>`,
    (d) => {
      d.querySelector("#pv").focus();
      d.querySelector("#pok").onclick = async () => {
        const url = d.querySelector("#pu").value.trim();
        const t = d.querySelector("#pv").value.trim();
        d.close();
        if (url) return importUrl(url);
        const p = await api("playlist-create", {
          title: t || "Новый плейлист",
          tracks: Array.isArray(tracks) ? tracks : [],
        });
        await reloadLib();
        go("playlist:" + p.id);
      };
    },
  );
}
// items: "-" | [label, icon, fn] | [label, icon, subItems[]] (4.10: a submenu, opens to the side on hover / click)
const menuHtml = (items) =>
  items
    .map((it, i) =>
      it === "-"
        ? "<hr>"
        : `<button data-mi="${i}"${Array.isArray(it[2]) ? ' class="has-sub" aria-haspopup="menu"' : ""}>${icon(it[1])}<span class="mi-l">${esc(it[0])}</span>${Array.isArray(it[2]) ? icon("right", "mi-chev") : ""}</button>`,
    )
    .join("");
function subMenuEl() {
  let sm = $("#menu-sub");
  if (!sm) {
    sm = document.createElement("div");
    sm.id = "menu-sub";
    sm.className = "menu sub";
    sm.hidden = true;
    $("#menu").after(sm);
  }
  return sm;
}
function hideSubMenu() {
  const sm = $("#menu-sub");
  if (sm) sm.hidden = true;
  $$("#menu .has-sub.open").forEach((b) => b.classList.remove("open"));
}
function openSubMenu(btn, items) {
  const sm = subMenuEl();
  $$("#menu .has-sub.open").forEach((b) => b.classList.toggle("open", b === btn));
  btn.classList.add("open");
  sm.className = "menu sub" + (items.length > 9 ? " tall" : "");
  sm.innerHTML = menuHtml(items);
  sm.hidden = false;
  const b = btn.getBoundingClientRect(),
    m = $("#menu").getBoundingClientRect(),
    r = sm.getBoundingClientRect();
  let x = m.right + 4;
  if (x + r.width > innerWidth - 8) x = Math.max(8, m.left - r.width - 4);
  let y = b.top - 7;
  if (y + r.height > innerHeight - 8) y = Math.max(8, innerHeight - 8 - r.height);
  sm.style.left = x + "px";
  sm.style.top = y + "px";
  sm.querySelectorAll("[data-mi]").forEach(
    (x) =>
      (x.onclick = () => {
        $("#menu").hidden = true;
        hideSubMenu();
        items[+x.dataset.mi][2]();
      }),
  );
}
function menu(e, items) {
  e.preventDefault();
  e.stopPropagation();
  hideSubMenu();
  const m = $("#menu");
  m.className = "menu";
  m.innerHTML = menuHtml(items);
  m.hidden = false;
  const r = m.getBoundingClientRect();
  let x = e.clientX,
    y = e.clientY;
  const anchor = e.target?.closest?.("button") || (e.currentTarget?.getBoundingClientRect ? e.currentTarget : null);
  if (!x && !y && anchor) {
    const b = anchor.getBoundingClientRect();
    x = b.left;
    y = b.bottom + 6;
  }
  if (x + r.width > innerWidth) x = innerWidth - r.width - 8;
  if (y + r.height > innerHeight - 10) y = Math.max(8, y - r.height);
  m.style.left = x + "px";
  m.style.top = y + "px";
  let hov = 0;
  m.querySelectorAll("[data-mi]").forEach((b) => {
    const it = items[+b.dataset.mi];
    if (Array.isArray(it[2])) {
      b.onclick = (ev) => {
        ev.stopPropagation();
        openSubMenu(b, it[2]);
      };
      b.onpointerenter = () => {
        clearTimeout(hov);
        hov = setTimeout(() => !m.hidden && openSubMenu(b, it[2]), 140);
      };
      b.onpointerleave = () => clearTimeout(hov);
      return;
    }
    b.onpointerenter = () => {
      clearTimeout(hov);
      hov = setTimeout(hideSubMenu, 160);
    };
    b.onclick = () => {
      m.hidden = true;
      hideSubMenu();
      it[2]();
    };
  });
}
document.addEventListener(
  "click",
  (e) => {
    if (!e.target.closest("#menu, #menu-sub")) {
      $("#menu").hidden = true;
      hideSubMenu();
    }
  },
  true,
);
// the submenu closes together with the menu (Esc, scrolling, another click…)
new MutationObserver(() => $("#menu").hidden && hideSubMenu()).observe($("#menu"), {
  attributes: true,
  attributeFilter: ["hidden"],
});
/* 4.10: a shorter track menu — wave by the track, the source of recommendations and «Добавить в плейлист» are
   submenus; «О треке», «Не рекомендовать» and «Играть следующим» are gone (the track page / the player have them) */
function trackMenu(e, t) {
  const src = S.settings?.waveSource || "wave";
  const items = [];
  if (!t.pod) items.push(["Микс", "mix", () => addGlobalMix(t)]);
  if (!t.pod)
    items.push(
      ["Моя волна по треку", "wave", () => startWave({ seed: t })],
      [
        "Рекомендации из",
        "tune",
        WAVE_SRC.map(([k, v]) => [
          v,
          k === src ? "check" : "blank",
          async () => {
            if (k !== (S.settings.waveSource || "wave")) S.settings = await api("settings", { waveSource: k });
            startWave({ seed: t });
          },
        ]),
      ],
      "-",
    );
  items.push(
    [
      window.WaveSocial?.inRoom() ? "Предложить в очередь комнаты" : "Добавить в очередь",
      "queue",
      () => {
        if (window.WaveSocial?.inRoom()) { window.WaveSocial.proposeTrack(t).catch((e) => toast(e.message, 5000)); return; }
        S.queue.push(t);
        renderQueue();
        toast("Добавлено в очередь");
      },
    ],
    [S.likeSet.has(t.id) ? "Убрать из «Мне нравится»" : "Мне нравится", "heart", () => toggleLike(t)],
    ["Не рекомендовать", "dislike", () => dislike(t)],
    [
      "Добавить в плейлист",
      "plus",
      [
        ["Новый плейлист…", "plus", () => newPlaylistDialog([t])],
        ...(S.playlists.length ? ["-"] : []),
        ...S.playlists.map((p) => [
          p.title,
          "note",
          async () => {
            await api("playlist-add", { id: p.id, tracks: [t] });
            await reloadLib();
            toast("Добавлено в «" + p.title + "»");
          },
        ]),
      ],
    ],
  );
  if (S.route?.startsWith("playlist:") && S.openPlaylist)
    items.push([
      "Убрать из этого плейлиста",
      "close",
      async () => {
        await api("playlist-remove-track", { id: S.openPlaylist, track: t.id });
        await reloadLib();
        reroute();
      },
    ]);
  items.push("-");
  const al = albumOf(t);
  if (al && S.route !== "rplaylist:yma:" + al.album) items.push(["Перейти к альбому", "album", () => openTrack(t)]);
  const a = artistList(t)[0];
  if (a && a.name !== NO_ARTIST) items.push(["Перейти к исполнителю", "user", () => openArtist(a.id || "", a.name)]);
  if (S.current && t.id === S.current.id)
    items.push(["Настройки звука", "eq", () => sndOpen() || openSound(e.target?.closest?.("button"))]);
  if (t.link) items.push(["Открыть в " + SRC_NAME[t.source], "link", () => api("open-external", { url: t.link })]);
  if (t.source !== "local" && !t.pod) items.push(["Выбрать версию", "tune", () => chooseVersion(t)]);
  menu(e, items);
}
const openArtist = (id, name) => go("artist:" + id + "|" + encodeURIComponent(name || ""));
// 4.11: «Анимация Моей волны» by default — calm: no shake, no reaction, a smaller spot, no lines
const WFX_DEF = { shake: 10, react: 60, size: 110, lines: false };
/* ---------------- colours from the cover ---------------- */
const DEFAULT_RAMP = ["#3d0a4f", "#c2127e", "#ff5a36", "#ffd400"];
// 4.10: «Аркейн» — red and black, the own colours of the glow too
const ARCANE_RAMP = ["#160205", "#6e0a16", "#d81b2b", "#ff6a4d"];
// 4.15: «Изумруд» (green) and «Сакура» (pink) — two more full palettes like «Аркейн»
const EMERALD_RAMP = ["#021208", "#0a4d2a", "#12b866", "#9dffb0"];
const SAKURA_RAMP = ["#16030d", "#6b0f3d", "#ff4f9a", "#ffc2dc"];
const OWN_RAMPS = { arcane: ARCANE_RAMP, emerald: EMERALD_RAMP, sakura: SAKURA_RAMP };
// 4.20: the «Wave» skin of the phone — the brand colours (night violet → violet → lavender → pink) instead of the
// heat colours of the Yandex look
const WAVE_RAMP = ["#0d0826", "#4c1d95", "#9d5cff", "#ff7ad9"];
const ownRamp = () =>
  (isGlass() && OWN_RAMPS[root.dataset.accent]) ||
  (isGlass() && root.hasAttribute("data-mobile") && root.dataset.skin === "wave" ? WAVE_RAMP : DEFAULT_RAMP);
const hx = (h) => {
  const n = parseInt(String(h).slice(1, 7), 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const rgbHex = (r, g, b) =>
  "#" +
  [r, g, b]
    .map((v) =>
      Math.max(0, Math.min(255, Math.round(v)))
        .toString(16)
        .padStart(2, "0"),
    )
    .join("");
function toHsl([r, g, b]) {
  ((r /= 255), (g /= 255), (b /= 255));
  const mx = Math.max(r, g, b),
    mn = Math.min(r, g, b),
    l = (mx + mn) / 2;
  let h = 0,
    s = 0;
  if (mx !== mn) {
    const d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h *= 60;
  }
  return [h, s, l];
}
function fromHsl(h, s, l) {
  h = (((h % 360) + 360) % 360) / 360;
  const f = (p, q, t) => {
    t = (t + 1) % 1;
    return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p;
  };
  if (!s) return rgbHex(l * 255, l * 255, l * 255);
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s,
    p = 2 * l - q;
  return rgbHex(f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255);
}
const satCols = (pal) =>
  (pal?.colors || []).map((c) => toHsl(hx(c))).filter((c) => c[1] > 0.2 && c[2] > 0.08 && c[2] < 0.94);
// 4.6: Yandex Music tracks carry the cover palette («derivedColors»): the glow uses it like Yandex does —
// average (dark base) → accent → mini-player colour → wave text colour (the bright core)
function rampFromYm(c) {
  const h = (v, d) => (v ? toHsl(hx(v)) : d);
  const a = h(c.accent, h(c.average)),
    avg = h(c.average, a),
    mp = h(c.miniPlayer, a),
    wt = h(c.waveText, [a[0], a[1], 0.86]);
  const L = (l, lo, hi) => Math.min(hi, Math.max(lo, l));
  const S2 = (x) => Math.min(1, x * 1.15);
  return [
    fromHsl(avg[0], S2(Math.max(avg[1], a[1] * 0.8)), 0.17),
    fromHsl(a[0], S2(a[1]), L(a[2], 0.4, 0.52)),
    fromHsl(mp[0], S2(mp[1]), L(mp[2], 0.56, 0.68)),
    fromHsl(wt[0], S2(wt[1]), L(wt[2], 0.72, 0.86)),
  ];
}
function rampFrom(pal) {
  if (!pal) return ownRamp();
  if (pal.ym) return rampFromYm(pal.ym);
  const cols = satCols(pal);
  if (!cols.length) {
    const g = pal.grey ? toHsl(hx(pal.grey)) : [250, 0, 0.5];
    return [fromHsl(g[0], 0.06, 0.12), fromHsl(g[0], 0.07, 0.36), fromHsl(g[0], 0.06, 0.62), "#f2f1f6"];
  }
  let hs = cols.slice(0, 3);
  if (hs.length === 1) hs = [hs[0], [hs[0][0], hs[0][1], hs[0][2] + 0.1], [hs[0][0], hs[0][1], hs[0][2] + 0.2]];
  else if (hs.length === 2) hs = [hs[0], hs[1], [hs[1][0], hs[1][1], hs[1][2] + 0.15]];
  hs.sort((a, b) => a[2] - b[2]);
  const sat = (s) => Math.min(1, Math.max(0.62, s * 1.3));
  return [
    fromHsl(hs[0][0], sat(hs[0][1]), 0.17),
    fromHsl(hs[0][0], sat(hs[0][1]), 0.44),
    fromHsl(hs[1][0], sat(hs[1][1]), 0.56),
    fromHsl(hs[2][0], sat(hs[2][1]), 0.67),
  ];
}
// accent «из обложки»: the most colourful of the big areas (colours come sorted by area); a black-and-white
// cover gives a light neutral accent instead of the default violet (4.6)
function accentFrom(pal) {
  if (!pal) return null;
  let cols;
  if (pal.ym) cols = [pal.ym.accent, pal.ym.miniPlayer].filter(Boolean).map((c, i) => ({ c: toHsl(hx(c)), i }));
  else
    cols = (pal.colors || [])
      .map((c, i) => ({ c: toHsl(hx(c)), i }))
      .filter(({ c }) => c[1] > 0.2 && c[2] > 0.08 && c[2] < 0.94);
  const score = ({ c, i }) => c[1] * (1 - Math.abs(c[2] - 0.5)) * (1 - 0.13 * Math.min(i, 5));
  cols = cols.filter(({ c }) => c[1] > 0.16).sort((a, b) => score(b) - score(a));
  if (!cols.length) {
    const g = pal.ym?.average ? toHsl(hx(pal.ym.average)) : pal.grey ? toHsl(hx(pal.grey)) : [240, 0, 0.5];
    return [fromHsl(g[0], Math.min(0.12, g[1]), 0.82), fromHsl(g[0], Math.min(0.08, g[1]), 0.92)];
  }
  const [h, s] = cols[0].c;
  return [fromHsl(h, Math.min(0.9, Math.max(0.55, s)), 0.66), fromHsl(h, Math.min(0.85, Math.max(0.5, s)), 0.84)];
}
let palSeq = 0;
async function loadPalette(url, ym) {
  const my = ++palSeq;
  let pal = null;
  if (ym?.accent || ym?.average) pal = { ym };
  // own files: wave-media:// covers are read by the main process (4.6; before only https covers had colours)
  else if (url && /^(https:|wave-media:)/.test(url))
    try {
      pal = await api("palette", { url: url.startsWith("https:") ? thumb(url, "s") : url });
    } catch {}
  if (my !== palSeq) return;
  S.palette = pal;
  applyPalette();
}
let palApplyT = 0;
function applyPalette() {
  // on a phone: after the switch animation (~0.4 s), in an idle moment — never in the frame of the tap
  if (root.hasAttribute("data-mobile")) {
    clearTimeout(palApplyT);
    palApplyT = setTimeout(() => {
      // in the next frame; if no frame comes (a hidden page), a little later anyway
      const run = () => {
        let done = false;
        const once = () => { if (!done) { done = true; applyPaletteNow(); } };
        requestAnimationFrame(once);
        setTimeout(once, 600);
      };
      if (window.requestIdleCallback) requestIdleCallback(run, { timeout: 500 });
      else run();
    }, 420);
    return;
  }
  applyPaletteNow();
}
function applyPaletteNow() {
  const r = rampFrom(S.palette),
    st = root.style;
  st.setProperty("--am1", r[1]);
  st.setProperty("--am2", r[2]);
  st.setProperty("--am3", r[3]);
  const acc = accentFrom(S.palette);
  if (acc) {
    st.setProperty("--cv-acc", acc[0]);
    st.setProperty("--cv-primary", acc[1]);
  } else {
    st.removeProperty("--cv-acc");
    st.removeProperty("--cv-primary");
  }
  // 4.13: the Yandex skin tints the player bar like Yandex Music — the average colour of the cover at 20 % lightness
  const avg = ymAverage(S.palette);
  if (avg) st.setProperty("--ym-avg", avg);
  else st.removeProperty("--ym-avg");
  waveRamp(true);
  if (root.dataset.accent === "cover") tintLogo();
}
function ymAverage(pal) {
  const c = pal?.ym?.average || (pal?.greyShare > 0.6 ? pal.grey : pal?.colors?.[0]) || pal?.grey;
  if (!c || !/^#[0-9a-f]{6}/i.test(c)) return null;
  const [h, sat] = toHsl(hx(c));
  return `hsl(${Math.round(h)}, ${Math.round(sat * 100)}%, 20%)`;
}
// 4.9.1: «Моя волна» takes the colours of the track while it plays and returns to its own colours on pause
// (like Yandex Music); a short pause between tracks / while seeking does not flash the colours
const WR = { key: "", t: null };
function waveRamp(force) {
  clearTimeout(WR.t);
  const playing = !!S.current && !audio.paused;
  const own = S.settings?.waveColorPause !== false && !playing;
  const go = () => {
    const key = own
      ? "own:" + root.dataset.accent + ":" + root.dataset.skin
      : "track:" + (S.palette ? JSON.stringify(S.palette).length : 0) + ":" + (S.current?.id || "");
    WaveFx.setLive(playing);
    if (!force && key === WR.key) return;
    WR.key = key;
    const stops = own ? ownRamp() : rampFrom(S.palette);
    WaveFx.setRamp(stops);
    glowRamp(stops);
  };
  if (own && !force) WR.t = setTimeout(go, 700);
  else go();
}

// 4.11: «Свечение справа» — a soft light over the right side of «Моя волна» (like Yandex Music) in the colours of
// the wave: the colours of the playing track, its own colours on pause. Colours change smoothly (@property in CSS).
function glowRamp(stops) {
  const g = $("#wv-glow");
  if (!g || !Array.isArray(stops) || !stops.length) return;
  const c = (i) => stops[Math.min(i, stops.length - 1)];
  g.style.setProperty("--wg1", c(1));
  g.style.setProperty("--wg2", c(2));
  g.style.setProperty("--wg3", c(3));
}
// 4.12: its brightness, how far it reaches into the window, its height and the pulsing (Настройки → Кастомизация)
const GLOW_DEF = { power: 100, reach: 86, height: 100, pulse: 50 };
const glowOpts = () => ({ ...GLOW_DEF, ...(S.settings?.waveGlowFx || {}) });
function applyWaveGlow(o = glowOpts()) {
  const g = $("#wv-glow");
  if (!g) return;
  g.classList.toggle("off", S.settings?.waveGlow === false);
  const st = g.style,
    p = Math.max(0, Math.min(150, +o.power || 0)) / 100,
    pu = Math.max(0, Math.min(100, +o.pulse || 0)) / 100;
  st.setProperty("--wg-op", Math.min(1, p).toFixed(3));
  st.setProperty("--wg-br", Math.max(1, p).toFixed(3));
  st.setProperty("--wg-reach", Math.max(30, Math.min(120, +o.reach || 86)) + "%");
  st.setProperty("--wg-h", (132 * Math.max(60, Math.min(140, +o.height || 100))) / 100 + "%");
  st.setProperty("--wg-pa", (0.12 * pu).toFixed(3));
  st.setProperty("--wg-dur", (17 - 10 * pu).toFixed(1) + "s");
  g.classList.toggle("still", pu === 0);
  g.classList.toggle("bright", p > 1);
}

/* ---------------- 4.12: two more looks of «Моя волна» (Настройки → Кастомизация → Анимация Моей волны → Вид) ----------------
   Both are drawn into #wv-alt (fixed over the whole window, blended with «screen» — their black background vanishes) and
   are driven by WaveFx: it keeps listening to the music, finds the kicks, draws the light streaks and hands every frame
   the levels, the colours of the wave (the track while it plays, its own on pause / «Аркейн») and the user options:
   «Реакция» scales the music, «Тряска» the kicks, «Размер» the spot. If WebGL is not available — the usual look. */
const lift = (hex, minS, minL) => {
  const [h, s, l] = toHsl(hx(hex));
  return [h, Math.max(s, minS), Math.min(0.72, Math.max(l, minL))];
};
// the hue of a colour of the cover with a set lightness: a light cover does not turn the spot white («screen» blending)
const tone = (hex, minS, L) => {
  const [h, s] = toHsl(hx(hex));
  return [h, s < 0.12 ? s : Math.max(s, minS), L];
};
// «Яндекс» — the original animation of Yandex Music: its WebGL worker (vendor/vibe, unchanged) on an OffscreenCanvas
const VibeFx = (() => {
  const T = "vibe-animation-worker-";
  let w = null,
    cv = null,
    ok = true,
    shown = false,
    playing = null,
    lastF = 0,
    sizeK = 1,
    ramp = null;
  const send = (type, payload) => w?.postMessage({ type: T + type, payload });
  function mount() {
    if (w) return true;
    if (!ok) return false;
    try {
      cv = document.createElement("canvas");
      cv.className = "wv-vibe";
      $("#wv-alt").append(cv);
      if (!cv.transferControlToOffscreen || typeof Worker === "undefined") throw new Error("нет OffscreenCanvas");
      const off = cv.transferControlToOffscreen();
      w = new Worker("vendor/vibe/vibe-worker.js");
      w.onmessage = (e) => e.data?.type === T + "error" && fail(e.data.payload);
      w.onerror = (e) => fail(e.message || "worker");
      const lite = root.dataset.fx === "lite";
      w.postMessage(
        {
          type: T + "init",
          payload: { canvas: off, state: lite ? "LITE" : "DEFAULT", isShaderV3Enabled: false, collectionHue: 10 },
        },
        [off],
      );
      send("update-layout", { isMobile: false });
      playing = null;
      if (ramp) setRamp(ramp);
      return true;
    } catch (e) {
      fail(e?.message || e);
      return false;
    }
  }
  function fail(why) {
    if (!ok) return;
    ok = false;
    console.warn("«Яндекс» look of the wave is not available:", why);
    destroy();
    WaveFx.altFailed("yandex");
  }
  function destroy() {
    try {
      w?.terminate();
    } catch {}
    w = null;
    cv?.remove();
    cv = null;
    shown = false;
  }
  function show(on) {
    shown = on;
    cv?.classList.toggle("on", on);
    send(on ? "enable" : "disable");
  }
  // the square canvas (650 px inside, like in the app) centred where the spot of the stage is
  function place(sc, opt) {
    if (!cv || !sc?.w) return;
    sizeK = 1 + 0.75 * Math.max(0, (opt?.size ?? 0.6) - 0.6);
    const s = Math.round(Math.max(sc.h || 0, sc.w * 0.6) * 1.22 * sizeK);
    Object.assign(cv.style, { width: s + "px", height: s + "px", left: sc.x - s / 2 + "px", top: sc.y - s / 2 + "px" });
  }
  function setRamp(stops) {
    ramp = stops;
    if (!w) return;
    const c = (i) => stops[Math.min(i, stops.length - 1)];
    const hsl = (x, s, l) => {
      const [h, ss, ll] = tone(x, s, l);
      return { h, s: ss, l: ll };
    };
    send("apply-settings", {
      customColors: { bottom: hsl(c(1), 0.6, 0.36), middle: hsl(c(2), 0.6, 0.45), top: hsl(c(3), 0.6, 0.5) },
    });
  }
  // the levels go at the 25 fps of the worker; «Реакция» scales them, «Тряска» adds the kicks to the bass
  function frame(now, dt, A) {
    if (!w || !shown) return;
    const pl = A.live > 0.5;
    if (pl !== playing) {
      playing = pl;
      if (pl) send("play-animation", { energy: 0.6 });
      else send("idle-animation");
    }
    if (now - lastF < 38) return;
    lastF = now;
    const R = A.opt.react,
      K = A.kick * Math.min(1, A.opt.shake);
    const v = (x) => Math.max(0, Math.min(1, x));
    send("audio-analyzer-frequencies", {
      low: v(Math.max(A.yb[0] * R, K * 0.9)),
      middle: v(Math.max(A.yb[1] * R, K * 0.5)),
      high: v(A.yb[2] * R),
    });
  }
  const pause = () => send("disable");
  const resume = () => shown && send("enable");
  // animations off: one frame, then still
  const still = () => {
    send("enable");
    setTimeout(() => !WaveFx.stats().on && send("disable"), 160);
  };
  const like = () => (w && shown ? (send("like-animation"), true) : false);
  const reset = () => {
    destroy();
    ok = true;
  };
  return {
    mount,
    destroy,
    show,
    place,
    setRamp,
    frame,
    pause,
    resume,
    still,
    like,
    reset,
    get ok() {
      return ok;
    },
  };
})();
// «Аура» — a glowing spot of three layers with thin shining edges rippled by noise (own WebGL shader): bass → size and brightness,
// mids → speed, highs → a light rim, kicks → the core flashes
const AuraFx = (() => {
  const VERT = "attribute vec2 p; void main(){ gl_Position = vec4(p, 0.0, 1.0); }";
  const FRAG = `precision highp float;
uniform vec2 uCenter; uniform float uUnit, uTime, uBass, uMid, uHigh, uBeat;
uniform vec3 uC0, uC1, uC2, uCore;
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy;
  i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx;
  vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}
// one layer of the spot: its edge is rippled by noise; returns the soft fill, «rim» gets a thin glowing line on the edge
float layer(vec2 uv, float seed, float base, float amp, float t, out float rim){
  float a = atan(uv.y, uv.x);
  vec2 dir = vec2(cos(a), sin(a));
  float n = snoise(vec3(dir * 0.8 + seed, t * 0.32 + seed)) + 0.45 * snoise(vec3(dir * 1.9 - seed, t * 0.55 + seed * 2.0));
  float d = length(uv) - base * (1.0 + amp * n);
  rim = exp(-abs(d) * 34.0) + 0.35 * exp(-abs(d) * 9.0);
  return 1.0 - smoothstep(-0.16, 0.015, d);
}
void main(){
  vec2 uv = (gl_FragCoord.xy - uCenter) / uUnit;
  float t = uTime;
  vec2 q = uv / (1.0 + 0.16 * uBass + 0.08 * uBeat);
  q += 0.035 * vec2(snoise(vec3(q * 1.4, t * 0.18)), snoise(vec3(q * 1.4 + 7.0, t * 0.18)));
  float amp = 0.09 + 0.11 * uBass + 0.04 * uHigh;
  float r0, r1, r2, rc;
  float f0 = layer(q, 1.7, 0.36, amp, t, r0);
  float f1 = layer(q * 1.06 + vec2(0.035, -0.02), 4.1, 0.31, amp * 1.25, t * 1.12, r1);
  float f2 = layer(q * 0.96 - vec2(0.025, 0.03), 8.3, 0.27, amp * 1.45, t * 0.92, r2);
  float fc = layer(q * 1.2, 12.0, 0.13, amp * 0.7, t * 1.3, rc);
  float L = length(q);
  vec3 col = (uC2 * 0.6 + uC0 * 0.4) * exp(-L * 3.4) * (0.22 + 0.25 * uBass);
  col += uC2 * (f0 * 0.24 + r0 * 0.42);
  col += uC0 * (f1 * 0.2 + r1 * 0.46);
  col += uC1 * (f2 * 0.16 + r2 * (0.40 + 0.35 * uHigh));
  col += uCore * fc * (0.10 + 0.30 * uBass + 0.45 * uBeat) * exp(-L * 4.0);
  col = 1.0 - exp(-col * 1.15);
  col *= 1.0 - smoothstep(0.55, 1.25, length(uv));
  gl_FragColor = vec4(col, 1.0);
}`;
  let cv = null,
    gl = null,
    U = null,
    ok = true,
    shown = false,
    sc = null,
    sizeK = 1,
    t = Math.random() * 100;
  let bass = 0,
    mid = 0,
    high = 0;
  // current and wanted colours (rgb 0…1); the change takes ~1 s at any frame rate
  const cur = { c0: [1, 0.35, 0.21], c1: [1, 0.83, 0], c2: [0.76, 0.07, 0.49], core: [1, 0.93, 0.7] };
  let want = null;
  function mount() {
    if (gl) return true;
    if (!ok) return false;
    try {
      cv = document.createElement("canvas");
      cv.className = "wv-aura";
      $("#wv-alt").append(cv);
      gl = cv.getContext("webgl", { antialias: false, alpha: false, premultipliedAlpha: false, depth: false });
      if (!gl) throw new Error("WebGL недоступен");
      const sh = (type, src) => {
        const s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
        return s;
      };
      const pr = gl.createProgram();
      gl.attachShader(pr, sh(gl.VERTEX_SHADER, VERT));
      gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FRAG));
      gl.linkProgram(pr);
      if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr) || "link");
      gl.useProgram(pr);
      gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(pr, "p");
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      U = {};
      for (const n of ["uCenter", "uUnit", "uTime", "uBass", "uMid", "uHigh", "uBeat", "uC0", "uC1", "uC2", "uCore"])
        U[n] = gl.getUniformLocation(pr, n);
      // a lost context of the current canvas (driver reset) → the usual look; our own destroy() is not a failure
      cv.addEventListener("webglcontextlost", (e) => {
        e.preventDefault();
        if (e.target === cv) fail("context lost");
      });
      return true;
    } catch (e) {
      fail(e?.message || e);
      return false;
    }
  }
  function fail(why) {
    if (!ok) return;
    ok = false;
    console.warn("«Аура» look of the wave is not available:", why);
    destroy();
    WaveFx.altFailed("aura");
  }
  function destroy() {
    const g = gl;
    gl = null;
    cv?.remove();
    cv = null;
    shown = false;
    try {
      g?.getExtension("WEBGL_lose_context")?.loseContext();
    } catch {}
  }
  function show(on) {
    shown = on;
    cv?.classList.toggle("on", on);
  }
  // the shader is soft — it is drawn at 60 % (40 % in «Лёгкий») of the window and scaled up by CSS
  const scale = () => (root.dataset.fx === "lite" ? 0.4 : 0.6);
  function place(s, opt) {
    sc = s;
    sizeK = 1 + 0.75 * Math.max(0, (opt?.size ?? 0.6) - 0.6);
    if (!cv) return;
    const k = scale(),
      w = Math.max(16, Math.round(innerWidth * k)),
      h = Math.max(16, Math.round(innerHeight * k));
    if (cv.width !== w || cv.height !== h) {
      cv.width = w;
      cv.height = h;
      gl?.viewport(0, 0, w, h);
    }
  }
  function setRamp(stops) {
    const c = (i) => stops[Math.min(i, stops.length - 1)];
    const rgb = (x, s, l) => hx(fromHsl(...tone(x, s, l))).map((v) => v / 255);
    const top = rgb(c(3), 0.6, 0.58);
    want = {
      c2: rgb(c(1), 0.55, 0.42),
      c0: rgb(c(2), 0.6, 0.5),
      c1: top,
      core: top.map((v) => v + (1 - v) * 0.55),
    };
  }
  function frame(now, dt, A) {
    if (!gl || !shown || !sc?.w) return;
    const R = A.opt.react,
      k = (tau) => 1 - Math.exp(-dt / tau);
    const b = Math.min(1, A.bass * R),
      m = Math.min(1, A.mids * R),
      h = Math.min(1, A.high * R * 1.6);
    bass += (b - bass) * k(b > bass ? 0.03 : 0.22);
    mid += (m - mid) * k(0.35);
    high += (h - high) * k(h > high ? 0.04 : 0.18);
    // calmer on pause; the speed is integrated here, so a change of the mids never makes the shape jump
    t += dt * (0.35 + 0.65 * A.live) * (0.6 + 1.4 * mid);
    if (want) {
      const f = k(0.45);
      for (const key in cur) cur[key] = cur[key].map((v, i) => v + (want[key][i] - v) * f);
    }
    const kk = scale(),
      unit = Math.min(sc.w, sc.h || sc.w) * 0.82 * sizeK * kk;
    gl.uniform2f(U.uCenter, sc.x * kk, (innerHeight - sc.y) * kk);
    gl.uniform1f(U.uUnit, unit);
    gl.uniform1f(U.uTime, t);
    gl.uniform1f(U.uBass, bass);
    gl.uniform1f(U.uMid, mid);
    gl.uniform1f(U.uHigh, high);
    gl.uniform1f(U.uBeat, Math.min(1, A.kick * Math.min(1, A.opt.shake)));
    gl.uniform3fv(U.uC0, cur.c0);
    gl.uniform3fv(U.uC1, cur.c1);
    gl.uniform3fv(U.uC2, cur.c2);
    gl.uniform3fv(U.uCore, cur.core);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  const reset = () => {
    destroy();
    ok = true;
  };
  return {
    mount,
    destroy,
    show,
    place,
    setRamp,
    frame,
    pause() {},
    resume() {},
    still() {},
    like: () => false,
    reset,
    get ok() {
      return ok;
    },
  };
})();

/* ---------------- «Моя волна» heat-map glow ----------------
   A metaball field coloured through a 4-stop ramp taken from the cover; the canvas covers the whole
   window and the blobs are positioned relative to the stage (one background without a seam).
   4.3.1 — sharper and livelier, closer to Яндекс Музыка:
   · 288×176 field (2.6× the pixels of 4.3) at ~45 fps; gaussians are separable, so a frame costs
     W·H·N multiply-adds instead of W·H·N exp() calls;
   · crisp colour bands (each ramp colour holds, then switches quickly) and only a light CSS blur;
   · faster drift, and the speed follows the music;
   · beat detection on its own pre-volume analyser: a kick swells the core and jolts the satellites
     (damped springs), so the shape breathes with the track at any volume.
   Runs only while «Моя волна» is visible. */
const WaveFx = (() => {
  const W = 288,
    H = 176;
  // [x, y, amp x, amp y, freq x, freq y, phase, radius, weight, reacts to the beat]
  const N_CUT = 9; // the last blob has a negative weight: it carves the top edge of the shape
  const BL = [
    [0.5, 0.43, 0.045, 0.05, 0.62, 0.54, 0, 0.3, 1.0, 1],
    [0.35, 0.6, 0.09, 0.07, 0.42, 0.66, 1, 0.21, 0.72, 0.7],
    [0.67, 0.31, 0.08, 0.08, 0.5, 0.38, 2, 0.2, 0.66, 0.7],
    [0.57, 0.77, 0.11, 0.05, 0.34, 0.46, 3, 0.19, 0.6, 0.5],
    [0.27, 0.36, 0.07, 0.07, 0.58, 0.62, 4, 0.15, 0.5, 0.6],
    [0.76, 0.58, 0.06, 0.08, 0.54, 0.42, 5, 0.16, 0.54, 0.6],
    [0.5, 0.47, 0.24, 0.2, 0.9, 0.9, 0.5, 0.085, 0.42, 1.2],
    [0.5, 0.45, 0.27, 0.23, -0.72, -0.72, 2.6, 0.075, 0.38, 1.2],
    [0.43, 0.24, 0.06, 0.04, 0.8, 0.7, 1.7, 0.1, 0.34, 0.8],
    [0.53, 0.04, 0.06, 0.04, 0.4, 0.48, 0, 0.13, -1.12, 0],
  ];
  const N = BL.length;
  // 4.6: constant morphing — every blob slowly stretches (own x / y radius), swells and drifts off its orbit
  // with incommensurate frequencies, so the shape never repeats. [fx, fy, fw, phase x, phase y, phase w, drift]
  const MO = BL.map((_, k) => [
    0.23 + 0.071 * k,
    0.31 + 0.053 * ((k * 7) % 10),
    0.17 + 0.043 * ((k * 3) % 10),
    k * 1.7,
    k * 2.3 + 1,
    k * 0.9 + 2,
    k === 0 ? 0.35 : k === N_CUT ? 0 : 1,
  ]);
  // user settings (Настройки → Кастомизация): shake / reaction / size as multipliers
  let OPT = { shake: 1, react: 1, size: 1, lines: true },
    mt = 0,
    // 4.12: the look — «classic» (this heat map), «yandex» (VibeFx) or «aura» (AuraFx); alt = the active other renderer
    style = "classic",
    styleKey = "",
    alt = null,
    stg = null,
    high = 0;
  // the three bands of Yandex Music (0–250 / 500–2000 / 2000–4000 Hz) for «Яндекс»
  const YB = [0, 0, 0];
  const NX = new Float32Array(W),
    NY = new Float32Array(H),
    EX = new Float32Array(N * W),
    EY = new Float32Array(N * H),
    WY = new Float32Array(N),
    KS = new Int32Array(N),
    // spring jolts per blob: offset + velocity
    jx = new Float32Array(N),
    jy = new Float32Array(N),
    vx = new Float32Array(N),
    vy = new Float32Array(N);
  let cv = null,
    ctx = null,
    img = null,
    raf = 0,
    last = 0,
    prevT = 0,
    paused = false,
    active = false,
    asp = 0.9;
  let fbuf = null,
    fbufAn = null,
    energy = 0,
    mids = 0,
    bass = 0,
    bassLow = 0,
    bassAvg = 0,
    midLow = 0,
    lastSnap = 0,
    kick = 0,
    lastBeat = 0,
    beats = 0,
    ph = 0,
    peak = 1.6;
  let lutA = null,
    lutB = null,
    lut = null,
    mix = 1,
    mixStart = 0,
    // 4.9.1: 1 while the music plays, 0 on pause — the shape moves calmer when nothing plays
    live = 0,
    liveTo = 0;
  const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
  function makeLut(stops) {
    const cs = stops.map(hx),
      out = new Uint8ClampedArray(1024),
      pos = [0.15, 0.39, 0.63, 0.87];
    for (let i = 0; i < 256; i++) {
      const v = i / 255;
      let c;
      if (v <= pos[0]) c = cs[0];
      else if (v >= pos[3]) c = cs[3];
      else {
        let k = 0;
        while (v > pos[k + 1]) k++;
        // hold each colour and switch over a fifth of the segment → crisp bands with a faint bright rim
        const g = (v - pos[k]) / (pos[k + 1] - pos[k]),
          f = clamp01((g - 0.4) / 0.2),
          s = f * f * (3 - 2 * f),
          rim = 1 + 0.1 * Math.exp(-((g - 0.5) ** 2) / 0.004);
        c = [0, 1, 2].map((j) => (cs[k][j] + (cs[k + 1][j] - cs[k][j]) * s) * rim);
      }
      const a = clamp01((v - 0.045) / 0.08);
      out[i * 4] = c[0];
      out[i * 4 + 1] = c[1];
      out[i * 4 + 2] = c[2];
      out[i * 4 + 3] = 255 * a * a * (3 - 2 * a);
    }
    return out;
  }
  lut = lutB = makeLut(DEFAULT_RAMP);
  // thin light streaks orbiting the glow: a second, sharp canvas over the blurred one (full effects only)
  let cv2 = null,
    ctx2 = null,
    sc = { x: 0, y: 0, w: 0 },
    srgb = [255, 255, 255],
    sk = 1;
  const ST = [0.2, 0.26, 0.31, 0.36, 0.41, 0.23, 0.33].map((r, i) => ({
    r,
    e: 0.34 + 0.09 * (i % 4),
    rot: -0.5 + i * 0.37,
    w: 0.9 + (i % 3) * 0.35,
    a: i * 0.9,
    sp: (i % 2 ? -1 : 1) * (0.16 + 0.03 * i),
    len: 0.9 + 0.22 * (i % 3),
    drift: 0.03 + 0.01 * (i % 3),
  }));
  const streaksOn = () => root.dataset.fx === "full" && !!cv2 && active && OPT.lines;
  function sizeStreaks() {
    if (!cv2) return;
    sk = Math.min(1, devicePixelRatio || 1) * 0.8;
    const w = Math.round(innerWidth * sk),
      h = Math.round(innerHeight * sk);
    if (cv2.width !== w || cv2.height !== h || !ctx2) {
      cv2.width = w;
      cv2.height = h;
      ctx2 = cv2.getContext("2d");
    }
  }
  function drawStreaks(dt) {
    const c = ctx2;
    if (!c) return;
    c.globalCompositeOperation = "source-over";
    c.clearRect(0, 0, cv2.width, cv2.height);
    if (!sc.w) return;
    c.globalCompositeOperation = "lighter";
    c.lineCap = "round";
    // 4.7: every audio term is scaled by «Реакция» — at 0 % the streaks do not flash on beats
    const Rk = Math.min(1, OPT.react),
      E = energy * Rk,
      K = kick * Rk,
      M = mids * Rk;
    const spd = 1 + OPT.react * (1.2 * energy + 2.6 * kick),
      cx = sc.x * sk,
      cy = sc.y * sk,
      base = sc.w * sk * OPT.size;
    const [r, g, b] = srgb;
    for (const s of ST) {
      s.a += s.sp * dt * spd;
      s.rot += s.drift * dt * Math.sign(s.sp);
      const rx = base * s.r * (1 + 0.06 * E + 0.12 * K),
        ry = rx * s.e;
      const A = 0.07 + 0.16 * E + 0.34 * K + 0.05 * M,
        seg = 9,
        dir = Math.sign(s.sp);
      for (let k = 0; k < seg; k++) {
        // tail → head: every next piece is brighter, so the streak fades out behind
        const a0 = s.a - dir * s.len * (1 - k / seg),
          a1 = s.a - dir * s.len * (1 - (k + 1) / seg),
          f = (k + 1) / seg,
          al = A * f * f;
        c.beginPath();
        c.ellipse(cx, cy, rx, ry, s.rot, Math.min(a0, a1), Math.max(a0, a1));
        c.strokeStyle = `rgba(${r},${g},${b},${(al * 0.35).toFixed(3)})`;
        c.lineWidth = s.w * 5 * sk;
        c.stroke();
        c.strokeStyle = `rgba(255,255,255,${al.toFixed(3)})`;
        c.lineWidth = s.w * sk;
        c.stroke();
      }
    }
  }

  function jolt(s) {
    s *= OPT.shake;
    if (!s) return;
    for (let k = 0; k < N; k++) {
      const r = BL[k][9] * s;
      if (!r) continue;
      const a = Math.random() * Math.PI * 2;
      vx[k] += Math.cos(a) * 0.5 * r;
      vy[k] += Math.sin(a) * 0.5 * r;
    }
  }
  // bass level → loudness envelope + onset (kick) detection; volume independent (pre-gain tap)
  function listen(dt, now) {
    const an = typeof AX !== "undefined" && AX.ok ? AX.fx : null;
    let b = 0,
      m = 0,
      h = 0;
    if (an && !audio.paused) {
      if (fbufAn !== an) {
        fbuf = new Uint8Array(an.frequencyBinCount);
        fbufAn = an;
      }
      an.getByteFrequencyData(fbuf);
      const hz = (an.context?.sampleRate || 48000) / an.fftSize,
        b0 = Math.max(1, Math.round(40 / hz)),
        b1 = Math.max(b0 + 1, Math.round(180 / hz)),
        m1 = Math.max(b1 + 2, Math.round(2000 / hz));
      for (let i = b0; i <= b1; i++) b += fbuf[i];
      b /= (b1 - b0 + 1) * 255;
      for (let i = b1 + 1; i <= m1; i++) m += fbuf[i];
      m /= (m1 - b1) * 255;
      if (alt) {
        const band = (lo, hi) => {
          const a = Math.max(0, Math.floor(lo / hz)),
            z = Math.min(fbuf.length - 1, Math.max(a, Math.floor(hi / hz)));
          let s = 0;
          for (let i = a; i <= z; i++) s += fbuf[i];
          return s / (z - a + 1) / 255;
        };
        h = band(4000, 12000);
        YB[0] = band(0, 250);
        YB[1] = band(500, 2000);
        YB[2] = band(2000, 4000);
      }
    } else YB.fill(0);
    high = h;
    bass = b;
    bassAvg += (b - bassAvg) * (1 - Math.exp(-dt / 0.6));
    // valley follower: drops with the signal, creeps up slowly → a kick is a jump above the last valley
    bassLow = b < bassLow ? b : bassLow + (b - bassLow) * (1 - Math.exp(-dt / 0.35));
    const jump = b - bassLow;
    if (b > 0.3 && b > bassAvg - 0.02 && jump > 0.09 && now - lastBeat > 200) {
      lastBeat = now;
      beats++;
      bassLow = b;
      const s = Math.min(1, 0.45 + jump * 3);
      kick = Math.max(kick, s);
      jolt(s);
    }
    // snares / claps (mids jump): a lighter jolt of the satellites — keeps tracks without a kick lively
    midLow = m < midLow ? m : midLow + (m - midLow) * (1 - Math.exp(-dt / 0.3));
    if (m > 0.25 && m - midLow > 0.08 && now - lastSnap > 160 && now - lastBeat > 120) {
      lastSnap = now;
      midLow = m;
      kick = Math.max(kick, 0.32);
      jolt(0.4);
    }
    kick *= Math.exp(-dt * 5.2);
    const e = clamp01((b - 0.3) / 0.55);
    energy += (e - energy) * (1 - Math.exp(-dt / (e > energy ? 0.05 : 0.4)));
    const mm = clamp01((m - 0.25) / 0.5);
    mids += (mm - mids) * (1 - Math.exp(-dt / (mm > mids ? 0.08 : 0.5)));
  }
  function draw(now) {
    if (!ctx) return;
    const dt = prevT ? Math.min(0.1, Math.max(0.001, (now - prevT) / 1000)) : 0.022;
    prevT = now;
    if (mix < 1) {
      mix = Math.min(1, (now - mixStart) / 1200);
      const m = mix * mix * (3 - 2 * mix);
      lut = new Uint8ClampedArray(1024);
      for (let i = 0; i < 1024; i++) lut[i] = lutA[i] + (lutB[i] - lutA[i]) * m;
    }
    listen(dt, now);
    live += (liveTo - live) * (1 - Math.exp(-dt / 0.9));
    if (alt) {
      alt.frame(now, dt, { energy, mids, bass, high, kick, live, yb: YB, opt: OPT });
      if (streaksOn()) drawStreaks(dt);
      return;
    }
    const R = OPT.react,
      Z = OPT.size,
      calm = 0.4 + 0.6 * live;
    ph += dt * (0.9 * calm + R * (0.9 * energy + 0.6 * mids + 1.6 * kick));
    mt += dt * (0.6 * calm + 0.5 * R * energy + 0.3 * R * kick);
    // slow breathing of the core: softer when both «Тряска» and «Реакция» are low
    const br =
      1 + 0.04 * Math.min(1, 0.25 + 0.75 * Math.max(Math.min(1, OPT.shake), Math.min(1, R))) * Math.sin(ph * 0.8);
    for (let k = 0; k < N; k++) {
      // damped spring pulls every jolted blob back to its path
      vx[k] += (-38 * jx[k] - 7 * vx[k]) * dt;
      vy[k] += (-38 * jy[k] - 7 * vy[k]) * dt;
      jx[k] += vx[k] * dt;
      jy[k] += vy[k] * dt;
      const p = BL[k],
        m = MO[k],
        re = p[9];
      const dr = m[6] * 0.035;
      const x = p[0] + p[2] * Math.sin(ph * p[4] + p[6]) + jx[k] + dr * Math.sin(mt * 0.13 * (1 + 0.21 * k) + k),
        y =
          p[1] +
          p[3] * Math.cos(ph * p[5] + p[6] * 1.3) +
          jy[k] +
          dr * 0.85 * Math.cos(mt * 0.11 * (1 + 0.17 * k) + 2 * k);
      const r = Z * p[7] * (k ? 1 : br) * (1 + re * R * (0.1 * energy + 0.28 * kick)),
        st = m[6] ? 0.17 : 0.05,
        rx = r * (1 + st * Math.sin(mt * m[0] + m[3])),
        ry = r * (1 + st * Math.sin(mt * m[1] + m[4])),
        w =
          p[8] < 0
            ? p[8]
            : p[8] *
              (1 + 0.14 * m[6] * Math.sin(mt * m[2] + m[5])) *
              (1 + re * R * (0.22 * energy + 0.38 * kick + 0.12 * mids));
      const ix = 1 / (rx * rx),
        iy = 1 / (ry * ry),
        ox = k * W,
        oy = k * H;
      for (let i = 0; i < W; i++) {
        const d = (NX[i] - x) * asp;
        EX[ox + i] = Math.exp(-d * d * ix);
      }
      for (let j = 0; j < H; j++) {
        const d = NY[j] - y;
        EY[oy + j] = w * Math.exp(-d * d * iy);
      }
    }
    // normalise by the (smoothed) peak: the core stays a small bright spot and every colour band stays
    // visible however loud it is; the beat shows as growth of the shape + a slightly hotter core
    const gain = (1.02 + 0.14 * kick * Math.min(1, R)) / Math.max(0.8, peak),
      d = img.data;
    let o = 0,
      mx = 0;
    for (let y = 0; y < H; y++) {
      let n = 0;
      for (let k = 0; k < N; k++) {
        const v = EY[k * H + y];
        if (v > 0.002 || v < -0.002) {
          WY[n] = v;
          KS[n++] = k * W;
        }
      }
      for (let x = 0; x < W; x++) {
        let v = 0;
        for (let k = 0; k < n; k++) v += WY[k] * EX[KS[k] + x];
        if (v > mx) mx = v;
        v *= gain;
        const q = (v <= 0 ? 0 : v >= 1 ? 255 : (v * 255) | 0) * 4;
        d[o] = lut[q];
        d[o + 1] = lut[q + 1];
        d[o + 2] = lut[q + 2];
        d[o + 3] = lut[q + 3];
        o += 4;
      }
    }
    ctx.putImageData(img, 0, 0);
    peak += (mx - peak) * (mx > peak ? 0.35 : 0.04);
    if (streaksOn()) drawStreaks(dt);
  }
  function loop(now) {
    raf = requestAnimationFrame(loop);
    // an unfocused window draws at ~20 fps, a hidden one does not draw at all (see the «win» event)
    // 4.7: every display frame up to ~70 fps (was ~30 fps — the motion looked jerky)
    if (now - last < (S.unfocused ? 50 : document.documentElement.hasAttribute("data-mobile") ? 15 : 13)) return;
    last = now;
    draw(now);
  }
  const animated = () => S.settings?.animation !== false && root.dataset.waveEconomy !== "1";
  // map canvas pixels to the stage-relative field: stage centre at 50 % / 40 %, 108 % × 96 % of the stage
  function frame(stage) {
    if (!cv) return;
    const c = cv.getBoundingClientRect(),
      r = stage?.getBoundingClientRect?.();
    if (!r || !r.width || !c.width) return;
    const sx0 = r.left - r.width * 0.04,
      sw = r.width * 1.08,
      sy0 = r.top - r.height * 0.08,
      sh = r.height * 0.96;
    // true aspect → round blobs on any window shape (slightly tall on very narrow stages)
    asp = Math.max(0.62, Math.min(1.6, sw / sh));
    for (let x = 0; x < W; x++) NX[x] = (c.left + ((x + 0.5) / W) * c.width - sx0) / sw;
    for (let y = 0; y < H; y++) NY[y] = (c.top + ((y + 0.5) / H) * c.height - sy0) / sh;
    // the core of the glow sits at 50 % / 43 % of the field
    sc = { x: sx0 + 0.5 * sw, y: sy0 + 0.43 * sh, w: sw, h: sh };
    stg = stage;
    alt?.place(sc, OPT);
    sizeStreaks();
    if (!raf) draw(performance.now());
  }
  function pickAlt() {
    if (style === "classic") return null;
    const R = style === "yandex" ? VibeFx : AuraFx;
    return R.mount() ? R : null;
  }
  function start(canvas, stage) {
    stop();
    cv = canvas;
    active = true;
    alt = pickAlt();
    cv.classList.toggle("on", !alt);
    alt?.show(true);
    if (cv.width !== W || cv.height !== H || !ctx) {
      cv.width = W;
      cv.height = H;
      ctx = cv.getContext("2d");
      img = ctx.createImageData(W, H);
    }
    cv2 = $("#wv-fx2");
    cv2?.classList.toggle("on", root.dataset.fx === "full");
    $("#wv-glow")?.classList.add("on");
    prevT = 0;
    frame(stage);
    draw(performance.now());
    if (animated() && !paused && !document.hidden && !S.bg) {
      raf = requestAnimationFrame(loop);
      alt?.resume();
    } else alt?.still();
  }
  function stop() {
    cancelAnimationFrame(raf);
    raf = 0;
    alt?.pause();
  }
  function halt() {
    stop();
    active = false;
    alt?.show(false);
    cv?.classList.remove("on");
    cv2?.classList.remove("on");
    $("#wv-glow")?.classList.remove("on");
    ctx2?.clearRect(0, 0, cv2.width, cv2.height);
  }
  function resume() {
    if (cv && active && !raf && animated() && !paused && !document.hidden && !S.bg) {
      prevT = 0;
      raf = requestAnimationFrame(loop);
      alt?.resume();
    }
  }
  // 4.12: the look of the wave; a change of «Эффект стекла» re-creates the Yandex worker (its LITE mode is set at start)
  function setStyle(s, fx = root.dataset.fx) {
    const want = s === "yandex" || s === "aura" ? s : "classic",
      key = want + "|" + fx;
    if (key === styleKey) return;
    const fxOnly = styleKey.split("|")[0] === want;
    styleKey = key;
    style = want;
    if (fxOnly && want !== "yandex") return alt?.place(sc, OPT);
    const was = alt;
    alt = null;
    was?.show(false);
    VibeFx.destroy();
    AuraFx.destroy();
    if (active && cv) start(cv, stg);
  }
  // a renderer could not start (no WebGL / the worker failed): the usual look, said once
  let failSaid = false;
  function altFailed(which) {
    if (style !== which) return;
    alt = null;
    if (active) {
      cv?.classList.add("on");
      if (!raf) draw(performance.now());
    }
    if (!failSaid) {
      failSaid = true;
      toast(
        `Вид «${which === "yandex" ? "Яндекс" : "Аура"}» не запустился на ${root.hasAttribute("data-mobile") ? "этом телефоне" : "этой видеокарте"} — показана волна Wave`,
        4500,
      );
    }
  }
  // ♥ on the playing track: the like animation of Yandex Music (in «Яндекс»), a soft pulse otherwise
  function like() {
    if (!active) return;
    if (!alt?.like()) pulse(0.9);
  }
  function setPaused(p) {
    paused = p;
    if (p) stop();
    else resume();
  }
  function setLive(on) {
    liveTo = on ? 1 : 0;
  }
  function setRamp(stops) {
    VibeFx.setRamp(stops);
    AuraFx.setRamp(stops);
    const c3 = hx(stops[2] || stops[0]);
    srgb = c3.map((v) => Math.round(v + (255 - v) * 0.45));
    lutA = lut;
    lutB = makeLut(stops);
    mix = 0;
    mixStart = performance.now();
    if (cv && active && !raf) {
      mix = 1;
      lut = lutB;
      draw(performance.now());
    } else if (active) pulse(0.6);
  }
  // a soft pulse (new track, play) — the same reaction as a kick
  function pulse(s = 0.7) {
    kick = Math.max(kick, s);
    jolt(s);
  }
  function setOpts(o) {
    const n = (v, lo, hi, d) => (Number.isFinite(+v) ? Math.min(hi, Math.max(lo, +v)) : d);
    OPT = {
      shake: n(o?.shake, 0, 100, WFX_DEF.shake) / 50,
      react: n(o?.react, 0, 100, WFX_DEF.react) / 60,
      size: n(o?.size, 60, 140, WFX_DEF.size) / 100,
      lines: o?.lines !== false,
    };
    if (!OPT.lines) ctx2?.clearRect(0, 0, cv2.width, cv2.height);
    alt?.place(sc, OPT);
    if (cv && active && !raf) draw(performance.now());
  }
  const stats = () => ({
    energy,
    mids,
    bass,
    high,
    bassLow,
    bassAvg,
    kick,
    beats,
    on: !!raf,
    opt: OPT,
    style,
    alt: alt === VibeFx ? "yandex" : alt === AuraFx ? "aura" : null,
    yb: [...YB],
  });
  document.addEventListener("visibilitychange", () => (document.hidden ? stop() : resume()));
  return {
    start,
    stop,
    halt,
    stop,
    frame,
    setRamp,
    setPaused,
    resume,
    pulse,
    stats,
    setOpts,
    setLive,
    setStyle,
    altFailed,
    like,
  };
})();

/* ---------------- «Моя волна» page (new interface) ---------------- */
const glyph = (d, a, b, c, id) =>
  `<svg class="wv-gl" viewBox="-6 -6 112 112"><defs><linearGradient id="gf${id}" x1="0" y1="0" x2=".9" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient><linearGradient id="gs${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${b}"/><stop offset="1" stop-color="${c}"/></linearGradient><linearGradient id="gh${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>${[
    7, 6, 5, 4, 3, 2, 1,
  ]
    .map((k) => `<path d="${d}" fill="url(#gs${id})" transform="translate(${k * 0.9} ${k * 1.1})"/>`)
    .join("")}<path d="${d}" fill="url(#gf${id})"/><path d="${d}" fill="url(#gh${id})" opacity=".55"/></svg>`;
const GLYPHS = {
  train: [
    "M8 8h20l12 24V8h20v24L72 8h20L72 46l22 42H72L60 64v24H40V64L28 88H6l22-42z",
    "#9db4d8",
    "#4b5f86",
    "#1d2740",
  ],
  cloud: ["M10 8h80v22H40v10h42v20H40v8h30v20H10V70h10V58H10V40h10V30H10z", "#ff8fd0", "#e2307f", "#7a0f45"],
  house: ["M14 10Q50 2 90 8L44 62Q66 58 84 66L74 90Q36 98 6 86L54 30Q32 30 12 36z", "#8fb5ff", "#2f5fe0", "#122a7a"],
  tune: ["M6 22h88v14H6zM16 46h68v13H16zM28 69h44v12H28z", "#ffffff", "#c9c9d6", "#4b4b5c"],
  rap: ["M6 8h26l18 28L68 8h26L64 48l30 40H68L50 62 32 88H6l30-40z", "#5ef0b0", "#13a26a", "#07452f"],
  sad: ["M50 4C66 30 80 46 80 64a30 30 0 0 1-60 0C20 46 34 30 50 4z", "#c7a8ff", "#7c4ddb", "#2e1a63"],
  rock: ["M58 2 16 54h28l-10 44 50-58H56z", "#ffb27a", "#f0462d", "#6e1209"],
  // 4.12: «Назад к привычному» (a yellow U-turn arrow, like Yandex Music) and «Встряхнуть Мою волну»
  back: [
    "M40 8 4 40l36 32V52h24c10 0 17 7 17 16s-7 16-17 16H44v14h20c18 0 31-13 31-30S82 38 64 38H40z",
    "#fff3a0",
    "#ffd400",
    "#8a6400",
  ],
  shake: [
    "M50 2l11 33 33 11-33 11-11 33-11-33L6 46l33-11zM84 70l5 13 13 5-13 5-5 13-5-13-13-5 13-5z",
    "#b8f6ff",
    "#25b5e0",
    "#0b4766",
  ],
};
// own colours for presets that share one shape (the genres of the wheel); the gradient ids stay unique
const gl = (k, c, id) => glyph(GLYPHS[k][0], ...(c || GLYPHS[k].slice(1)), id || k);
// 4.7: the wheel icons of Yandex Music (its «agent» covers, transparent PNG) — loaded at runtime from the Yandex
// image CDN; until loaded / offline the own glyph is shown (see the load/error listener below)
const YICON = {
  workout: "2413828/rotor-activity-workout-agent-cover-Wcrjo",
  work: "2413828/rotor-activity-work-background-agent-cover-5t6qb",
  happy: "70683/rotor-mood-happy-agent-cover-JWFjr",
  energetic: "70683/rotor-mood-energetic-agent-cover-NrJtV",
  sad: "30221/rotor-mood-sad-agent-cover-IN0O6",
  road: "70683/rotor-activity-road-trip-agent-cover-S1vPp",
  wake: "28592/rotor-activity-wake-up-agent-cover-RSUMc",
  sleep: "28592/rotor-activity-fall-asleep-agent-cover-XaOnj",
};
const yIcon = (k) => (YICON[k] ? `https://avatars.mds.yandex.net/get-music-misc/${YICON[k]}/200x200` : "");
// 4.13: a 3D picture of Yandex (the agent of a station, «Встряхнуть») over the own glyph — the glyph stays when the
// picture does not load, so a broken picture never shows
const wheelIcon = (x) => {
  const g = GLYPHS[x.g] ? gl(x.g, x.c, x.c ? "c" + String(x.k).replace(/[^A-Za-z0-9]/g, "") : x.g) : gl("tune");
  const src = x.yimg || (x.y && YICON[x.y] ? yIcon(x.y) : "");
  return src
    ? `<span class="wv-ico">${g}<img class="wv-yimg" src="${esc(src)}" alt="" draggable="false" decoding="async"></span>`
    : g;
};
const onYIcon = (e) => {
  const im = e.target;
  if (!(im instanceof HTMLImageElement) || !im.classList.contains("wv-yimg")) return;
  if (e.type === "load") im.parentElement?.classList.add("ok");
  else im.remove();
};
document.addEventListener("load", onYIcon, true);
document.addEventListener("error", onYIcon, true);
const MOOD_LABEL = Object.fromEntries(MOODS);
/* 4.12: the wheel of «Моя волна» — new stations at every start of Wave. With the Yandex account: its personal stations
   and a different handful of all its stations with their pictures (main → «wave-wheel»); without it (or offline) —
   another handful of the own set below. Pinned presets («Закрепить» in the pill on top) always come first, liked
   ones («Нравится») stay in the wheel. «Назад к привычному» resets the choice and the settings of the wave. */
const OWN_WHEEL = [
  { k: "m:wakeup", title: "Просыпаюсь", g: "house", y: "wake", mood: "wakeup", station: "activity:wake-up" },
  { k: "m:energetic", title: "Тренироваться в ритме", g: "train", y: "workout", mood: "energetic" },
  { k: "m:calm", title: "Витаю в облаках на работе", g: "cloud", y: "work", mood: "calm" },
  { k: "m:fun", title: "Хаус и танцуем", g: "house", y: "happy", mood: "fun" },
  { k: "m:rap", title: "Йо, рэп", g: "rap", y: "energetic", mood: "rap" },
  { k: "m:sad", title: "Грустинка под дождь", g: "sad", y: "sad", mood: "sad" },
  { k: "m:rock", title: "Рок на полную", g: "rock", y: "road", mood: "rock" },
  { k: "m:sleep", title: "Засыпаю", g: "sad", y: "sleep", mood: "sleep", station: "activity:fall-asleep" },
  { k: "g:phonk", title: "Фонк в наушниках", g: "rap", c: ["#e0b3ff", "#8b2cf5", "#33105e"], genre: "phonk" },
  {
    k: "g:electronic",
    title: "Электроника на вечер",
    g: "train",
    c: ["#9ff3ff", "#2f8cf0", "#13306e"],
    genre: "electronic",
    station: "genre:electronics",
  },
  { k: "g:lofi", title: "Lo-Fi для учёбы", g: "cloud", c: ["#c9f7d9", "#3fbf86", "#0f4f37"], genre: "lofi" },
  {
    k: "g:jazz",
    title: "Джаз и кофе",
    g: "tune",
    c: ["#ffe1b0", "#d9893a", "#5c2c0a"],
    genre: "jazz",
    station: "genre:jazz",
  },
  {
    k: "g:indie",
    title: "Инди на прогулке",
    g: "house",
    c: ["#fff0a8", "#e8b923", "#6b4b00"],
    genre: "indie",
    station: "genre:local-indie",
  },
  {
    k: "g:dnb",
    title: "Drum & Bass на скорости",
    g: "rock",
    c: ["#b8ffb0", "#36c24a", "#0e4a19"],
    genre: "drum & bass",
    station: "genre:dnb",
  },
  {
    k: "g:pop",
    title: "Поп на повторе",
    g: "cloud",
    c: ["#ffc2e2", "#ff4f9a", "#7a0f45"],
    genre: "pop",
    station: "genre:pop",
  },
  {
    k: "g:ambient",
    title: "Эмбиент для фокуса",
    g: "sad",
    c: ["#c4dcff", "#5b7fe0", "#1a2a6b"],
    genre: "ambient",
    station: "genre:ambient",
  },
  {
    k: "g:rnb",
    title: "R&B ночью",
    g: "sad",
    c: ["#f1b8ff", "#b02fd0", "#3d0a4f"],
    genre: "r&b",
    station: "genre:rnb",
  },
  {
    k: "g:metal",
    title: "Метал без тормозов",
    g: "rock",
    c: ["#d6d9e0", "#6b7280", "#1f2430"],
    genre: "metal",
    station: "genre:metal",
  },
  {
    k: "g:rusrap",
    title: "Русский рэп",
    g: "rap",
    c: ["#ffb3b3", "#e0303a", "#5e0a10"],
    genre: "russian rap",
    station: "genre:rusrap",
  },
];
const WHEEL_N = 9;
let OWN_SET = null;
const ownWheel = () => {
  if (!OWN_SET) {
    const a = [...OWN_WHEEL];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    OWN_SET = a.slice(0, WHEEL_N);
  }
  return OWN_SET;
};
// Yandex stations: the big 3D covers of the wheel for the known ones, the station icon on its colour otherwise
const YST = {
  "activity:workout": "workout",
  "activity:work-background": "work",
  "mood:happy": "happy",
  "mood:energetic": "energetic",
  "mood:sad": "sad",
  "activity:road-trip": "road",
  "activity:wake-up": "wake",
  "activity:fall-asleep": "sleep",
};
const ST_GLYPH = { activity: "train", mood: "cloud", genre: "rock", epoch: "tune" };
// 4.13: the wheel of the new Yandex client — waves (the 3D agent; without it — the own glyph of the kind of the wave, no
// round station icons), new releases / «Продолжить» (a small square cover; plays the album) and the «Встряхнуть» agent
const stationItems = () => {
  const out = [];
  for (const x of S.wheel?.items || []) {
    if (x.control) continue;
    if (x.kind === "album") {
      if (x.album && x.title)
        out.push({
          k: "al:" + x.album,
          title: x.title,
          sub: x.sub || "Новый релиз",
          img: x.img || undefined,
          album: x.album,
          from: x.from || undefined,
          act: () => playWheelAlbum(x),
        });
      continue;
    }
    if (!x.station || !x.title) continue;
    out.push({
      k: "st:" + x.station,
      title: x.title,
      station: x.station,
      g: ST_GLYPH[x.type] || "tune",
      y: x.agent ? "" : YST[x.station] || "",
      img: x.img || undefined,
      agent: !!(x.agent && x.img),
      color: x.color || undefined,
    });
  }
  return out;
};
const wheelShakeImg = () => (S.wheel?.items || []).find((x) => x.control === "shake" && x.img)?.img || "";
// a release of the wheel → its album from the start (or from the track to continue with)
async function playWheelAlbum(x) {
  S.wavePreset = "al:" + x.album;
  markPresets();
  try {
    const r = await api("remote-playlist", { id: x.album });
    const list = r.tracks || [];
    if (!list.length) throw new Error("В альбоме нет доступных треков");
    const i = Math.max(
      0,
      list.findIndex((t) => t.id === x.from),
    );
    playList(list, i, { title: r.playlist?.title || x.title, go: "rplaylist:" + x.album });
    renderWaveSrc();
  } catch (e) {
    toast(e.message, 3000);
  }
}
const presetDesc = (x) => {
  const d = {};
  for (const f of [
    "k",
    "title",
    "sub",
    "station",
    "mood",
    "genre",
    "img",
    "color",
    "g",
    "y",
    "round",
    "agent",
    "likes",
    "seed",
    "album",
    "from",
  ])
    if (x[f] !== undefined && x[f] !== null && x[f] !== "" && x[f] !== false) d[f] = x[f];
  if (Array.isArray(x.c)) d.c = x.c;
  return d;
};
const presetPinned = (k) => (S.settings?.wavePins || []).some((p) => p.k === k);
const presetLiked = (k) => (S.settings?.waveLikes || []).some((p) => p.k === k);
// own glyphs get the colours of their own preset (several genres share one shape)
const OWN_C = Object.fromEntries(OWN_WHEEL.filter((x) => x.c).map((x) => [x.k, x.c]));
function wavePresets() {
  const pins = (S.settings?.wavePins || []).map((p) => ({ ...p }));
  const have = new Set(pins.map((p) => p.k));
  const set = (S.wheel?.items?.length ? stationItems() : ownWheel()).filter((x) => !have.has(x.k));
  for (const x of set) have.add(x.k);
  const half = Math.ceil(set.length / 2);
  const items = [...pins, ...set.slice(0, half)];
  const h = S.history.find((t) => t.cover) || S.history[0];
  if (h && !have.has("seed:" + h.id))
    items.push({
      k: "seed:" + h.id,
      sub: "Продолжить с трека",
      title: `${h.artist} — ${h.title}`,
      img: h.cover,
      seed: h,
    });
  items.push({ k: "back", title: "Назад к привычному", g: "back", act: waveBack });
  items.push({ k: "tune", title: "Настроить Мою волну", g: "tune", act: tuneWave, center: true });
  items.push({
    k: "shake",
    title: "Встряхнуть Мою волну",
    g: "shake",
    yimg: wheelShakeImg() || undefined,
    act: waveShake,
  });
  const seen = new Set(h ? [h.artist] : []),
    arts = [];
  for (const t of [...S.likes, ...S.history]) {
    if (arts.length >= 2) break;
    const a = (t.artists?.[0]?.name || t.artist || "").trim();
    if (!a || seen.has(a) || !t.cover || have.has("art:" + a)) continue;
    seen.add(a);
    arts.push({ k: "art:" + a, sub: "В стиле артиста", title: a, img: t.cover, round: true, seed: t });
  }
  if (arts[0]) items.push(arts[0]);
  if (S.likes.length && !have.has("likes"))
    items.push({
      k: "likes",
      sub: "Ваша коллекция",
      title: "Мне нравится вперемешку",
      img: S.likesCover || S.likes.find((t) => t.cover)?.cover,
      likes: !S.likesCover,
    });
  if (arts[1]) items.push(arts[1]);
  items.push(...set.slice(half));
  const inWheel = new Set(items.map((x) => x.k));
  for (const p of S.settings?.waveLikes || []) if (!inWheel.has(p.k) && items.length < 30) items.push({ ...p });
  for (const x of items) {
    x.pinned = presetPinned(x.k);
    x.liked = presetLiked(x.k);
    if (!x.c && OWN_C[x.k]) x.c = OWN_C[x.k];
    if (!x.act) x.act = x.album ? () => playWheelAlbum(x) : () => playPreset(x);
  }
  return items;
}
let WAVE_ITEMS = [];
// a preset of the wheel → its wave (the mood / genre / station is not saved as the setting of «Моя волна»)
function playPreset(x) {
  S.wavePreset = x.k;
  S.wavePresetInfo = presetDesc(x);
  markPresets();
  if (x.k === "likes") {
    S.shuffle = true;
    syncModes();
    playList(S.likes, Math.floor(Math.random() * S.likes.length), { title: "Мне нравится", go: "likes" });
    return renderWaveSrc();
  }
  renderWaveSrc(true);
  if (x.seed) return startWave({ seed: x.seed });
  if (x.mood && !x.genre)
    return startWave(x.station && S.settings.ymToken ? { mood: x.mood, station: x.station } : { mood: x.mood });
  startWave({ station: x.station || null, genre: x.genre || null });
}
async function waveMood(mood, station) {
  playPreset({ k: "m:" + mood, title: MOOD_LABEL[mood] || mood, mood, station });
}
function waveSeed(t, key) {
  playPreset({ k: key, title: `${t.artist} — ${t.title}`, img: t.cover, seed: t });
}
// «Назад к привычному»: the plain «Моя волна» with the default settings (mood «Любое», «Всё вперемешку»)
async function waveBack() {
  S.wavePreset = "";
  S.wavePresetInfo = null;
  markPresets();
  try {
    S.settings.wave = await api("wave-settings", { mood: "all", diversity: "default" });
  } catch {}
  renderWaveSrc();
  toast("Моя волна — как обычно", 1800);
  startWave({});
}
// «Встряхнуть Мою волну»: unfamiliar music this time (the settings stay)
function waveShake() {
  S.wavePreset = "shake";
  S.wavePresetInfo = { k: "shake", title: "Встряхнуть Мою волну", g: "shake", noMenu: true };
  markPresets();
  renderWaveSrc(true);
  startWave({ diversity: "discover" });
}
const markPresets = () => $$(".wv-item").forEach((b) => b.classList.toggle("on", b.dataset.k === S.wavePreset));
// the pill on top of the stage: the source list (when a playlist / album plays) or the chosen preset of the wheel
function renderWaveSrc(force) {
  const src = $("#wv-src");
  if (!src) return;
  const t = S.current;
  const fromList = !!(t && !S.wave && S.ctx);
  const p = (S.wave || force) && S.wavePresetInfo;
  src.innerHTML = fromList
    ? `<button class="wv-src-pill" data-go="${esc(S.ctx.go || "collection")}" title="Открыть источник">${icon("note")}<span>${esc(S.ctx.title)}</span>${icon("down")}</button><button class="wv-src-x" data-cmd="wave-return" title="Вернуться к Моей волне">${icon("close")}</button>`
    : p
      ? `<button class="wv-src-pill wv-pre${p.noMenu ? " no-menu" : ""}"${p.noMenu ? "" : ' data-cmd="wave-preset-menu" aria-haspopup="menu"'} title="${esc(p.title)}">${icon(presetPinned(p.k) ? "pushpin-on" : presetLiked(p.k) ? "heart" : "wave", "wp-ic")}<span>${esc(p.title)}</span>${p.noMenu ? "" : icon("down", "wp-dn")}</button><button class="wv-src-x" data-cmd="wave-preset-x" title="Вернуться к Моей волне">${icon("close")}</button>`
      : "";
}
function wavePresetMenu(e) {
  const p = S.wavePresetInfo;
  if (!p || p.noMenu) return;
  const pin = presetPinned(p.k),
    lk = presetLiked(p.k);
  const b = e.target?.closest?.(".wv-pre");
  const ev = b
    ? {
        preventDefault: () => e.preventDefault(),
        stopPropagation: () => e.stopPropagation(),
        target: b,
        clientX: 0,
        clientY: 0,
      }
    : e;
  menu(ev, [
    [pin ? "Открепить" : "Закрепить", pin ? "pushpin-on" : "pushpin", () => togglePresetPin(p)],
    [lk ? "Больше не нравится" : "Нравится", lk ? "heart" : "heart-o", () => togglePresetLike(p)],
    ["Поделиться", "link", () => sharePreset(p)],
  ]);
}
async function savePresets(key, list, max) {
  try {
    S.settings = await api("settings", { [key]: list.slice(0, max) });
  } catch (e) {
    toast(e.message, 3000);
  }
  renderWaveSrc();
  refreshWheel();
}
async function togglePresetPin(p) {
  const cur = S.settings?.wavePins || [],
    on = !cur.some((x) => x.k === p.k);
  await savePresets("wavePins", on ? [presetDesc(p), ...cur] : cur.filter((x) => x.k !== p.k), 8);
  toast(on ? `«${p.title}» закреплена в начале колеса` : `«${p.title}» откреплена`, 2400);
}
async function togglePresetLike(p) {
  const cur = S.settings?.waveLikes || [],
    on = !cur.some((x) => x.k === p.k);
  await savePresets("waveLikes", on ? [presetDesc(p), ...cur] : cur.filter((x) => x.k !== p.k), 40);
  toast(on ? `«${p.title}» нравится — она останется в колесе` : `«${p.title}» больше не в понравившихся`, 2400);
}
async function sharePreset(p) {
  const link = p.seed?.link || "";
  const text = `Моя волна «${p.title}»${p.sub ? " · " + p.sub : ""}${link ? " — " + link : ""} · слушаю в Wave`;
  const ok = await api("copy-text", { text }).catch(() => false);
  toast(ok ? "Скопировано в буфер обмена" : "Не удалось скопировать", 2200);
}
// the stations of the wheel are asked once per start (in the background); the open wheel is rebuilt when they come
async function loadWheel() {
  try {
    const r = await api("wave-wheel");
    if (r?.items?.length) {
      S.wheel = r;
      refreshWheel();
    }
  } catch {}
}
const WV_COPIES = 5; // the preset wheel is rendered several times and re-centred while scrolling → endless loop
const wheelItemHtml = (x, i) => {
  const ic = x.g
    ? wheelIcon(x.agent && x.img ? { ...x, yimg: x.img } : x)
    : x.img
      ? `<span class="wv-img${x.round ? " round" : ""}${x.likes ? " likes" : ""}${x.album ? " sq" : ""}" ${bg(x.img, "s")}>${x.likes ? icon("heart") : ""}</span>`
      : `<span class="wv-img${x.likes ? " likes" : ""}${x.album ? " sq" : ""}">${icon(x.likes ? "heart" : x.album ? "note" : "wave")}</span>`;
  const mark = x.pinned ? icon("pushpin-on", "wv-mk") : x.liked ? icon("heart", "wv-mk") : "";
  return `<button class="wv-item${x.img && !x.g ? " has-img" : ""}${x.g ? " st" : ""}${x.k === S.wavePreset ? " on" : ""}" data-wi="${i}" data-k="${esc(x.k)}">${ic}<span class="wv-tx">${x.sub ? `<small>${esc(x.sub)}</small>` : ""}<b>${mark}${esc(x.title)}</b></span></button>`;
};
function waveView() {
  WAVE_ITEMS = wavePresets();
  if (!S.wavePreset) S.wavePreset = S.wave ? "m:" + (S.settings.wave?.mood || "all") : "";
  setContent(
    `<div class="wv" id="wv"><div class="wv-left"><div class="wv-arc" id="wv-arc" tabindex="-1"></div></div>
    <div class="wv-stage" id="wv-stage"><div class="wv-src" id="wv-src"></div><div class="wv-lbl">Моя волна</div><h1 class="wv-title" id="wv-title">Моя волна</h1><div class="wv-now" id="wv-now"></div></div></div>`,
    { flush: true },
  );
  sizeStage();
  renderWaveNow();
  const arc = $("#wv-arc");
  arc.onclick = (e) => {
    const b = e.target.closest("[data-wi]");
    if (b) WAVE_ITEMS[+b.dataset.wi]?.act();
  };
  wheelScroll(arc);
  fillWheel(arc);
  const fit = () => {
    if (!arc.isConnected) return removeEventListener("resize", fit);
    WHEEL.fit?.();
    sizeStage();
    WaveFx.frame($("#wv-stage"));
    fitWaveTitle();
    fitWavePill();
  };
  addEventListener("resize", fit);
  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => (arc.isConnected ? fit() : ro.disconnect()));
    ro.observe($("#wv-stage"));
  }
  // Wait until the splash has gone before starting the expensive wave renderer.
  if (!document.querySelector("#splash:not(.out)")) WaveFx.start($("#wv-fx"), $("#wv-stage"));
}
// (re)fill the wheel and centre the chosen preset («Настроить Мою волну» when nothing is chosen)
function fillWheel(arc = $("#wv-arc")) {
  if (!arc) return;
  const one = WAVE_ITEMS.map(wheelItemHtml).join("");
  arc.innerHTML = Array(WV_COPIES).fill(one).join("");
  const n = WAVE_ITEMS.length;
  // a very tall window with few presets: more copies, so the loop never shows its end
  const H = arc.children[n] ? arc.children[n].offsetTop - arc.children[0].offsetTop : 0;
  if (H && arc.clientHeight > H * (WV_COPIES - 3))
    arc.insertAdjacentHTML("beforeend", one.repeat(Math.ceil(arc.clientHeight / H) + 3 - WV_COPIES));
  let ci = WAVE_ITEMS.findIndex((x) => x.k === S.wavePreset);
  if (ci < 0) ci = WAVE_ITEMS.findIndex((x) => x.center);
  WHEEL.center?.(Math.max(0, ci));
}
function refreshWheel() {
  const arc = $("#wv-arc");
  if (!arc || S.route !== "wave") return;
  // not under the pointer of someone scrolling it right now — a moment later
  if (performance.now() - WHEEL.touched < 1500) {
    clearTimeout(WHEEL.later);
    WHEEL.later = setTimeout(refreshWheel, 1600);
    return;
  }
  WAVE_ITEMS = wavePresets();
  fillWheel(arc);
}
/* 4.12: own smooth scrolling of the wheel. The browser scroll (with scroll-snap and smooth wheel scrolling) jumped back
   when the loop re-centred it during a smooth scroll and raced on fast flicks. Now one notch of the mouse wheel = one
   preset, the motion eases to it, fast flicks go at most three presets ahead, the scroll bar / keyboard settle on the
   nearest preset; the loop shifts the position and the target by exactly one copy, so the jump is never visible. */
const WHEEL = { pos: 0, tgt: 0, raf: 0, last: 0, snapT: 0, touched: 0, later: 0, fit: null, center: null };
function wheelScroll(arc) {
  const W = WHEEL;
  const n = () => WAVE_ITEMS.length || 1;
  const copyH = () => (arc.children[n()] ? arc.children[n()].offsetTop - arc.children[0].offsetTop : 0);
  const itemH = () => copyH() / n() || 112;
  const layout = () => {
    if (!arc.isConnected) return;
    const h = arc.clientHeight,
      mid = h / 2,
      top = arc.scrollTop;
    for (const el of arc.children) {
      const c = el.offsetTop - top + el.offsetHeight / 2;
      if (c < -200 || c > h + 200) continue;
      const dy = Math.max(-1.25, Math.min(1.25, (c - mid) / mid));
      const k = dy * dy;
      const shift = Math.round(k * 130);
      // Keep the shrinking row inside the wheel as it curves to the right.
      el.style.setProperty("--wv-shift", `${shift}px`);
      el.style.transform = `translateX(${shift}px) scale(${(1 - k * 0.1).toFixed(3)})`;
      el.style.opacity = Math.max(0, 1 - Math.pow(Math.abs(dy), 2.2) * 0.62).toFixed(3);
    }
  };
  // keep the position inside the second copy: [H, 2H)
  const norm = () => {
    const H = copyH();
    if (!H) return;
    while (W.pos < H) {
      W.pos += H;
      W.tgt += H;
    }
    while (W.pos >= 2 * H) {
      W.pos -= H;
      W.tgt -= H;
    }
  };
  const apply = () => {
    norm();
    arc.scrollTop = W.pos;
    // clamped by the browser (should not happen with enough copies) — continue from where it really is
    const got = arc.scrollTop;
    if (Math.abs(got - W.pos) > 1.5) W.pos = W.tgt = got;
    layout();
  };
  const step = (now) => {
    W.raf = 0;
    if (!arc.isConnected) return;
    const dt = W.last ? Math.min(0.05, (now - W.last) / 1000) : 1 / 60;
    W.last = now;
    W.pos += (W.tgt - W.pos) * (1 - Math.exp(-dt / 0.14));
    if (Math.abs(W.tgt - W.pos) < 0.5) W.pos = W.tgt;
    apply();
    if (W.pos !== W.tgt) W.raf = requestAnimationFrame(step);
    else W.last = 0;
  };
  const kick = () => {
    if (!W.raf) {
      W.last = 0;
      W.raf = requestAnimationFrame(step);
    }
  };
  const snap = () => {
    W.tgt = posOf(idxOf(W.tgt));
    kick();
  };
  // position of the preset with the (global) index i in the middle of the wheel, and back
  const posOf = (i) => (arc.children[0]?.offsetTop || 0) + i * itemH() + itemH() / 2 - arc.clientHeight / 2;
  const idxOf = (p) =>
    Math.round((p + arc.clientHeight / 2 - (arc.children[0]?.offsetTop || 0) - itemH() / 2) / itemH());
  let acc = 0,
    accT = 0;
  arc.addEventListener(
    "wheel",
    (e) => {
      if (e.ctrlKey) return;
      e.preventDefault();
      const now = performance.now();
      W.touched = now;
      let d = e.deltaY || e.deltaX;
      if (e.deltaMode === 1) d *= 36;
      else if (e.deltaMode === 2) d *= arc.clientHeight;
      // one notch of the mouse wheel (≈100 px) = one preset; touchpads: one preset per ~80 px of the swipe
      if (now - accT > 260 || Math.sign(d) !== Math.sign(acc)) acc = 0;
      accT = now;
      acc += d;
      let steps = 0;
      while (Math.abs(acc) >= 80) {
        steps += Math.sign(acc);
        acc -= Math.sign(acc) * 80;
      }
      if (!steps) return;
      // fast flicks: at most three presets ahead of where the wheel is now, so it never races off
      const base = idxOf(W.pos);
      W.tgt = posOf(Math.max(base - 3, Math.min(base + 3, idxOf(W.tgt) + steps)));
      clearTimeout(W.snapT);
      kick();
    },
    { passive: false },
  );
  // the scroll bar / keyboard / touch: follow what the browser did, then keep it in the loop
  arc.addEventListener("scroll", () => {
    if (Math.abs(arc.scrollTop - Math.round(W.pos)) <= 1) return;
    W.touched = performance.now();
    cancelAnimationFrame(W.raf);
    W.raf = 0;
    W.pos = W.tgt = arc.scrollTop;
    apply();
    clearTimeout(W.snapT);
    W.snapT = setTimeout(snap, 220);
  });
  W.center = (i) => {
    const el = arc.children[Math.floor(WV_COPIES / 2) * n() + i];
    if (!el) return;
    cancelAnimationFrame(W.raf);
    W.raf = 0;
    W.pos = W.tgt = el.offsetTop - (arc.clientHeight - el.offsetHeight) / 2;
    apply();
  };
  W.fit = layout;
}
// Under the wave: wait for the artist bio; if absent, introduce a modern-music fact first.
const BIO = new Map();
// Music facts: existing Wave fact sources plus GRAMMY and Apple Music album pages:
// https://www.grammy.com/news/billie-eilish-wins-best-pop-vocal-album-2020-grammys
// https://www.billboard.com/artist/billie-eilish
// https://music.apple.com/us/album/after-hours/1499385848
const MUSIC_FACTS = [
  // https://www.the-village.ru/weekend/musika/melon-music
  "Melon Music выросло из тюменской рэп-сцены и названо в память о Lil Melon",
  // https://the-flow.ru/new-flow/vol6-seemee
  "Seemee вспоминал, что в 16 лет выступил на разогреве у Гуфа",
  // https://the-flow.ru/new-flow/vol6-seemee
  "По словам Seemee, на жарком концерте Melon Music в Тюмени 17 зрителей потеряли сознание",
  // https://the-flow.ru/new-flow/vol6-mayot
  "Mayot работал звукорежиссёром и записывал других исполнителей",
  // https://the-flow.ru/features/og-buda-intervyu
  "OG Buda рассказывал, что вместе с Lil Melon искал собственный звук и учился работать с автотюном",
  // https://the-flow.ru/new-flow/vol7-bushido-zho
  "Bushido Zho в детстве любил танцевать и слушать Майкла Джексона",
  // https://the-flow.ru/new-flow/vol7-bushido-zho
  "Bushido Zho и Big Baby Tape познакомились ещё до большой известности",
  // https://the-flow.ru/new-flow/vol7-bushido-zho
  "Bushido Zho занимал деньги у мамы и подрабатывал, чтобы оплачивать записи на студии",
  // https://the-flow.ru/new-flow/vol8-toxis
  "Big Baby Tape стал одним из первых русских рэперов, которые зацепили Toxi$",
  // https://the-flow.ru/features/kto-takoy-aarne-i-kak-on-sobral-stolko-zvezd-u-sebya-na-albome
  "Продюсерский тег Aarne озвучил американский рэпер Winn Billion",
  // https://the-flow.ru/features/kto-takoy-aarne-i-kak-on-sobral-stolko-zvezd-u-sebya-na-albome
  "До работы под именем Aarne продюсер выпускал музыку как Octoberweather",
  // https://the-flow.ru/features/kto-takoy-aarne-i-kak-on-sobral-stolko-zvezd-u-sebya-na-albome
  "Aarne писал биты для Kizaru, Платины, Lil Krystalll и Obladaet",
  // https://the-flow.ru/features/10-klipov-kizaru
  "До псевдонима Kizaru рэпер выступал под именем Dealing Ounces",
  // https://the-flow.ru/features/10-klipov-kizaru
  "Kizaru основал объединение Haunted Family в Барселоне",
  // https://the-flow.ru/features/10-klipov-kizaru
  "Битмейкер White Punk раньше использовал имя PHVNTXM",
  // https://the-flow.ru/features/saluki-interview
  "Saluki рассказывал, что начал слушать русский рэп после знакомства с музыкой Скриптонита и Boulevard Depo",
  // https://the-flow.ru/features/saluki-afisha
  "Saluki сам писал и редактировал пояснения к своим песням на Genius",
  // https://the-flow.ru/features/saluki-afisha
  "Скриптонит помог Saluki со сведением песни «Улыбка»",
  // https://the-flow.ru/features/domu-s-normalnymi-yavleniyami-10-let-chto-izmenil-etot-albom
  "Скриптонит записывал «Дом с нормальными явлениями» в павлодарской квартире",
  // https://the-flow.ru/features/domu-s-normalnymi-yavleniyami-10-let-chto-izmenil-etot-albom
  "Скриптонит задумывал «Дом с нормальными явлениями» как историю с переходами между треками",
  // https://ufa.aif.ru/culture/art/i_face_i_morgenshtern_kak_ufa_stala_stolicey_russkogo_repa
  "Boulevard Depo увлекался граффити и сначала использовал имя Depo",
  // https://ufa.aif.ru/culture/art/i_face_i_morgenshtern_kak_ufa_stala_stolicey_russkogo_repa
  "Клип Pharaoh и Boulevard Depo «Champagne Squirt» стал вирусным и породил множество мемов",
  // https://the-flow.ru/new-flow/new-flow-vol3-gone-fludd
  "GONE.Fludd начинал в объединении Sabbat Cult, которое продвигало мрачный рэп",
  // https://the-flow.ru/features/flesh-interview
  "Flesh рассказывал, что первую музыку записывал в Adobe Audition, полученном на флешке",
  // https://the-flow.ru/features/friendly-thug-52-vpiska-2025
  "Friendly Thug 52 NGG рассказал, что получил высшее образование на факультете туризма",
  // https://the-flow.ru/news/vpiska-friendly-thug-52-ngg
  "Friendly Thug 52 NGG рассказывал, что написал часть альбома в монастыре",
  // https://the-flow.ru/features/friendly-thug-52-vpiska-2025
  "Friendly Thug 52 NGG говорил, что дружит и с OG Buda, и с Obladaet, несмотря на их биф",
  // https://the-flow.ru/features/huski-profile-2022
  "После отмены концерта Хаски исполнил песню на крыше автомобиля и был задержан",
  // https://the-flow.ru/features/zamay-2017
  "Псевдоним Хан Замай, по словам рэпера, придумал Слава КПСС",
  // https://au.rollingstone.com/music/music-news/russia-rappers-putin-war-ukraine-38458
  "Фирменный тег Slava Marlow звучит как «Слава, что ты сделал?»",
  // https://the-flow.ru/features/flesh-interview
  "Flesh связывал расцвет новой рэп-сцены с возможностью записывать музыку дома",
  // https://the-flow.ru/features/klassnyy-diss-na-og-buda-chto-rasskazal-boulevard-depo-v-podkaste-kosmicheskiy-dzhem
  "Boulevard Depo рассказывал, что впервые попал в студию по приглашению друга Pkhat",
];
const WAVE_STORY_FACTS = [
  "Wave создал один человек, а перенести приложение на Android и iOS помог ещё один человек",
  "Wave создал человек из объединения Arcane Squad",
  "Прототип логотипа Wave — Лилит, один из маскотов объединения Arcane Squad",
  "Любимое аниме создателя Wave — «Блич»",
];
function infoDeck(key, facts) {
  let st = null;
  try {
    st = JSON.parse(localStorage.getItem(key) || "null");
  } catch {}
  if (
    !st ||
    st.n !== facts.length ||
    !Array.isArray(st.deck) ||
    st.deck.length !== facts.length ||
    !(st.pos < facts.length)
  ) {
    const deck = [...Array(facts.length).keys()];
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    if (deck.length > 1 && deck[0] === st?.last) [deck[0], deck[1]] = [deck[1], deck[0]];
    st = { n: facts.length, deck, pos: 0, last: st?.last ?? null };
  }
  const index = st.deck[st.pos++];
  st.last = index;
  try {
    localStorage.setItem(key, JSON.stringify(st));
  } catch {}
  return facts[index];
}
function waveFact() {
  return Math.random() < 0.08
    ? infoDeck("wave.info.story", WAVE_STORY_FACTS)
    : infoDeck("wave.info.music", MUSIC_FACTS);
}
const WINFO = { id: null, phase: "", fact: "", timer: 0, serial: 0 };
function fitWaveInfo(p) {
  if (!p?.isConnected) return;
  p.style.width = "";
  const range = document.createRange();
  range.selectNodeContents(p);
  const lines = [...range.getClientRects()].filter((r) => r.width > 0);
  if (lines.length > 1) p.style.width = Math.ceil(Math.max(...lines.map((r) => r.width)) + 2) + "px";
}
window.addEventListener("resize", () => requestAnimationFrame(() => fitWaveInfo($("#wv-now .wv-info p"))));
function setWaveInfo(p, text, html = false) {
  if (!p) return;
  const spark = p.parentElement?.querySelector(".wv-spark");
  const before = spark?.getBoundingClientRect();
  if (html) p.innerHTML = text; else p.textContent = text;
  fitWaveInfo(p);
  if (!before || S.settings?.animation === false || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const after = spark.getBoundingClientRect();
  if (Math.abs(before.left - after.left) > .5 || Math.abs(before.top - after.top) > .5) {
    spark.getAnimations().forEach((a) => a.cancel());
    spark.animate([{ transform: `translate(${before.left - after.left}px, ${before.top - after.top}px)` }, { transform: "none" }], {duration: 400, easing: "cubic-bezier(.2,.8,.2,1)"});
  }
}

function waveInfo(t) {
  if (!t) {
    clearTimeout(WINFO.timer);
    WINFO.id = null;
    WINFO.serial++;
    return esc(waveFact());
  }
  if (WINFO.id !== t.id) {
    clearTimeout(WINFO.timer);
    Object.assign(WINFO, { id: t.id, phase: "", fact: "", timer: 0, serial: WINFO.serial + 1 });
  }
  const name = cutName(t);
  const bio = name ? BIO.get(name) : "";
  if (name && bio === undefined) {
    BIO.set(name, null);
    api("artist-bio", { name, id: t.artists?.[0]?.id || "" })
      .catch(() => "")
      .then((text) => {
        BIO.set(name, text || "");
        if (BIO.size > 200) BIO.delete(BIO.keys().next().value);
        const p = $("#wv-now .wv-info p");
        if (p && S.current && cutName(S.current) === name) setWaveInfo(p, waveInfo(S.current), true);
      });
  }
  if (bio === undefined || bio === null) return "Ищем информацию об исполнителе…";
  if (bio) return esc(bio);
  if (!WINFO.phase) {
    WINFO.phase = "intro";
    WINFO.fact = waveFact();
    const serial = WINFO.serial;
    let elapsed = 0,
      last = performance.now();
    const tick = () => {
      if (WINFO.serial !== serial || S.current?.id !== t.id) return;
      const now = performance.now();
      if (!S.bg && !document.hidden && $("#wv-now .wv-info p")) elapsed += Math.min(300, now - last);
      last = now;
      if (elapsed < 3500) {
        WINFO.timer = setTimeout(tick, 250);
        return;
      }
      WINFO.phase = "fact";
      const p = $("#wv-now .wv-info p");
      if (!p) return;
      const instant = S.settings?.animation === false || matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (instant) return void setWaveInfo(p, WINFO.fact);
      p.classList.add("wi-out");
      setTimeout(() => {
        if (!p.isConnected || WINFO.serial !== serial || S.current?.id !== t.id) return;
        setWaveInfo(p, WINFO.fact);
        p.classList.remove("wi-out");
        p.classList.add("wi-in");
        p.addEventListener("animationend", () => p.classList.remove("wi-in"), { once: true });
      }, 260);
    };
    WINFO.timer = setTimeout(tick, 250);
  }
  return esc(WINFO.phase === "fact" ? WINFO.fact : "Упс… Ничего не нашли про артиста, но у нас для вас кое-что есть.");
}
// narrow stages: smaller round buttons so the track pill keeps room for the name
function sizeStage() {
  const st = $("#wv-stage");
  if (!st) return;
  const w = st.clientWidth;
  st.classList.toggle("narrow", w < 760);
  st.classList.toggle("tiny", w < 600);
  st.classList.toggle("mini", w < 500);
}
// long artist names: shrink the big title until it fits; if even 48 px is too wide — two lines
function fitWaveTitle() {
  const ttl = $("#wv-title");
  if (!ttl || !ttl.isConnected) return;
  ttl.style.fontSize = "";
  ttl.classList.remove("wrap");
  if (!ttl.classList.contains("artist")) return;
  let fs = parseFloat(getComputedStyle(ttl).fontSize) || 100;
  for (let n = 0; n < 16 && fs > 42 && ttl.scrollWidth > ttl.clientWidth + 1; n++) {
    fs = Math.max(42, fs * 0.92);
    ttl.style.fontSize = fs + "px";
  }
  if (ttl.scrollWidth <= ttl.clientWidth + 1) return;
  ttl.classList.add("wrap");
  fs = Math.min(fs, 76);
  ttl.style.fontSize = fs + "px";
  for (
    let n = 0;
    n < 12 && fs > 34 && (ttl.scrollHeight > ttl.clientHeight + 2 || ttl.scrollWidth > ttl.clientWidth + 1);
    n++
  ) {
    fs = Math.max(34, fs * 0.92);
    ttl.style.fontSize = fs + "px";
  }
}
// the track pill: the whole «artist — title» is shown — it scrolls back and forth when it does not fit
function fitWavePill() {
  const tx = $("#wv-now .wpill-tx");
  if (!tx || !tx.isConnected) return;
  tx.classList.remove("marq");
  tx.style.removeProperty("--mq");
  if (tx.scrollWidth <= tx.clientWidth + 1 || document.body.classList.contains("no-anim")) return;
  tx.classList.add("marq");
  const over = tx.scrollWidth - tx.clientWidth;
  if (over <= 1) return tx.classList.remove("marq");
  tx.style.setProperty("--mq", -over + "px");
  tx.style.setProperty("--mqd", (7 + over / 26).toFixed(1) + "s");
}
const volHtml = (btn) =>
  `<div class="vol-wrap up"><button class="${btn}" data-cmd="mute" data-np="volicon" title="Звук">${icon(muted || vol === 0 ? "mute" : "volume")}</button><div class="vol-pop vert"><div class="bar vol" data-vol data-vert><i class="bar-mark"></i><div class="bar-fill" data-np="vol"><i></i></div></div><span class="vol-val" data-np="volval"></span></div></div>`;
// big title: «Моя волна», or the artist when a playlist plays / the artist cut-out is shown (Yandex style)
function waveTitle() {
  const t = S.current;
  const st = $("#wv-stage");
  const fromList = !!(t && !S.wave && S.ctx);
  // 4.9.1: like Yandex Music — the artist while a track plays (with or without a photo), «Моя волна» on pause
  const art = !!t && (fromList || !audio.paused || !!S.mobileSwitching || !!st?.classList.contains("cut"));
  st?.classList.toggle("list", fromList);
  const ttl = $("#wv-title");
  if (!ttl) return;
  const txt = art ? (t.artist || t.artists?.map((a) => a.name).join(", ") || "").trim() || "Моя волна" : "Моя волна";
  const key = art ? "a:" + t.id : "w";
  if (ttl.dataset.key !== key) {
    ttl.dataset.key = key;
    // the big artist title is a link too (several artists → several links)
    ttl.innerHTML = art ? artistsHtml(t) || esc(txt) : esc(txt);
  }
  ttl.classList.toggle("artist", art);
  fitWaveTitle();
}

/* ---------- 4.7: «Моя волна» while a track PLAYS — the artist cut out of a photo (only the person, no background),
   the cover stays small in front of it; on pause everything is as before. The cut-out is made on this PC
   (main process, worker thread) and cached; artists without a usable photo keep the usual view. ---------- */
const CUT = { cache: new Map(), want: "", late: null };
const cutName = (t) =>
  (
    t?.artists?.[0]?.name ||
    String(t?.artist || "").split(/\s*(?:,|;|&|\/|\bfeat\.?|\bft\.?|\bx\b|\bи\b)\s*/i)[0] ||
    ""
  ).trim();
function waveCut(force) {
  const st = $("#wv-stage");
  if (!st) return;
  const t = S.current;
  const name = t && !audio.paused && S.settings.waveCutout !== false && root.dataset.waveEconomy !== "1" ? cutName(t) : "";
  // a short pause between tracks or while seeking must not flash the title in and out
  if (!name && !force && st.classList.contains("cut") && t && S.settings.waveCutout !== false && root.dataset.waveEconomy !== "1") {
    clearTimeout(CUT.late);
    CUT.late = setTimeout(() => waveCut(true), 400);
    return;
  }
  clearTimeout(CUT.late);
  let box = $("#wv-cut");
  if (!box) {
    box = document.createElement("div");
    box.className = "wv-cut";
    box.id = "wv-cut";
    box.setAttribute("aria-hidden", "true");
    box.innerHTML = `<img alt="" draggable="false">`;
    st.prepend(box);
  }
  const r = name ? CUT.cache.get(name) : null;
  if (name && r === undefined && CUT.want !== name) {
    CUT.want = name;
    api("artist-cutout", { name, id: t.artists?.[0]?.id || "" })
      .catch(() => null)
      .then((res) => {
        CUT.cache.set(name, res && res.url ? res : null);
        if (CUT.cache.size > 40) CUT.cache.delete(CUT.cache.keys().next().value);
        if (CUT.want === name) CUT.want = "";
        waveCut();
      });
  }
  const img = box.firstChild;
  if (r && img.dataset.name !== name) {
    img.dataset.name = name;
    img.dataset.ok = "";
    img.onload = () => {
      if (img.dataset.name !== name) return;
      img.dataset.ok = "1";
      waveCut();
    };
    img.onerror = () => {
      CUT.cache.set(name, null);
      waveCut();
    };
    box.classList.toggle("float", !r.bottom);
    img.src = r.url;
  }
  const show = !!r && img.dataset.name === name && img.dataset.ok === "1";
  if (st.classList.contains("cut") !== show) {
    st.classList.toggle("cut", show);
    waveTitle();
  }
}
function renderWaveNow() {
  const box = $("#wv-now");
  if (!box) return;
  const t = S.current;
  const liked = t && S.likeSet.has(t.id);
  // On Android, don't destroy the controls again when the same track finishes loading.
  const mobileKey = document.documentElement.hasAttribute("data-mobile") ? JSON.stringify([t?.id, t?.title, t?.artist, t?.cover]) : null;
  if (mobileKey && box.dataset.mobileTrack === mobileKey && box.querySelector(".m-wplay")) {
    waveCut(); waveTitle();
    if (t && LY.cache.has(t.id)) markLyBtns(LY.cache.get(t.id));
    fitWavePill(); renderWaveSrc(); syncVolUi();
    return;
  }
  if (mobileKey) box.dataset.mobileTrack = mobileKey;
  // 4.11: the cover opens the page of the track (or of its album), the ⤢ button — the full player
  box.innerHTML = `<button class="wv-cover fp-src${t ? "" : " none"}" id="wv-cover" data-cmd="cur-page" ${t?.cover ? bg(t.cover, "m") : ""} title="${t && albumOf(t) ? "Открыть альбом" : "Открыть страницу трека"}"${t ? "" : ' tabindex="-1" aria-hidden="true"'}>${t && !t.cover ? `<img src="${LOGO.url}" alt="" data-logo>` : ""}</button>
  <div class="wv-row">
    ${mobileKey ? `<button class="wbtn m-wplay" data-cmd="play" title="${audio.paused ? "Играть" : "Пауза"}" aria-label="Воспроизведение">${icon(audio.paused ? "play" : "pause")}</button>` : ""}
    <button class="wbtn" data-cmd="full" title="Развернуть плеер">${icon("expand")}</button>
    ${volHtml("wbtn")}
    <button class="wbtn" data-cmd="dislike" title="Не рекомендовать">${icon("dislike")}</button>
    <div class="wpill${t ? "" : " idle"}"${t ? ` data-seek role="slider" tabindex="0" aria-label="Перемотка: ${esc(t.artist + " — " + t.title)}"` : ""}><span class="wpill-track"><i class="wpill-fill" data-np="fill" style="transform:${fillTf(t ? curPct() : 0)}"></i><i class="wpill-ghost"></i></span><span class="wpill-tx"><span class="wpill-in">${t ? esc(t.title) : "Моя волна ждёт"}</span></span><b class="wpill-tip"></b></div>
    <button class="wbtn${liked ? " on" : ""}" data-cmd="like" title="Нравится">${icon(liked ? "heart" : "heart-o")}</button>
    <button class="wbtn${lyOpen() ? " on" : ""}" data-cmd="lyrics" title="Текст песни">${icon("lyrics")}</button>
    <button class="wbtn" data-cmd="cur-menu" title="Ещё">${icon("more")}</button>
  </div>
  <div class="wv-ctl">
    <button data-cmd="shuffle" class="${S.shuffle ? "on" : ""}" title="Перемешать">${icon("shuffle")}</button>
    <button data-cmd="prev" title="Предыдущий">${icon("prev")}</button>
    <button class="wv-play" data-cmd="wave-play" title="${t && !audio.paused ? "Пауза" : "Играть"}">${icon(t && !audio.paused ? "pause" : "play")}</button>
    <button data-cmd="next" title="Следующий">${icon("next")}</button>
    <button data-cmd="repeat" class="${S.repeat !== "off" ? "on" : ""}${S.repeat === "one" ? " one" : ""}" title="Повтор">${icon("repeat")}<i class="one">1</i></button>
  </div>
  <div class="wv-info"><span class="wv-spark">${icon("spark")}</span><p>${waveInfo(t)}</p></div>`;
  fitWaveInfo($("#wv-now .wv-info p"));
  waveCut();
  waveTitle();
  if (t && LY.cache.has(t.id)) markLyBtns(LY.cache.get(t.id));
  fitWavePill();
  renderWaveSrc();
  syncVolUi();
}

/* ---------------- track panel (new interface): album, lyrics, similar tracks — like Yandex Music ---------------- */
const TP = { open: false, t: null, ctx: null, seq: 0, follow: false, out: null };
const TRACKS = new Map(); // id → track, for the «track:» page
const lyricsCache = async (t) => {
  let d = LY.cache.get(t.id);
  if (d) return d;
  const via = S.current?.id === t.id && S.stream?.via && S.stream.via.id !== t.id ? S.stream.via : null;
  d = await api("lyrics", { track: t, via });
  LY.cache.set(t.id, d);
  if (LY.cache.size > 80) LY.cache.delete(LY.cache.keys().next().value);
  return d;
};
const infoCache = new Map();
async function trackInfo(t) {
  if (infoCache.has(t.id)) return infoCache.get(t.id);
  const r = (await api("track-info", { track: t })) || { similar: [] };
  infoCache.set(t.id, r);
  if (infoCache.size > 60) infoCache.delete(infoCache.keys().next().value);
  return r;
}
function lyPreview(d, full) {
  if (!d || d.error || d.instrumental || !d.lines?.length)
    return `<p class="tp-muted">${d?.instrumental ? "Инструментальная композиция" : "Текст не найден"}</p>`;
  const lines = d.lines.filter((l) => l.text).map((l) => esc(l.text));
  if (full) return `<div class="tp-ly full">${lines.join("<br>")}</div>`;
  return `<div class="tp-ly">${lines
    .slice(0, 4)
    .map((l, i) => `<span style="opacity:${[1, 0.75, 0.5, 0.25][i]}">${l}</span>`)
    .join("")}</div>${lines.length > 4 ? '<button class="tp-more" data-tp="ly-full">Читать полностью</button>' : ""}`;
}
function albumHtml(a) {
  if (!a) return "";
  const go = a.id ? `data-go="rplaylist:${esc(a.id)}"` : "";
  return `<section class="tp-sec"><h3>Альбом</h3><button class="tp-album" ${go}${a.id ? "" : " disabled"}><span class="tp-ac" ${bg(a.cover, "s")}>${a.cover ? "" : icon("album")}</span><span class="tp-at"><b>${esc(a.title)}${a.id ? icon("right") : ""}</b><small>${a.count ? plural(a.count, "трек", "трека", "треков") : a.year || "Альбом"}</small></span></button></section>`;
}
function openTrackPanel(t, ctx = {}) {
  if (!t) return;
  if (spDesk() && !$("#queue").hidden) toggleQueue();
  let el = $("#tpanel");
  if (!el) {
    el = document.createElement("aside");
    el.id = "tpanel";
    el.className = "tpanel";
    $(".main").appendChild(el);
  }
  TRACKS.set(t.id, t);
  if (TP.open && TP.t?.id === t.id && !ctx.follow) return;
  TP.open = true;
  $(".main")?.classList.add("sp-panel-open");
  $$('[data-cmd="track-panel"]').forEach((b) => { b.classList.add("on"); b.setAttribute("aria-pressed", "true"); });
  TP.t = t;
  TP.ly = null;
  TP.lyFullRequested = false;
  TP.ctx = ctx.list ? ctx : null;
  TP.follow = !ctx.list || !!ctx.follow; // the panel of the playing track follows the next tracks
  const my = ++TP.seq;
  const [m, v] = splitTitle(t.title);
  const liked = S.likeSet.has(t.id);
  const playing = S.current?.id === t.id && !audio.paused;
  el.innerHTML = `<div class="tp-head"><span>${esc(t.id === S.current?.id ? (S.wave ? "Моя волна" : S.ctx?.title || "Текущий трек") : "Трек")}</span><button class="tp-x" data-tp="close" title="Закрыть">${icon("close")}</button></div>
  <div class="tp-scroll">
    <div class="tp-cover"${t.cover ? ` data-zoom="${esc(t.cover)}" aria-label="${esc(t.title)}" title="Открыть обложку"` : ""} ${bg(t.cover, "l")}>${t.cover ? "" : icon("note")}</div>
    <h2 class="tp-title" data-tp="page" title="${albumOf(t) ? "Открыть альбом" : "Открыть страницу трека"}">${esc(m)}${v ? ` <span class="tv">${esc(v)}</span>` : ""}</h2>
    <div class="tp-artists">${artistsHtml(t)}</div>
    ${S.current?.id === t.id ? `<p class="tp-q" id="tp-q" title="${esc(srcTip(t, S.stream))}">${esc(srcBadge(t, S.stream))}</p>` : ""}
    <div class="tp-acts"><button class="pill-acc tp-play" data-tp="play">${icon(playing ? "pause" : "play")}${playing ? "Пауза" : "Слушать"}</button><button class="gbtn tp-like${liked ? " on" : ""}" data-tp="like" title="Нравится">${icon(liked ? "heart" : "heart-o")}</button><button class="gbtn tp-dislike${S.dislikes.has(t.id) ? " on" : ""}" data-tp="dislike" title="Не рекомендовать" aria-label="Не рекомендовать">${icon("dislike")}</button><button class="gbtn" data-tp="lyrics" title="Текст песни" aria-label="Текст песни">${icon("lyrics")}</button><button class="gbtn" data-tp="menu" title="Ещё" aria-label="Ещё">${icon("more")}</button></div>
    <div id="tp-album"></div>
    <section class="tp-sec" id="tp-lyrics"><h3>Текст</h3><div class="skel" style="height:86px;border-radius:12px"></div></section>
    <section class="tp-sec" id="tp-sim"><h3>Похожие треки</h3>${skel(4)}</section>
  </div>`;
  TP.out?.cancel();
  TP.out = null;
  if (!el.classList.contains("on")) {
    el.classList.add("on");
    // slides in a little and fades in (4.6: no long slide across the whole window)
    if (S.settings?.animation !== false)
      el.animate(
        [
          { transform: "translateX(36px)", opacity: 0 },
          { transform: "none", opacity: 1 },
        ],
        { duration: 300, easing: "cubic-bezier(.2,.8,.2,1)" },
      );
  }
  trackInfo(t)
    .catch(() => ({ album: null, similar: [] }))
    .then((info) => {
      if (my !== TP.seq) return;
      $("#tp-album").innerHTML = albumHtml(info.album);
      const sim = (info.similar || []).filter((x) => !S.dislikes.has(x.id));
      $("#tp-sim").innerHTML = sim.length
        ? `<h3>Похожие треки</h3>${tracksHtml(sim, { hot: false })}`
        : '<h3>Похожие треки</h3><p class="tp-muted">Не нашёл похожих треков</p>';
      lazyScan();
    });
  lyricsCache(t)
    .catch((e) => ({ lines: [], error: e.message }))
    .then((d) => {
      if (my !== TP.seq) return;
      TP.ly = d;
      const box = $("#tp-lyrics");
      if (box) box.innerHTML = "<h3>Текст</h3>" + lyPreview(d, !!TP.lyFullRequested);
    });
}
function closeTrackPanel(instant) {
  const el = $("#tpanel");
  TP.open = false;
  $(".main")?.classList.remove("sp-panel-open");
  $$('[data-cmd="track-panel"]').forEach((b) => { b.classList.remove("on"); b.setAttribute("aria-pressed", "false"); });
  TP.seq++;
  if (!el || !el.classList.contains("on")) return;
  if (instant === true || S.settings?.animation === false) {
    TP.out?.cancel();
    TP.out = null;
    el.classList.remove("on");
    el.innerHTML = "";
    return;
  }
  if (TP.out) return;
  TP.out = el.animate(
    [
      { transform: "none", opacity: 1 },
      { transform: "translateX(36px)", opacity: 0 },
    ],
    { duration: 220, easing: "cubic-bezier(.4,0,1,1)", fill: "forwards" },
  );
  TP.out.onfinish = () => {
    const a = TP.out;
    TP.out = null;
    if (TP.open) return a?.cancel();
    el.classList.remove("on");
    el.innerHTML = "";
    a?.cancel();
  };
}
/* ---------- 4.6: cover lightbox (track panel, track / playlist / album pages) ---------- */
const lboxOpen = () => !!$("#lbox") && !$("#lbox").hidden && !$("#lbox")._out;
// 4.9: `gallery` — several pictures (artist photos): arrows, keys ← →, swipe / drag, counter
const LB = { list: null, i: 0 };
function lbSrc(img, url) {
  // the small cached picture first, the big one replaces it once loaded (no empty frame)
  const big = thumb(url, "x");
  img.src = thumb(url, "m");
  if (img.src !== big) {
    const pre = new Image();
    pre.onload = () => img.isConnected && img.dataset.u === url && (img.src = big);
    pre.src = big;
  }
  img.dataset.u = url;
}
function lbStep(dir) {
  const el = $("#lbox");
  if (!LB.list || !el || el.hidden) return;
  const n = LB.list.length;
  LB.i = (LB.i + dir + n) % n;
  const img = el.querySelector(".lbox-img");
  lbSrc(img, LB.list[LB.i]);
  const cnt = el.querySelector(".lbox-cnt");
  if (cnt) cnt.textContent = LB.i + 1 + " / " + n;
  if (S.settings?.animation !== false)
    img.animate(
      [
        { transform: `translateX(${dir * 46}px)`, opacity: 0.35 },
        { transform: "none", opacity: 1 },
      ],
      { duration: 240, easing: "cubic-bezier(.2,.8,.2,1)" },
    );
}
function coverLightbox(url, title = "", gallery = null) {
  if (!url) return;
  let el = $("#lbox");
  if (!el) {
    el = document.createElement("div");
    el.id = "lbox";
    el.className = "lbox";
    el.setAttribute("role", "dialog");
    el.onclick = (e) => {
      const nb = e.target.closest("[data-lb]");
      if (nb) return lbStep(+nb.dataset.lb);
      if (!e.target.closest(".lbox-img") && !el._drag) closeLightbox();
    };
    // swipe / drag the picture sideways → the next / previous one
    el.addEventListener("pointerdown", (e) => {
      const img = e.target.closest(".lbox-img");
      if (!img || !LB.list || e.button !== 0) return;
      const x0 = e.clientX;
      let dx = 0;
      img.setPointerCapture(e.pointerId);
      const move = (ev) => {
        dx = ev.clientX - x0;
        img.style.transform = `translateX(${dx * 0.6}px)`;
      };
      const up = () => {
        img.removeEventListener("pointermove", move);
        img.style.transform = "";
        el._drag = Math.abs(dx) > 8;
        setTimeout(() => (el._drag = false), 0);
        if (Math.abs(dx) > 60) lbStep(dx < 0 ? 1 : -1);
      };
      img.addEventListener("pointermove", move);
      img.addEventListener("pointerup", up, { once: true });
      img.addEventListener("pointercancel", up, { once: true });
    });
    el.addEventListener(
      "wheel",
      (e) => {
        if (!LB.list || Math.abs(e.deltaX) < 30 || Math.abs(e.deltaX) < Math.abs(e.deltaY)) return;
        if (performance.now() - (el._wh || 0) < 350) return;
        el._wh = performance.now();
        lbStep(e.deltaX > 0 ? 1 : -1);
      },
      { passive: true },
    );
    document.body.appendChild(el);
  }
  el._out?.cancel();
  el._out = null;
  const list = Array.isArray(gallery) && gallery.length > 1 ? gallery : null;
  LB.list = list;
  LB.i = list ? Math.max(0, list.indexOf(url)) : 0;
  el.classList.toggle("gal", !!list);
  el.setAttribute("aria-label", title || "Обложка");
  el.innerHTML = `<img class="lbox-img" alt="${esc(title)}" draggable="false"><button class="lbox-x" title="Закрыть (Esc)">${icon("close")}</button>${list ? `<button class="lbox-nav prev" data-lb="-1" title="Предыдущее фото (←)">${icon("left")}</button><button class="lbox-nav next" data-lb="1" title="Следующее фото (→)">${icon("right")}</button><div class="lbox-cnt">${LB.i + 1} / ${list.length}</div>` : ""}`;
  const img = el.firstChild;
  lbSrc(img, list ? list[LB.i] : url);
  el.hidden = false;
  if (S.settings?.animation !== false) {
    el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 200, easing: "ease-out" });
    img.animate(
      [
        { transform: "scale(.92)", opacity: 0 },
        { transform: "none", opacity: 1 },
      ],
      { duration: 260, easing: "cubic-bezier(.2,.8,.2,1)" },
    );
  }
}
function closeLightbox() {
  const el = $("#lbox");
  if (!el || el.hidden || el._out) return;
  if (S.settings?.animation === false) return void (el.hidden = true);
  el._out = el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 160, easing: "ease-in", fill: "forwards" });
  el._out.onfinish = () => {
    const a = el._out;
    el._out = null;
    el.hidden = true;
    a.cancel();
  };
}
function tpAction(a, e) {
  const t = TP.t;
  if (a === "close") return closeTrackPanel();
  if (!t) return;
  if (a === "play") {
    if (S.current?.id === t.id) return togglePlay();
    if (TP.ctx?.list && TP.ctx.lid !== "q") return playList(TP.ctx.list, TP.ctx.i);
    if (TP.ctx?.lid === "q") return playAt(TP.ctx.i);
    return playList([t], 0, { title: t.title, go: "track:" + t.id });
  }
  if (a === "like") return toggleLike(t);
  if (a === "dislike") return dislike(t);
  if (a === "lyrics") {
    TP.lyFullRequested = true;
    const box = $("#tp-lyrics");
    if (box) {
      if (TP.ly) box.innerHTML = "<h3>Текст</h3>" + lyPreview(TP.ly, true);
      box.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    return;
  }
  if (a === "menu") return trackMenu(e, t);
  if (a === "page") return openTrack(t);
  if (a === "ly-full") {
    const box = $("#tp-lyrics");
    if (box) box.innerHTML = "<h3>Текст</h3>" + lyPreview(TP.ly, true);
  }
}
// «track:» page: hero + lyrics + similar tracks
async function trackView(id) {
  const t = TRACKS.get(id) || (S.current?.id === id ? S.current : null);
  if (!t) return setContent('<div class="empty"><b>Трек не найден</b>Откройте его заново из списка</div>');
  const [m, v] = splitTitle(t.title);
  S.pageTitle = { route: S.route, title: t.title };
  // 4.9: the track itself as a row under the header (like Yandex Music): number, title, ⓘ, like, duration
  const oneRow = trackRow(t, reg([t]), 0, { num: true }).replace(
    '<button class="icon-btn lk',
    (isGlass() ? `<button class="icon-btn inf" data-act="info" title="О треке">${icon("info")}</button>` : "") +
      '<button class="icon-btn lk',
  );
  setContent(
    `${listHero({ cover: t.cover, iconName: "note", kind: "Трек", title: m + (v ? " (" + v + ")" : ""), meta: `${artistsHtml(t)}${t.duration ? " · " + fmt(t.duration) : ""}${t.album ? " · " + esc(t.album) : ""}`, actions: `<button class="pill-acc" id="trp">${icon("play")}Слушать</button>${gbtn("trl", S.likeSet.has(t.id) ? "heart" : "heart-o", "Нравится")}${gbtn("trm", "more", "Ещё")}` })}
    <section class="section trk-one"><div class="tracks">${oneRow}</div></section>
    <div class="trk-grid"><section class="section"><div class="sec-head"><h2>Похожие треки</h2></div><div id="trk-sim">${skel(6)}</div></section><section class="section"><div class="sec-head"><h2>Текст</h2></div><div id="trk-ly" class="trk-ly">${skel(4)}</div></section></div><div id="trk-rel"></div>`,
  );
  if (isSpotify()) { $(".trk-one").insertAdjacentHTML("afterbegin", '<div class="sp-table-head"><span>#</span><span>Название</span><span>Продолжительность</span></div>'); spotifyReleaseColor(t.cover, t.colors); }
  const route = S.route;
  $("#trp").onclick = () => (S.current?.id === t.id ? togglePlay() : playList([t], 0));
  $("#trl").onclick = () =>
    toggleLike(t).then(() => ($("#trl").innerHTML = icon(S.likeSet.has(t.id) ? "heart" : "heart-o")));
  $("#trm").onclick = (e) => trackMenu(e, t);
  trackInfo(t)
    .catch(() => ({ similar: [] }))
    .then((info) => {
      if (S.route !== route) return;
      $("#trk-sim").innerHTML = info.similar?.length
        ? tracksHtml(info.similar, { hot: false })
        : '<div class="empty">Не нашёл похожих треков</div>';
      // 4.10: release date and label of the album (Yandex Music), like at the bottom of a Yandex page
      const al = info.album;
      const rel = releaseHtml(al);
      if (al && (rel || al.id))
        $("#trk-rel").innerHTML = rel
          ? rel.replace(
              '<div class="rel-foot">',
              `<div class="rel-foot">${al.id ? `<span>Альбом: <a data-go="rplaylist:${esc(al.id)}">${esc(al.title)}</a></span>` : ""}`,
            )
          : "";
      lazyScan();
    });
  lyricsCache(t)
    .catch((e) => ({ lines: [], error: e.message }))
    .then((d) => {
      if (S.route !== route) return;
      $("#trk-ly").innerHTML = d?.lines?.length
        ? d.lines.map((l) => (l.text ? esc(l.text) : "")).join("<br>")
        : `<div class="empty">${d?.instrumental ? "Инструментальная композиция" : "Текст не найден"}</div>`;
    });
}
/* ---------------- global delegation ---------------- */
const CMD = {
  play: () => togglePlay(),
  "wave-play": () => (S.current ? togglePlay() : startWave(S.waveOpts || {})),
  "sp-wave-play": () => (S.wave && S.current ? togglePlay() : startWave(S.waveOpts || {})),
  "wave-return": () => {
    S.wavePreset = "m:" + (S.settings.wave?.mood || "all");
    S.wavePresetInfo = null;
    markPresets();
    startWave({});
  },
  // 4.12: the pill of the chosen preset: ⌄ — «Закрепить» / «Нравится» / «Поделиться», ✕ — back to the plain wave
  "wave-preset-menu": (e) => wavePresetMenu(e),
  "wave-preset-x": () => {
    S.wavePreset = "";
    S.wavePresetInfo = null;
    markPresets();
    renderWaveSrc();
    startWave({});
  },
  lyrics: (e, c) => {
    const d = S.current && LY.cache.get(S.current.id);
    if ($("#lyrics").hidden && lyNone(d))
      return toast(
        d.instrumental ? "Инструментальная композиция — в ней нет слов" : "Для этого трека текста нет",
        2200,
      );
    // 4.11: «текст» on the cover of the lyrics screen → the usual full player (even when the lyrics were opened
    // from the mini player); the ⌄ button in the corner still closes back to where they were opened from
    toggleLyrics(undefined, { toFull: !!c?.closest?.(".ly-cover") });
  },
  sound: (e, c) => openSound(c),
  next: () => next(),
  prev: () => prev(),
  like: () => S.current && toggleLike(S.current),
  dislike: () => S.current && dislike(S.current),
  shuffle: () => {
    S.shuffle = !S.shuffle;
    syncModes();
  },
  repeat: () => {
    S.repeat = { off: "all", all: "one", one: "off" }[S.repeat];
    syncModes();
  },
  mute: () => {
    muted = !muted;
    setVol(vol);
  },
  queue: () => (spDesk() ? toggleQueue() : isGlass() ? toggleQueueView() : toggleQueue()),
  full: () => {
    if (!S.current) return openFull();
    if (lyOpen() || (!fpEl().hidden && !fpEl()._closing) || !vtOk()) return openFull();
    morph(() => openFull({ instant: true }), { kind: "ly", from: () => shown($("#wv-cover")) || plArt(), to: fpArt });
  },
  "cur-page": () => {
    const t = S.current;
    if (!t) return;
    TRACKS.set(t.id, t);
    leaveTo(() => openTrack(t), { to: albumOf(t) ? null : heroArt });
  },
  "track-panel": () => TP.open ? closeTrackPanel() : S.current && openTrackPanel(S.current),
  "fp-close": () => closeFull(),
  osfull: () => api("fullscreen").catch(() => {}),
  "cur-menu": (e) => S.current && trackMenu(e, S.current),
  "cur-artist": () => {
    const a = artistList(S.current)[0];
    if (a && a.name !== NO_ARTIST) leaveTo(() => openArtist(a.id || "", a.name), { to: plArt });
  },
};
// 4.7: a click on an empty spot of the window closes the track panel (not on controls, rows, menus, dialogs)
const TP_KEEP =
  "#tpanel,.menu,.lbox,.dialog,.sndp,.ldock,.fullplayer,.lyrics,button,a,input,select,textarea,label,summary,[contenteditable],[data-l],[data-go],[data-artist],[data-seek],[data-vol],[data-cmd],[data-station],[data-ymplay],[data-wave-mood],[data-zoom],[data-ext],[data-clip],.clipbox,[data-scroll],[data-match],[data-cover-edit],[data-banner-edit],[data-tp],[data-trk],.range,.switch";
function tpOutside(e) {
  if (!TP.open || !e.isTrusted || e.button !== 0) return;
  const tg = e.target;
  if (!(tg instanceof Element) || !tg.isConnected || tg.closest(TP_KEEP)) return;
  // the empty space of the glass mini player toggles the panel itself (see below)
  if (isGlass() && tg.closest("#player")) return;
  if (getSelection?.()?.toString()) return;
  closeTrackPanel();
}
// 4.9.1: like Yandex Music — a track that belongs to an album opens the album page with the track highlighted
// (Yandex tracks: the album id is in the link); a single / a track without an album → the track page
function albumOf(t) {
  const m = /music\.yandex\.[a-z]+\/album\/(\d{1,15})\/track\/(\d{1,15})/.exec(t?.link || "");
  return m ? { album: m[1], track: "ym:" + m[2] } : null;
}
function openTrack(t) {
  if (!t) return;
  TRACKS.set(t.id, t);
  const a = albumOf(t);
  if (!a) return go("track:" + t.id);
  S.hlTrack = { route: "rplaylist:yma:" + a.album, id: a.track, t };
  go("rplaylist:yma:" + a.album);
}
// 4.7: a click on a track title → the track page (4.9.1: or its album)
function trackTitleClick(e) {
  const tt = e.target.closest("[data-trk]");
  if (!tt) return false;
  const t = tt.dataset.trk === "cur" ? S.current : TRACKS.get(tt.dataset.trk);
  if (!t) return false;
  e.stopPropagation();
  TRACKS.set(t.id, t);
  leaveTo(() => openTrack(t), { to: albumOf(t) ? null : heroArt });
  return true;
}
document.addEventListener("click", (e) => {
  tpOutside(e);
  if (e.target.closest?.("[data-trk]") && !e.target.closest("[data-artist]") && trackTitleClick(e)) return;
  const c = e.target.closest("[data-cmd]");
  if (c && !e.target.closest("[data-artist]")) {
    CMD[c.dataset.cmd]?.(e, c);
    return;
  }
  const yp = e.target.closest("[data-ymplay]");
  if (yp) {
    const list = S.lists[yp.dataset.ymplay];
    if (list?.length) playList(list, 0);
    return;
  }
  const wm = e.target.closest("[data-wave-mood]");
  if (wm) {
    startWave(wm.dataset.waveMood ? { mood: wm.dataset.waveMood } : {});
    return;
  }
  const st = e.target.closest("[data-station]");
  if (st) {
    playStation(st.dataset.station);
    return;
  }
  const zm = e.target.closest("[data-zoom]");
  if (zm && !e.target.closest("[data-cover-edit]")) {
    coverLightbox(zm.dataset.zoom, zm.getAttribute("aria-label") || "", S.gallery?.[zm.dataset.gal] || null);
    return;
  }
  const tp = e.target.closest("[data-tp]");
  if (tp) {
    tpAction(tp.dataset.tp, e);
    return;
  }
  const cl = e.target.closest("[data-clip]");
  if (cl) {
    openClip(cl.dataset.clip, { title: cl.dataset.title, by: cl.dataset.by, link: cl.dataset.link });
    return;
  }
  const ext = e.target.closest("[data-ext]");
  if (ext) {
    api("open-external", { url: ext.dataset.ext });
    return;
  }
  const ar = e.target.closest("[data-artist]");
  if (ar) {
    e.stopPropagation();
    leaveTo(() => openArtist(ar.dataset.artist, ar.dataset.name), { to: plArt });
    return;
  }
  // empty space of the mini player → the track panel (like Yandex Music)
  if (
    isGlass() &&
    S.current &&
    e.target.closest("#player") &&
    !e.target.closest("button,a,input,[data-seek],[data-vol],.vol-wrap")
  ) {
    openTrackPanel(S.current);
    return;
  }
  const ce = e.target.closest("[data-cover-edit]");
  if (ce) {
    coverMenu(e, ce.dataset.coverEdit);
    return;
  }
  if (e.target.closest("[data-banner-edit]")) {
    bannerEditor();
    return;
  }
  const mt = e.target.closest("[data-match]");
  if (mt) {
    matchAction(mt.dataset.match);
    return;
  }
  const sc = e.target.closest("[data-scroll]");
  if (sc) {
    const el = document.getElementById(sc.dataset.scroll);
    if (!el) return;
    // a page of whole cards: the step is rounded to the card width so no card stays cut at the edge
    const first = el.firstElementChild,
      gap = parseFloat(getComputedStyle(el).columnGap) || 0,
      cw = first ? first.getBoundingClientRect().width + gap : 0,
      step = cw ? Math.max(cw, Math.floor((el.clientWidth + gap) / cw) * cw) : el.clientWidth * 0.9;
    el.scrollBy({ left: step * +sc.dataset.dir, behavior: "smooth" });
    return;
  }
  const row = e.target.closest("[data-l]");
  if (row) {
    const list = S.lists[row.dataset.l];
    const i = +row.dataset.i;
    if (!list || !list[i]) return;
    const t = list[i];
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "like") return void toggleLike(t);
    if (act === "menu") return void trackMenu(e, t);
    if (act === "info") return void openTrackPanel(t, { list, i, lid: row.dataset.l });
    // In search, the title/cover play; in albums, the whole row plays. Artist links are handled above.
    if (row.classList.contains("tr") && !act && ((row.closest("#sres") && e.target.closest(".tt, .c")) || row.closest("[data-album-tracks]"))) {
      if (S.current?.id === t.id) {
        if (audio.paused || S.pendingResume) togglePlay();
      } else playList(list, i);
      return;
    }
    if (row.classList.contains("tr") && e.detail > 1 && !act) return; // dblclick handler owns the second click
    const al = albumOf(t);
    const here = S.route === "track:" + t.id || (al && S.route === "rplaylist:yma:" + al.album);
    if (row.classList.contains("tr") && e.target.closest(".tt b, .tt .tv") && e.detail < 2 && !act && !here) {
      TRACKS.set(t.id, t);
      return void leaveTo(() => openTrack(t), { to: S.current?.id === t.id && !al ? heroArt : null });
    }
    if (row.classList.contains("tr") && !e.target.closest(".c") && e.detail < 2 && !act) {
      // rows: play on dblclick or cover click; a single click opens the track panel (new interface)
      if (isGlass()) openTrackPanel(t, { list, i, lid: row.dataset.l });
      return;
    }
    if (S.current && S.current.id === t.id) return void togglePlay();
    if (row.dataset.l === "q") return void playAt(i);
    playFromRow(list, i, row.dataset.l);
    return;
  }
  const g = e.target.closest("[data-go]");
  if (g) leaveTo(() => go(g.dataset.go), { to: plArt });
});
document.addEventListener("dblclick", (e) => {
  const row = e.target.closest(".tr[data-l]");
  if (!row || e.target.closest("[data-act], .c")) return;
  const list = S.lists[row.dataset.l];
  const i = +row.dataset.i;
  const track = list?.[i];
  if (!track) return;
  if (S.current?.id === track.id) togglePlay();
  else if (row.dataset.l === "q") playAt(i);
  else playFromRow(list, i, row.dataset.l);
});
document.addEventListener("contextmenu", (e) => {
  const row = e.target.closest("[data-l]");
  if (row) {
    const t = S.lists[row.dataset.l]?.[+row.dataset.i];
    if (t) trackMenu(e, t);
  }
});
$("#side-search").addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    S.lastSearch = e.target.value.trim();
    go("search:" + encodeURIComponent(S.lastSearch));
  }
});
$("#side-search").addEventListener("focus", () => {
  if (!S.route?.startsWith("search")) go("search");
});

/* ---------------- library ---------------- */
function setLikes(l) {
  S.likes = l;
  S.likeSet = new Set(l.map((t) => t.id));
  renderPins();
  refreshLikeButtons();
}
async function reloadLib() {
  PL_CACHE.clear();
  const b = await api("bootstrap");
  S.playlists = b.library.playlists;
  S.history = b.library.history;
  S.artistTime = b.library.artistTime || S.artistTime || [];
  S.likesCover = b.library.likesCover || null;
  setLikes(b.library.likes);
}
async function toggleLike(t) {
  const liked = !S.likeSet.has(t.id);
  const r = await api("like", { track: t, liked });
  setLikes(r.likes);
  likeAnim(t, liked);
  if (liked && S.current?.id === t.id && S.route === "wave") WaveFx.like();
  if (isGlass()) likeToast(t, liked);
  else toast(liked ? "Добавлено в «Мне нравится»" : "Удалено из «Мне нравится»", 1800);
  if (S.route === "likes") reroute();
}
// ♥ pops when liked, gently shakes when removed
function likeAnim(t, liked) {
  if (S.settings?.animation === false) return;
  const svgs = [];
  if (S.current?.id === t.id) $$('[data-cmd="like"] svg').forEach((x) => svgs.push(x));
  $$("[data-l]").forEach((r) => {
    if (S.lists[r.dataset.l]?.[+r.dataset.i]?.id === t.id) r.querySelectorAll(".lk svg").forEach((x) => svgs.push(x));
  });
  $$("#tpanel .tp-like svg").forEach((x) => TP.t?.id === t.id && svgs.push(x));
  const kf = liked
    ? [
        { transform: "scale(1)" },
        { transform: "scale(1.38)", offset: 0.35 },
        { transform: "scale(.92)", offset: 0.7 },
        { transform: "scale(1)" },
      ]
    : [
        { transform: "translateX(0)" },
        { transform: "translateX(-3px) rotate(-8deg)", offset: 0.2 },
        { transform: "translateX(3px) rotate(7deg)", offset: 0.45 },
        { transform: "translateX(-2px) rotate(-4deg)", offset: 0.7 },
        { transform: "translateX(0)" },
      ];
  for (const x of svgs) x.animate(kf, { duration: liked ? 460 : 420, easing: "cubic-bezier(.3,.7,.3,1)" });
}
// «Трек X добавлен в плейлист «Мне нравится»» — slides up from the bottom edge of the content panel
let ltT = 0;
function likeToast(t, liked) {
  let dock = $("#ldock");
  if (!dock) {
    dock = document.createElement("div");
    dock.id = "ldock";
    dock.className = "ldock";
    document.body.appendChild(dock);
  }
  const over = document.body.classList.contains("fp-open") || document.body.classList.contains("ly-open");
  const m = $(".main").getBoundingClientRect();
  const r = over || !m.width ? { left: 0, top: 0, width: innerWidth, height: innerHeight } : m;
  Object.assign(dock.style, {
    left: r.left + "px",
    top: r.top + "px",
    width: r.width + "px",
    height: r.height + "px",
  });
  dock.classList.toggle("over", !!over);
  const [main] = splitTitle(t.title);
  dock.innerHTML = `<div class="ltoast"><span class="lt-c" ${bg(t.cover, "s")}>${t.cover ? "" : icon("note")}</span><span class="lt-t">Трек <b>${esc(main)}</b> ${liked ? "добавлен в плейлист" : "удалён из плейлиста"} «Мне нравится»</span><button class="lt-x" title="Закрыть">${icon("close")}</button></div>`;
  const el = dock.firstElementChild;
  const hide = () => {
    clearTimeout(ltT);
    if (!el.isConnected) return;
    const a = el.animate(
      [
        { transform: "none", opacity: 1 },
        { transform: "translateY(130%)", opacity: 0.4 },
      ],
      {
        duration: 280,
        easing: "cubic-bezier(.4,0,.2,1)",
        fill: "forwards",
      },
    );
    a.finished.then(() => el.remove()).catch(() => {});
  };
  el.querySelector(".lt-x").onclick = hide;
  el.animate(
    [
      { transform: "translateY(130%)", opacity: 0.4 },
      { transform: "none", opacity: 1 },
    ],
    {
      duration: S.settings?.animation === false ? 1 : 420,
      easing: "cubic-bezier(.2,.8,.2,1)",
    },
  );
  clearTimeout(ltT);
  ltT = setTimeout(hide, 3800);
}
async function dislike(t) {
  const r = await api("dislike", { id: t.id, track: t });
  S.dislikes = new Set(r.dislikes);
  setLikes(r.likes);
  toast("Больше не будем рекомендовать", 1800);
  // Remove future occurrences already queued, without disturbing the current index.
  S.queue = S.queue.filter((x, i) => i <= S.index || (x.id !== t.id && songKey(x) !== songKey(t)));
  S.lists.q = S.queue;
  renderQueue();
  if (S.current?.id === t.id) {
    if (S.index < S.queue.length - 1) next();
    else { stopFades(); audio.pause(); if (S.wave) startWave(S.waveOpts || {}); }
  }
}
function refreshLikeButtons() {
  $$(".tr[data-l],.qrow[data-l]").forEach((r) => {
    const t = S.lists[r.dataset.l]?.[+r.dataset.i];
    const b = t && r.querySelector(".lk");
    if (!b) return;
    const on = S.likeSet.has(t.id);
    b.classList.toggle("on", on);
    b.innerHTML = icon(on ? "heart" : "heart-o");
  });
  const on = !!(S.current && S.likeSet.has(S.current.id));
  $$('[data-cmd="like"]').forEach((b) => {
    b.classList.toggle("on", on);
    b.innerHTML = icon(on ? "heart" : "heart-o");
  });
  const td = $("#tpanel .tp-dislike");
  if (td && TP.t) td.classList.toggle("on", S.dislikes.has(TP.t.id));
  const tl = $("#tpanel .tp-like");
  if (tl && TP.t) {
    const v = S.likeSet.has(TP.t.id);
    tl.classList.toggle("on", v);
    tl.innerHTML = icon(v ? "heart" : "heart-o");
  }
}
function renderPins() {
  // 4.9.1: not while a playlist is being dragged (it is redrawn when the drag ends)
  if (S.pinDrag?.on) return void (S.pinDrag.again = true);
  const g = isGlass();
  const lc = S.likesCover;
  $("#side-pins").innerHTML =
    `<button class="pin" data-go="likes"><span class="pc likes" ${lc ? bg(lc, "s") : ""}>${lc ? "" : icon("heart")}</span><span><b>Мне нравится</b><small>${g ? "Плейлист" : plural(S.likes.length, "трек", "трека", "треков")}</small></span></button>` +
    S.playlists
      .map(
        (p) =>
          `<button class="pin" data-go="playlist:${esc(p.id)}"><span class="pc" ${bg(p.cover, "s")}>${p.cover ? "" : icon("note")}</span><span><b>${esc(p.title)}</b><small>${g ? "Плейлист" : plural(p.count, "трек", "трека", "треков")}</small></span></button>`,
      )
      .join("") +
    `<button class="pin" id="pin-new"><span class="pc">${icon("plus")}</span><span><b>Создать плейлист</b></span></button>`;
  $("#pin-new").onclick = () => newPlaylistDialog();
  $$(".pin").forEach((b) => b.classList.toggle("active", b.dataset.go === S.route));
}
/* 4.9.1: playlists in the sidebar are reordered by a long press — hold a playlist for ~1 s (it lifts), then drag it
   up or down; «Мне нравится» always stays first. The new order is saved in the library (and used everywhere). */
const PIN_HOLD = 1000;
(() => {
  const box = $("#side-pins");
  const pins = () => [...box.querySelectorAll('.pin[data-go^="playlist:"]')];
  const ly = (y) => y - box.getBoundingClientRect().top + box.scrollTop - box.clientTop;
  const flip = (els, fn) => {
    const top = new Map(els.map((x) => [x, x.offsetTop]));
    fn();
    for (const x of els) {
      const d = top.get(x) - x.offsetTop;
      if (!d) continue;
      x.style.transition = "none";
      x.style.transform = `translateY(${d}px)`;
      x.offsetWidth;
      x.style.transition = "";
      x.style.transform = "";
    }
  };
  const place = () => {
    const D = S.pinDrag,
      el = D.el;
    const others = pins().filter((x) => x !== el);
    const first = box.querySelector('.pin[data-go="likes"]');
    const last = $("#pin-new");
    const min = first ? first.offsetTop + first.offsetHeight : 0,
      max = (last ? last.offsetTop : box.scrollHeight) - el.offsetHeight;
    let top = Math.max(min, Math.min(max, ly(D.y) - D.grab));
    const mid = top + el.offsetHeight / 2;
    const before = others.find((x) => x.offsetTop + x.offsetHeight / 2 > mid) || last;
    if (before && el.nextElementSibling !== before) flip(others, () => box.insertBefore(el, before));
    el.style.transform = `translateY(${top - el.offsetTop}px) scale(1.03)`;
  };
  const scroll = () => {
    const D = S.pinDrag;
    if (!D?.on) return;
    const r = box.getBoundingClientRect(),
      edge = 36;
    const v = D.y < r.top + edge ? -(r.top + edge - D.y) / 3 : D.y > r.bottom - edge ? (D.y - r.bottom + edge) / 3 : 0;
    if (v) {
      const was = box.scrollTop;
      box.scrollTop += Math.max(-14, Math.min(14, v));
      if (box.scrollTop !== was) place();
    }
    D.raf = requestAnimationFrame(scroll);
  };
  const stop = async (save) => {
    const D = S.pinDrag;
    if (!D) return;
    clearTimeout(D.t);
    cancelAnimationFrame(D.raf);
    S.pinDrag = null;
    D.el.classList.remove("hold", "lifted");
    if (!D.on) return;
    box.classList.remove("dragging");
    try {
      D.el.releasePointerCapture(D.id);
    } catch {}
    // the click that ends the drag must not open the playlist
    S.pinEat = true;
    setTimeout(() => (S.pinEat = false), 350);
    const ids = pins().map((x) => x.dataset.go.slice(9));
    const old = S.playlists.map((p) => p.id);
    if (save && ids.join("\n") !== old.join("\n")) {
      const by = new Map(S.playlists.map((p) => [p.id, p]));
      S.playlists = [...ids.map((id) => by.get(id)).filter(Boolean), ...S.playlists.filter((p) => !ids.includes(p.id))];
      PL_CACHE.clear();
      try {
        await api("playlists-order", { ids: S.playlists.map((p) => p.id) });
      } catch (e) {
        toast("Не удалось сохранить порядок: " + (e.message || e));
      }
      if (S.route === "collection" || S.route === "profile") reroute();
    }
    renderPins();
  };
  box.addEventListener("pointerdown", (e) => {
    if (e.button !== 0 || S.pinDrag) return;
    const el = e.target.closest('.pin[data-go^="playlist:"]');
    if (!el) return;
    const D = (S.pinDrag = { el, id: e.pointerId, x: e.clientX, y: e.clientY, on: false, grab: 0, raf: 0 });
    D.h = setTimeout(() => S.pinDrag === D && el.classList.add("hold"), 180);
    D.t = setTimeout(() => {
      if (S.pinDrag !== D) return;
      clearTimeout(D.h);
      D.on = true;
      D.grab = ly(D.y) - el.offsetTop;
      el.classList.remove("hold");
      el.classList.add("lifted");
      box.classList.add("dragging");
      try {
        el.setPointerCapture(D.id);
      } catch {}
      place();
      D.raf = requestAnimationFrame(scroll);
    }, PIN_HOLD);
  });
  addEventListener(
    "pointermove",
    (e) => {
      const D = S.pinDrag;
      if (!D || e.pointerId !== D.id) return;
      if (!D.on) {
        // moved before the hold time → an ordinary click / scroll, not a drag
        if (Math.hypot(e.clientX - D.x, e.clientY - D.y) > 6) {
          clearTimeout(D.h);
          stop(false);
        }
        return;
      }
      e.preventDefault();
      D.y = e.clientY;
      place();
    },
    { passive: false },
  );
  addEventListener("pointerup", (e) => S.pinDrag && e.pointerId === S.pinDrag.id && stop(true));
  addEventListener("pointercancel", (e) => S.pinDrag && e.pointerId === S.pinDrag.id && stop(true));
  addEventListener("keydown", (e) => e.key === "Escape" && S.pinDrag?.on && stop(false));
  addEventListener("blur", () => S.pinDrag && stop(true));
  box.addEventListener(
    "click",
    (e) => {
      if (!S.pinEat) return;
      S.pinEat = false;
      e.preventDefault();
      e.stopPropagation();
    },
    true,
  );
  box.addEventListener("contextmenu", (e) => S.pinDrag?.on && e.preventDefault());
})();
/* ---------------- 4.10: «Жидкое стекло» — liquid glass like in iOS 26 ----------------
   Every glass control gets its own SVG filter: a displacement map drawn on a canvas for its size and corner
   radius (a rounded-rect distance field → a lens-shaped bezel that bends the background at the edges, sampling
   inwards), applied through backdrop-filter: blur() url(#…) saturate(). A thin specular rim and a soft glare
   (it follows the pointer when «Блик за курсором» is on) are drawn by ::after (see v410.css). Sizes are watched
   by a ResizeObserver; filters are shared between elements of the same size. */
const LiquidGlass = (() => {
  const GROUPS = {
    player: "#player",
    buttons: ".gbtn, .wbtn, .wpill, .fpa-c, .fpa-s:not(.fpa-m), .wv-src-pill, .wv-src-x",
    menus: ".menu, .dialog, .sndp, .vol-pop",
  };
  const NS = "http://www.w3.org/2000/svg";
  let o = null,
    sel = "",
    raf = 0,
    seq = 0,
    hot = null;
  const cache = new Map(); // "w×h×r" → { id, bz, node }
  const els = new Set();
  let defs = null;
  const ensureDefs = () => {
    if (defs?.isConnected) return defs;
    const svg = document.createElementNS(NS, "svg");
    svg.id = "lg-defs";
    svg.setAttribute("aria-hidden", "true");
    svg.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none";
    defs = document.createElementNS(NS, "defs");
    svg.appendChild(defs);
    document.body.appendChild(svg);
    return defs;
  };
  // the displacement map: R/G = 128 ± the inward normal × lens profile in the bezel, neutral grey inside
  function makeMap(w, h, r, bz) {
    const k = w * h > 90000 ? 0.5 : 1;
    const cw = Math.max(2, Math.round(w * k)),
      ch = Math.max(2, Math.round(h * k));
    const c = document.createElement("canvas");
    c.width = cw;
    c.height = ch;
    const g = c.getContext("2d");
    const im = g.createImageData(cw, ch);
    const d = im.data;
    const hw = w / 2,
      hh = h / 2;
    for (let y = 0; y < ch; y++)
      for (let x = 0; x < cw; x++) {
        const px = (x + 0.5) / k - hw,
          py = (y + 0.5) / k - hh;
        const qx = Math.abs(px) - (hw - r),
          qy = Math.abs(py) - (hh - r);
        let dist, nx, ny;
        if (qx > 0 && qy > 0) {
          const l = Math.hypot(qx, qy) || 1;
          dist = l - r;
          nx = qx / l;
          ny = qy / l;
        } else if (qx > qy) {
          dist = qx - r;
          nx = 1;
          ny = 0;
        } else {
          dist = qy - r;
          nx = 0;
          ny = 1;
        }
        if (px < 0) nx = -nx;
        if (py < 0) ny = -ny;
        const depth = -dist;
        const t = Math.min(1, Math.max(0, depth) / bz);
        const m = depth >= bz ? 0 : (1 - t) * (1 - t);
        const i = (y * cw + x) * 4;
        d[i] = 128 - nx * m * 127;
        d[i + 1] = 128 - ny * m * 127;
        d[i + 2] = 128;
        d[i + 3] = 255;
      }
    g.putImageData(im, 0, 0);
    return c.toDataURL("image/png");
  }
  const scaleOf = (bz) => (((o?.refract ?? 60) / 100) * bz * 1.5).toFixed(1);
  function filterFor(w, h, r) {
    const key = `${w}x${h}x${r}`;
    let f = cache.get(key);
    if (f) return f;
    if (cache.size > 160) reset();
    const bz = Math.max(6, Math.min(Math.min(w, h) / 2, Math.min(30, Math.min(w, h) * 0.34)));
    const id = "lgf" + ++seq;
    const node = document.createElementNS(NS, "filter");
    node.id = id;
    for (const [a, v] of [
      ["x", 0],
      ["y", 0],
      ["width", w],
      ["height", h],
      ["filterUnits", "userSpaceOnUse"],
      ["primitiveUnits", "userSpaceOnUse"],
      ["color-interpolation-filters", "sRGB"],
    ])
      node.setAttribute(a, v);
    const img = document.createElementNS(NS, "feImage");
    for (const [a, v] of [
      ["x", 0],
      ["y", 0],
      ["width", w],
      ["height", h],
      ["preserveAspectRatio", "none"],
      ["result", "m"],
    ])
      img.setAttribute(a, v);
    img.setAttribute("href", makeMap(w, h, r, bz));
    const dm = document.createElementNS(NS, "feDisplacementMap");
    for (const [a, v] of [
      ["in", "SourceGraphic"],
      ["in2", "m"],
      ["scale", scaleOf(bz)],
      ["xChannelSelector", "R"],
      ["yChannelSelector", "G"],
    ])
      dm.setAttribute(a, v);
    node.append(img, dm);
    ensureDefs().appendChild(node);
    f = { id, bz, node, dm };
    cache.set(key, f);
    return f;
  }
  const radiusOf = (el, w, h) => {
    const v = getComputedStyle(el).borderTopLeftRadius || "0";
    const n = parseFloat(v) || 0;
    const r = v.includes("%") ? (n / 100) * Math.min(w, h) : n;
    return Math.round(Math.max(0, Math.min(r, Math.min(w, h) / 2)));
  };
  function assign(el, box) {
    if (!o?.on || !el.isConnected) return;
    const w = Math.round(box ? box.inlineSize : el.offsetWidth),
      h = Math.round(box ? box.blockSize : el.offsetHeight);
    if (w < 8 || h < 8 || w > 2400 || h > 1600) return void el.style.removeProperty("--lg-f");
    const f = filterFor(w, h, radiusOf(el, w, h));
    el.style.setProperty("--lg-f", `url(#${f.id})`);
  }
  const ro = new ResizeObserver((entries) => {
    for (const en of entries) assign(en.target, en.borderBoxSize?.[0]);
  });
  function scan() {
    raf = 0;
    for (const el of els)
      if (!el.isConnected || !sel || !el.matches(sel)) {
        ro.unobserve(el);
        el.style.removeProperty("--lg-f");
        els.delete(el);
      }
    if (!sel) return;
    for (const el of document.querySelectorAll(sel))
      if (!els.has(el)) {
        els.add(el);
        ro.observe(el);
      }
  }
  const later = () => raf || (raf = requestAnimationFrame(scan));
  new MutationObserver((muts) => {
    if (!sel || muts.every((m) => m.target.closest?.(".vlist, #lg-defs"))) return;
    later();
  }).observe(document.body, { childList: true, subtree: true });
  function reset() {
    for (const f of cache.values()) f.node.remove();
    cache.clear();
    for (const el of els) {
      ro.unobserve(el);
      el.style.removeProperty("--lg-f");
    }
    els.clear();
    later();
  }
  // the glare follows the pointer over the hovered glass element
  const unhot = () => {
    if (hot) {
      hot.style.removeProperty("--lg-mx");
      hot.style.removeProperty("--lg-my");
    }
    hot = null;
  };
  let pm = null,
    pmRaf = 0;
  document.addEventListener(
    "pointermove",
    (e) => {
      if (!o?.on || !o.follow || !sel) return;
      pm = e;
      if (pmRaf) return;
      pmRaf = requestAnimationFrame(() => {
        pmRaf = 0;
        const t = pm.target instanceof Element ? pm.target.closest(sel) : null;
        if (t !== hot) unhot();
        if (!t) return;
        hot = t;
        const r = t.getBoundingClientRect();
        if (!r.width || !r.height) return;
        t.style.setProperty("--lg-mx", (((pm.clientX - r.left) / r.width) * 100).toFixed(1) + "%");
        t.style.setProperty("--lg-my", (((pm.clientY - r.top) / r.height) * 100).toFixed(1) + "%");
      });
    },
    { passive: true },
  );
  document.addEventListener("pointerleave", unhot);
  function apply(opts, enabled) {
    const prev = o;
    o = { ...opts, on: !!(opts?.on && enabled) };
    root.dataset.lg = o.on ? "on" : "off";
    for (const k of ["player", "buttons", "menus"]) root.toggleAttribute("data-lg-" + k, o.on && o[k] !== false);
    root.toggleAttribute("data-lg-follow", o.on && o.follow !== false);
    const st = root.style;
    st.setProperty("--lg-bp", ((o.blur ?? 30) * 0.4).toFixed(1) + "px");
    st.setProperty("--lg-bb", ((o.blur ?? 30) * 0.18).toFixed(1) + "px");
    st.setProperty("--lg-mbp", ((o.blur ?? 30) * 0.12).toFixed(1) + "px");
    st.setProperty("--lg-mbb", ((o.blur ?? 30) * 0.08).toFixed(1) + "px");
    st.setProperty("--lg-shine", ((o.shine ?? 60) / 100).toFixed(2));
    st.setProperty("--lg-op", Math.round(100 - (o.clear ?? 35) * 0.85) + "%");
    sel = o.on
      ? ["player", "buttons", "menus"]
          .filter((k) => o[k] !== false)
          .map((k) => GROUPS[k])
          .join(", ")
      : "";
    if (!o.follow) unhot();
    if (prev && prev.refract !== o.refract) for (const f of cache.values()) f.dm.setAttribute("scale", scaleOf(f.bz));
    later();
  }
  return { apply, stats: () => ({ filters: cache.size, els: els.size, sel }) };
})();
const LIQUID_DEF = {
  on: true,
  refract: 60,
  blur: 30,
  shine: 60,
  clear: 35,
  follow: true,
  player: true,
  buttons: true,
  menus: true,
};
const liquidOpts = () => ({ ...LIQUID_DEF, ...(S.settings?.liquid || {}) });
// 4.13: the flat Yandex skin goes without the liquid glass
const applyLiquid = (opts = liquidOpts()) =>
  LiquidGlass.apply(
    opts,
    isGlass() && (S.settings?.glassFx || "full") !== "off" && (root.hasAttribute("data-mobile") || !["yandex", "spotify"].includes(S.settings?.skin)),
  );
function applySettings() {
  const s = S.settings;
  const prevUi = root.dataset.ui;
  root.dataset.theme = s.theme || "dark";
  root.dataset.ui = s.ui === "classic" ? "classic" : "glass";
  const prevAcc = root.dataset.accent;
  // 4.13: the Yandex skin has its own yellow — the chosen accent comes back when the skin is off
  const ymSkin = false; // 4.21.3: always the "wave" skin — circles on the Wave screen
  // 4.15: the Spotify skin — its own green
  const spSkin = false;
  root.dataset.accent = ymSkin
    ? "yellow"
    : spSkin
      ? "spotify"
      : ["violet", "yellow", "cover", "arcane", "emerald", "sakura"].includes(s.accent)
        ? s.accent
        : "violet";
  root.dataset.fx = ["full", "lite", "off"].includes(s.glassFx) ? s.glassFx : "full";
  applyLiquid();
  // 4.10: «Аркейн» has its own colours of the «Моя волна» glow
  if (prevAcc && prevAcc !== root.dataset.accent) waveRamp(true);
  root.dataset.font = s.font === "onest" ? "onest" : "ys";
  // 4.13: the experimental look of Yandex Music (only the new interface)
  const prevSkin = root.dataset.skin;
  root.dataset.skin = ymSkin ? "yandex" : spSkin ? "spotify" : "wave";
  if (prevSkin && prevSkin !== root.dataset.skin) waveRamp(true);
  WaveFx.setOpts(s.waveFx);
  WaveFx.setStyle(s.waveStyle);
  applyWaveGlow();
  $("#fullplayer").dataset.variant = ["cover", "nowplaying", "classic"].includes(s.player) ? s.player : "cover";
  document.body.classList.toggle("no-anim", s.animation === false);
  try {
    localStorage.setItem("wave.anim", s.animation === false ? "0" : "1"); // the splash of the next start
  } catch {}
  $("#theme-toggle").innerHTML = icon(s.theme === "light" ? "sun" : "moon");
  $("#side-avatar").outerHTML = avatarHtml("sm", "side-avatar");
  $("#g-avatar").outerHTML = avatarHtml("", "g-avatar");
  $("#side-nick").textContent = $("#g-nick").textContent = s.profile?.nick || "Слушатель";
  $("#tb-ver").textContent = "Wave " + (S.version || "");
  setSidebar(s.sidebarWidth || 250);
  const gif = $("#pl-gif");
  if (s.progressGif) {
    if (gif.getAttribute("src") !== s.progressGif) gif.src = s.progressGif;
    gif.hidden = false;
  } else {
    gif.hidden = true;
    gif.removeAttribute("src");
  }
  root.style.setProperty("--gif", (s.progressGifSize || 44) + "px");
  document.body.classList.toggle("has-gif", !!s.progressGif);
  tintLogo();
  splashSave();
  // window buttons: in the title bar (new) or in the top bar of the content (classic)
  const wc = $(".winctl"),
    host = isGlass() ? $(".titlebar") : $(".topbar");
  if (wc.parentElement !== host) host.appendChild(wc);
  // new interface: vertical volume capsule with % on top (the % can be hidden in the settings)
  const vp = $("#pl-volpop");
  vp.classList.toggle("vert", isGlass());
  vp.querySelector(".bar").toggleAttribute("data-vert", isGlass());
  document.body.classList.toggle("no-volpct", s.volPct === false);
  syncVolUi();
  loadSnd(s);
  if (prevUi !== root.dataset.ui) onUiSwitch();
}
function onUiSwitch() {
  renderPins();
  if (S.current) updateNow(S.current, S.stream);
  if (S.route) {
    if (S.route === "wave" && !isGlass()) go("home", { push: false });
    else reroute();
  }
  renderQueue();
}
$("#theme-toggle").onclick = async () => {
  S.settings = await api("settings", { theme: S.settings.theme === "dark" ? "light" : "dark" });
  applySettings();
  if (S.route === "settings") settingsView();
};

/* ---------- sidebar width (setting + drag handle) ---------- */
function setSidebar(w) {
  w = Math.max(200, Math.min(380, Math.round(+w || 250)));
  root.style.setProperty("--sb", w + "px");
  document.body.classList.toggle("sb-narrow", w < 232);
}
(() => {
  const h = $("#sb-resize");
  h.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    h.setPointerCapture(e.pointerId);
    document.body.classList.add("sb-drag");
    const x0 = e.clientX,
      w0 = $(".sidebar").getBoundingClientRect().width;
    let w = w0;
    const move = (ev) => {
      w = Math.max(200, Math.min(380, w0 + ev.clientX - x0));
      setSidebar(w);
    };
    const up = () => {
      h.removeEventListener("pointermove", move);
      h.removeEventListener("pointerup", up);
      h.removeEventListener("pointercancel", up);
      document.body.classList.remove("sb-drag");
      if (Math.round(w) !== Math.round(w0))
        api("settings", { sidebarWidth: Math.round(w) })
          .then((st) => {
            S.settings = st;
            const r = $("#sbw");
            if (r) {
              r.value = st.sidebarWidth;
              $("#sbw-v").textContent = st.sidebarWidth + " px";
            }
          })
          .catch(() => {});
    };
    h.addEventListener("pointermove", move);
    h.addEventListener("pointerup", up);
    h.addEventListener("pointercancel", up);
  });
  h.addEventListener("dblclick", () => {
    setSidebar(250);
    api("settings", { sidebarWidth: 250 })
      .then((st) => (S.settings = st))
      .catch(() => {});
  });
})();

/* ---------- logo follows the accent colour (hue shift of the yellow original) ---------- */
const LOGO = { img: null, hue: null, url: "assets/logo.png", busy: false };
function accentHex() {
  const v = getComputedStyle(root)
    .getPropertyValue(isGlass() ? "--g-acc" : "--acc")
    .trim();
  if (/^#[0-9a-f]{6}$/i.test(v)) return v;
  if (/^#[0-9a-f]{3}$/i.test(v)) return "#" + [...v.slice(1)].map((c) => c + c).join("");
  const m = v.match(/rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/);
  return m ? rgbHex(+m[1], +m[2], +m[3]) : null;
}
function tintLogo() {
  const hex = accentHex();
  if (!hex) return;
  const [h, sat] = toHsl(hx(hex));
  // the original logo is yellow (~48°): keep it for the yellow accent and for greys
  const target = Math.abs(((h - 48 + 540) % 360) - 180) < 14 || sat < 0.12 ? null : Math.round(h);
  if (target === LOGO.hue && (target === null || LOGO.url !== "assets/logo.png")) return;
  LOGO.hue = target;
  const apply = (url) => {
    LOGO.url = url;
    $$("img[data-logo]").forEach((i) => i.getAttribute("src") !== url && (i.src = url));
    splashSave();
  };
  if (target === null) return apply("assets/logo.png");
  const run = () => {
    const im = LOGO.img,
      c = document.createElement("canvas");
    c.width = im.naturalWidth;
    c.height = im.naturalHeight;
    const g = c.getContext("2d", { willReadFrequently: true });
    g.drawImage(im, 0, 0);
    let d;
    try {
      d = g.getImageData(0, 0, c.width, c.height);
    } catch {
      // file:// canvas is tainted in some Electron builds — let the main process tint it
      return api("logo", { hue: target })
        .then((url) => LOGO.hue === target && apply(url || "assets/logo.png"))
        .catch(() => apply("assets/logo.png"));
    }
    const px = d.data,
      shift = (target - 48) / 360;
    const ch = (p, q, t) => {
      t = t < 0 ? t + 1 : t > 1 ? t - 1 : t;
      return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p;
    };
    for (let i = 0; i < px.length; i += 4) {
      if (!px[i + 3]) continue;
      const r = px[i] / 255,
        gg = px[i + 1] / 255,
        b = px[i + 2] / 255;
      const mx = Math.max(r, gg, b),
        mn = Math.min(r, gg, b),
        l = (mx + mn) / 2;
      if (mx === mn) continue;
      const dd = mx - mn,
        sa = l > 0.5 ? dd / (2 - mx - mn) : dd / (mx + mn);
      let h = mx === r ? (gg - b) / dd + (gg < b ? 6 : 0) : mx === gg ? (b - r) / dd + 2 : (r - gg) / dd + 4;
      h = (h / 6 + shift + 1) % 1;
      const q = l < 0.5 ? l * (1 + sa) : l + sa - l * sa,
        pp = 2 * l - q;
      px[i] = ch(pp, q, h + 1 / 3) * 255;
      px[i + 1] = ch(pp, q, h) * 255;
      px[i + 2] = ch(pp, q, h - 1 / 3) * 255;
    }
    g.putImageData(d, 0, 0);
    if (LOGO.hue === target) apply(c.toDataURL("image/png"));
  };
  if (LOGO.img?.complete && LOGO.img.naturalWidth) return run();
  LOGO.img = new Image();
  LOGO.img.onload = run;
  LOGO.img.onerror = () => apply("assets/logo.png");
  LOGO.img.src = "assets/logo.png";
}

/* ---------- 4.6: shelf arrows are disabled at the ends (and hidden when everything fits) ---------- */
function shelfArrows(el) {
  if (!el?.id) return;
  const btns = document.querySelectorAll(`[data-scroll="${el.id}"]`);
  if (!btns.length) return;
  const max = el.scrollWidth - el.clientWidth;
  for (const b of btns) {
    b.disabled = +b.dataset.dir < 0 ? el.scrollLeft <= 2 : el.scrollLeft >= max - 2;
    b.parentElement?.classList.toggle("fits", max <= 2);
  }
}
let arrowsRaf = 0;
const allArrows = () => {
  if (arrowsRaf) return;
  arrowsRaf = requestAnimationFrame(() => {
    arrowsRaf = 0;
    document.querySelectorAll("#content .shelf[id]").forEach(shelfArrows);
  });
};
document.addEventListener("scroll", (e) => e.target.classList?.contains("shelf") && shelfArrows(e.target), {
  capture: true,
  passive: true,
});
addEventListener("resize", allArrows);
new MutationObserver(allArrows).observe($("#content"), { childList: true, subtree: true });

/* ---------- click ripple (not on covers, lyrics/text buttons and the «Моя волна» wheel) ---------- */
const RIPPLE_ON = "button, .pin, .gchip, .chip, .tr, .tk, .ytile, .seg button";
const RIPPLE_OFF =
  ".c, .cv, .card, .pl-cover, .wv-cover, .fp-art, .gh-cover, .ly-cover, .ylk-cover, .yc-av, .wv-arc, .wv-item, [data-cmd='lyrics']:not(.player *), .ly-l, .bar, [data-seek], [data-vol], .winctl, .sb-resize, .switch, input, .tk-img, .tp-cover, [data-drag]";
document.addEventListener(
  "pointerdown",
  (e) => {
    if (e.button !== 0 || S.settings?.animation === false || document.body.classList.contains("no-anim")) return;
    if (e.target.closest(RIPPLE_OFF)) return;
    let el = e.target.closest(RIPPLE_ON);
    // 4.7: the empty space of the glass mini player (it opens the track panel) ripples too — white, like Yandex
    if (!el && isGlass() && !e.target.closest("a,input,.vol-wrap,.vol-pop")) el = e.target.closest("#player");
    if (!el || el.disabled) return;
    const r = el.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return;
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    const box = document.createElement("wave-ripple");
    // 4.10: elements without own rounding (the logo button in the sidebar…) get a rounded ripple, not a square
    if (!parseFloat(getComputedStyle(el).borderTopLeftRadius)) box.style.borderRadius = "12px";
    const x = e.clientX - r.left,
      y = e.clientY - r.top,
      d = Math.hypot(Math.max(x, r.width - x), Math.max(y, r.height - y)) * 2;
    const dot = document.createElement("i");
    dot.style.cssText = `width:${d}px;height:${d}px;left:${x - d / 2}px;top:${y - d / 2}px`;
    box.appendChild(dot);
    el.appendChild(box);
    setTimeout(() => box.remove(), 700);
  },
  true,
);

/* ---------------- volume (0–200 %) ----------------
   Slider position p: 0…1 → gain p² (perceptual: quiet levels are finely adjustable),
   1…2 → +0…12 dB boost through Web Audio with a limiter so loud tracks do not clip. */
/* ---------------- audio engine (4.5): one AudioContext, two «decks» for the crossfade ----------------
   deck: <audio> → MediaElementSource → fade gain ─┬→ fx analyser (Моя волна glow, before the volume)
                                                    └→ bus → preamp → 10-band EQ → volume → [limiter] → analyser → out
   Hosts without CORS headers cannot enter Web Audio (the element would play silence): such elements play
   directly — volume and crossfade go through element.volume, the equalizer and boost do not apply to them. */
const AX = {
  ctx: null,
  bus: null,
  pre: null,
  eq: [],
  gain: null,
  comp: null,
  an: null,
  fx: null,
  ok: false, // the active element goes through the graph
  failed: false,
  lim: null,
  decks: new Map(),
};
const VOL_MAX = 2,
  BOOST_DB = 12;
let vol = 0.84,
  muted = false,
  volSave;
const gainOf = (p) => (p <= 1 ? p * p : Math.pow(10, ((p - 1) * BOOST_DB) / 20));
// 4.14: until the level of Wave in the Windows volume mixer is set to 50 % (the first sound of a new Wave.exe, see
// «mixer-init» in main.cjs) everything plays at half the level (−6 dB, the same as the mixer at 50 %) — the first
// seconds do not deafen either. Windows did not let it → the volume of Wave itself goes down by the same −6 dB once
const MIXG = { on: false, asked: false };
const volMul = () => (MIXG.on ? 0.5 : 1);
const volNow = () => (muted ? 0 : gainOf(vol) * volMul());
function mixerInit() {
  if (!MIXG.on || MIXG.asked) return;
  MIXG.asked = true;
  api("mixer-init")
    .then((r) => {
      if (r && !r.ok && !r.skipped) setVol(vol * Math.SQRT1_2, true);
    })
    .catch(() => {})
    .finally(() => {
      MIXG.on = false;
      applyGain();
    });
}
const noCorsHosts = new Set();
const hostOf = (u) => {
  try {
    return new URL(u).host;
  } catch {
    return "";
  }
};
// sound settings (speed, pitch, crossfade, equalizer) — mirrored from S.settings
const EQ_F = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000];
const EQ_LBL = ["60", "170", "310", "600", "1k", "3k", "6k", "12k", "14k", "16k"];
const EQ_PRESETS = [
  ["flat", "По умолчанию", [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
  ["bass", "Больше баса", [6, 5, 3, 1, 0, 0, 0, 0, 0, 0]],
  ["bassmax", "Мощный бас", [9, 7.5, 4, 1, -1, -1, 0, 0, 0, 0]],
  ["treble", "Больше высоких", [0, 0, 0, 0, 0, 1, 3, 5, 6, 6]],
  ["bt", "Бас и высокие", [6, 4, 0, -3, -2, 0, 3, 5, 6, 6]],
  ["vocal", "Вокал", [-3, -2, 0, 2, 4, 4, 3, 1, 0, -1]],
  ["pop", "Поп", [-1, 2, 4, 4, 2, 0, -1, -1, -1, -1]],
  ["rock", "Рок", [5, 3, -2, -3, -1, 2, 4, 5, 5, 5]],
  ["hiphop", "Хип-хоп", [6, 5, 1, -1, -1, 1, 0, 1, 2, 2]],
  ["electro", "Электроника", [5, 4, 1, 0, -2, 1, 1, 3, 4, 5]],
  ["dance", "Танцевальная", [6, 5, 2, 0, 0, -2, -3, -3, 0, 0]],
  ["acoustic", "Акустика", [4, 3, 1, 1, 2, 2, 3, 3, 2, 1]],
  ["jazz", "Джаз", [3, 2, 1, 2, -1, -1, 0, 1, 2, 3]],
  ["classic", "Классика", [4, 3, 2, 1, -1, -1, 0, 2, 3, 4]],
  ["loud", "Тихое прослушивание", [5, 3, 1, 0, 0, 0, 0, 2, 3, 3]],
  ["phones", "Наушники", [2, 4, 2, -1, -1, 1, 2, 4, 5, 5]],
  ["laptop", "Динамики ноутбука", [-2, 2, 4, 2, 0, 1, 2, 3, 3, 2]],
];
const SND = {
  speed: 1,
  pitch: true,
  xf: 5,
  eq: { on: false, preset: "flat", pre: 0, bands: Array(10).fill(0), custom: null },
};
const dbGain = (db) => Math.pow(10, db / 20);
const eqHot = () => SND.eq.on && (SND.eq.pre > 0 || SND.eq.bands.some((b) => b > 0));
function ensureCtx() {
  if (AX.ctx || AX.failed) return !!AX.ctx;
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    const ctx = new C({ latencyHint: "playback" });
    const bus = ctx.createGain(),
      pre = ctx.createGain(),
      gain = ctx.createGain(),
      comp = ctx.createDynamicsCompressor(),
      an = ctx.createAnalyser(),
      fx = ctx.createAnalyser();
    comp.threshold.value = -2;
    comp.knee.value = 4;
    comp.ratio.value = 20;
    comp.attack.value = 0.002;
    comp.release.value = 0.2;
    an.fftSize = 256;
    an.smoothingTimeConstant = 0.75;
    // the «Моя волна» glow listens before the volume: same reaction at any loudness
    fx.fftSize = 1024;
    fx.smoothingTimeConstant = 0.32;
    // −85…−15 dB: loud modern masters do not pin the bass at the top, kicks stand out (tuned on real tracks)
    fx.minDecibels = -85;
    fx.maxDecibels = -15;
    const eq = EQ_F.map((f, i) => {
      const b = ctx.createBiquadFilter();
      b.type = i === 0 ? "lowshelf" : i === EQ_F.length - 1 ? "highshelf" : "peaking";
      b.frequency.value = f;
      b.Q.value = 1.1;
      b.gain.value = 0;
      return b;
    });
    bus.connect(fx);
    bus.connect(pre);
    let n = pre;
    for (const b of eq) {
      n.connect(b);
      n = b;
    }
    n.connect(gain);
    an.connect(ctx.destination);
    Object.assign(AX, { ctx, bus, pre, eq, gain, comp, an, fx, lim: null });
    routeGraph(false);
    applyEq(true);
  } catch (e) {
    AX.failed = true;
  }
  return !!AX.ctx;
}
function attachDeck(el) {
  if (!el.hasAttribute("crossorigin") || !ensureCtx()) return null;
  let d = AX.decks.get(el);
  if (d) return d;
  try {
    const src = AX.ctx.createMediaElementSource(el);
    const g = AX.ctx.createGain();
    g.gain.value = el._lvl ?? 1;
    // 4.14: the filters of «Микс» transitions — transparent outside of a transition (high-pass at 0 Hz, low-pass at
    // the Nyquist frequency, a 0 dB low shelf pass the signal unchanged)
    const hp = AX.ctx.createBiquadFilter(),
      lp = AX.ctx.createBiquadFilter(),
      lo = AX.ctx.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 0;
    lp.type = "lowpass";
    lp.frequency.value = AX.ctx.sampleRate / 2;
    lo.type = "lowshelf";
    lo.frequency.value = 220;
    lo.gain.value = 0;
    src.connect(g);
    g.connect(hp);
    hp.connect(lp);
    lp.connect(lo);
    lo.connect(AX.bus);
    d = { src, g, hp, lp, lo };
    AX.decks.set(el, d);
    el.volume = 1;
  } catch {
    d = null;
  }
  return d;
}
function detachDeck(el) {
  const d = AX.decks.get(el);
  if (!d) return;
  AX.decks.delete(el);
  try {
    d.src.disconnect();
    d.g.disconnect();
    d.hp?.disconnect();
    d.lp?.disconnect();
    d.lo?.disconnect();
  } catch {}
}
// 4.14: the «Микс» filters of a deck back to transparent (a transition cut short)
function deckNeutral(d) {
  if (!d?.hp || !AX.ctx) return;
  const now = AX.ctx.currentTime;
  for (const [prm, v] of [
    [d.hp.frequency, 0],
    [d.lp.frequency, AX.ctx.sampleRate / 2],
    [d.lo.gain, 0],
  ])
    try {
      prm.cancelScheduledValues(now);
      prm.setValueAtTime(v, now);
    } catch {}
}
// kept for older call sites: makes sure the active element goes through the graph
function audioGraph() {
  AX.ok = !!attachDeck(audio);
  sndNote();
  return AX.ok;
}
function setActive(el) {
  if (audio && audio !== el) audio.removeAttribute("id");
  el.id = "audio";
  audio = el;
  AX.ok = AX.decks.has(el);
  sndNote();
}
function applyRate(el = audio) {
  if (window.WaveSocial?.follower()) { el.defaultPlaybackRate = window.WaveSocial.roomRate(); el.playbackRate = window.WaveSocial.roomRate(); el.preservesPitch = window.WaveSocial.roomPitch(); return; }
  try {
    el.preservesPitch = SND.pitch;
  } catch {}
  el.defaultPlaybackRate = SND.speed;
  el.playbackRate = SND.speed;
}
function newAudio(cors) {
  const el = document.createElement("audio");
  el.preload = "auto";
  if (cors) el.setAttribute("crossorigin", "anonymous");
  el.hidden = true;
  document.body.appendChild(el);
  applyRate(el);
  bindAudio(el);
  return el;
}
function stopEl(el, h) {
  if (!el) return;
  clearInterval(el._fadeIv);
  try {
    el.pause();
  } catch {}
  if (h)
    try {
      h.destroy();
    } catch {}
  el.removeAttribute("src");
  try {
    el.load();
  } catch {}
  detachDeck(el);
  if (el !== audio) el.remove();
}
// CORS mode of the active element changes: replace it (a MediaElementSource cannot be detached from an element)
function swapAudio(cors) {
  if (audio.hasAttribute("crossorigin") === cors) {
    if (cors && !AX.ok) audioGraph();
    return;
  }
  const old = audio;
  const el = newAudio(cors);
  setActive(el);
  stopEl(old);
  old.remove();
  if (cors) audioGraph();
  applyGain();
}
function routeGraph(lim) {
  if (!AX.ctx || AX.lim === lim) return;
  AX.lim = lim;
  try {
    AX.gain.disconnect();
    AX.comp.disconnect();
  } catch {}
  if (lim) {
    AX.gain.connect(AX.comp);
    AX.comp.connect(AX.an);
  } else AX.gain.connect(AX.an);
}
// all elements that sound right now: the active one + a fading or starting deck
const liveEls = () => [audio, XF.old?.el, XF.nx?.el, VERSION.job?.el].filter(Boolean);
function applyGain() {
  const g = volNow();
  if (AX.ctx) {
    const now = AX.ctx.currentTime;
    AX.gain.gain.cancelScheduledValues(now);
    AX.gain.gain.setTargetAtTime(g, now, 0.015);
    // the limiter is on above 100 % and while the equalizer boosts something (no clipping)
    routeGraph(g > 1.001 || eqHot());
  }
  for (const el of liveEls()) el.volume = AX.decks.has(el) ? 1 : Math.min(1, g) * (el._lvl ?? 1);
}
function applyEq(instant) {
  if (!AX.ctx) return;
  const on = SND.eq.on;
  const now = AX.ctx.currentTime,
    tc = instant ? 0.001 : 0.03;
  const set = (p, v) => {
    p.cancelScheduledValues(now);
    p.setTargetAtTime(v, now, tc);
  };
  set(AX.pre.gain, on ? dbGain(SND.eq.pre) : 1);
  AX.eq.forEach((b, i) => set(b.gain, on ? SND.eq.bands[i] || 0 : 0));
  applyGain();
}
/* ---- crossfade ----
   ~25 s before the end the next track's stream is resolved ahead; when «crossfade» seconds are left the next track
   starts on a second element at zero level and both levels move along equal-power curves. A manual switch,
   pause or error cancels the fade. */
const XF = { pre: null, nx: null, old: null };
// At most the adjacent two tracks; URLs and elements are discarded after a short time.
const WARM = new Map();
const WARM_TTL = 3 * 60e3;
function warmDrop(w) {
  if (!w) return;
  if (WARM.get(w.id) === w) WARM.delete(w.id);
  clearTimeout(w.timer);
  if (w.fail) w.el.removeEventListener("error", w.fail);
  if (w.el !== audio) stopEl(w.el, w.hls);
}
function warmNeighbors() {
  const ids = new Set();
  if (S.index > 0) ids.add(S.queue[S.index - 1]?.id);
  const i = nextIndex();
  if (i >= 0) ids.add(S.queue[i]?.id);
  ids.delete(S.current?.id);
  return ids;
}
function pruneWarm() {
  const ids = warmNeighbors();
  for (const w of WARM.values())
    if (w.queue !== S.queue || !ids.has(w.id) || Date.now() - w.at > WARM_TTL) warmDrop(w);
}
function putWarm(w) {
  if (!w?.id || !w.el || !w.s || w.el === audio || !warmNeighbors().has(w.id)) {
    if (w?.el && w.el !== audio) stopEl(w.el, w.hls);
    return;
  }
  const old = WARM.get(w.id);
  if (old && old !== w) warmDrop(old);
  w.queue = S.queue;
  w.at = Date.now();
  WARM.set(w.id, w);
  w.timer = setTimeout(() => warmDrop(w), WARM_TTL);
  pruneWarm();
}
function keepOldDeck(el, h, t, s) {
  if (document.documentElement.hasAttribute("data-mobile")) return void stopEl(el, h);
  if (!el || el === audio || !t || !s || !warmNeighbors().has(t.id)) return void stopEl(el, h);
  try { el.pause(); } catch {}
  setLevel(el, 0);
  if (h) try { h.stopLoad(); } catch {}
  try { el.currentTime = 0; } catch {}
  putWarm({ id: t.id, el, hls: h, s, stopped: !!h });
}
function takeWarm(t) {
  const w = WARM.get(t?.id);
  if (!w) return null;
  if (w.queue !== S.queue || Date.now() - w.at > WARM_TTL || w.el.error || w.el.readyState < 2) {
    // A still-loading deck is left alone unless it is stale or broken.
    if (w.queue !== S.queue || Date.now() - w.at > WARM_TTL || w.el.error) warmDrop(w);
    return null;
  }
  WARM.delete(w.id);
  clearTimeout(w.timer);
  if (w.fail) w.el.removeEventListener("error", w.fail);
  if (w.stopped && w.hls) try { w.hls.startLoad(0); } catch {}
  return w;
}
function prepareWarm(p, t) {
  if (document.documentElement.hasAttribute("data-mobile")) return;
  if (!p.s || WARM.has(t.id) || p.queue !== S.queue || S.queue[nextIndex()]?.id !== t.id || t.id === S.current?.id) return;
  const s = p.s, useHls = s.type === "hls" && window.Hls && Hls.isSupported();
  const cors = !AX.failed && (useHls || !noCorsHosts.has(hostOf(s.url)));
  const el = newAudio(cors);
  setLevel(el, 0);
  const w = { id: t.id, el, hls: null, s };
  w.fail = () => { if (WARM.get(w.id) === w) warmDrop(w); };
  el.addEventListener("error", w.fail, { once: true });
  putWarm(w);
  if (WARM.get(w.id) !== w) return;
  if (useHls) w.hls = makeHls(el, s.url, () => {
    if (WARM.get(w.id) === w) warmDrop(w);
    else if (XF.nx?.el === el) dropPending();
    else if (audio === el && hls === w.hls) onError(new Error("Ошибка потока HLS"));
  }, 0, true);
  else el.src = s.url;
}
// A selected version is prepared on a separate silent deck while the old stream keeps playing.
const VERSION = { job: null };
function cancelVersionSwitch() {
  const job = VERSION.job;
  if (!job) return;
  VERSION.job = null;
  clearTimeout(job.timer);
  job.controller.abort();
  if (job.el) stopEl(job.el, job.hls);
}
function versionAwait(promise, signal) {
  return new Promise((resolve, reject) => {
    if (signal.aborted) return reject(new Error("cancelled"));
    const abort = () => {
      cleanup();
      reject(new Error("cancelled"));
    };
    const cleanup = () => signal.removeEventListener("abort", abort);
    signal.addEventListener("abort", abort, { once: true });
    Promise.resolve(promise).then(
      (v) => {
        cleanup();
        resolve(v);
      },
      (e) => {
        cleanup();
        reject(e);
      },
    );
  });
}
function versionEvent(el, type, signal) {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      el.removeEventListener(type, ok);
      el.removeEventListener("error", fail);
      signal.removeEventListener("abort", abort);
    };
    const ok = () => {
      cleanup();
      resolve();
    };
    const fail = () => {
      cleanup();
      reject(new Error("version-media-error"));
    };
    const abort = () => {
      cleanup();
      reject(new Error("cancelled"));
    };
    if (signal.aborted) return abort();
    el.addEventListener(type, ok, { once: true });
    el.addEventListener("error", fail, { once: true });
    signal.addEventListener("abort", abort, { once: true });
  });
}
async function switchVersion(t, match) {
  cancelVersionSwitch();
  if (S.current?.id !== t.id) return;
  stopFades();
  XF.pre = null;
  const job = {
    old: audio,
    seq: playSeq,
    controller: new AbortController(),
    el: null,
    hls: null,
    timer: 0,
    timeout: false,
  };
  VERSION.job = job;
  const signal = job.controller.signal;
  job.timer = setTimeout(() => {
    job.timeout = true;
    job.controller.abort();
  }, 25000);
  toast("Версия сохранена · подготавливаю поток…", 3000);
  const valid = () =>
    VERSION.job === job && audio === job.old && playSeq === job.seq && S.current?.id === t.id && !job.old.ended;
  try {
    const stream = await versionAwait(streamFor(t, true), signal);
    if (!valid()) return;
    // resolveStream can fall back silently: never claim that a different candidate was selected.
    if (match && stream.via?.id !== match.id) throw new Error("выбранный источник недоступен");
    const useHls = stream.type === "hls" && window.Hls && Hls.isSupported();
    const setup = async (cors) => {
      const el = newAudio(cors);
      job.el = el;
      el._lvl = 0;
      if (cors) attachDeck(el);
      setLevel(el, 0);
      const metadata = versionEvent(el, "loadedmetadata", signal);
      if (useHls) job.hls = makeHls(el, stream.url, () => job.controller.abort(), job.old.currentTime);
      else el.src = stream.url;
      await metadata;
      return el;
    };
    let el;
    const cors = !AX.failed && (useHls || !noCorsHosts.has(hostOf(stream.url)));
    try {
      el = await setup(cors);
    } catch (e) {
      if (signal.aborted || useHls || !cors || e.message !== "version-media-error") throw e;
      noCorsHosts.add(hostOf(stream.url));
      stopEl(job.el, job.hls);
      job.el = job.hls = null;
      el = await setup(false);
    }
    if (!valid()) return;
    AX.ctx?.resume().catch(() => {});
    // Re-sample the running old deck after buffering/seek; don't restart at zero.
    for (let n = 0; n < 4; n++) {
      if (!valid()) return;
      const at = Math.max(0, job.old.currentTime || 0);
      if (Number.isFinite(el.duration) && at >= el.duration - 0.2) throw new Error("эта версия короче текущей позиции");
      if (Math.abs(el.currentTime - at) > 0.08) {
        const seeked = versionEvent(el, "seeked", signal);
        el.currentTime = at;
        await seeked;
      }
      if (!valid()) return;
      if (job.old.paused) {
        el.pause();
        break;
      }
      if (el.paused) await versionAwait(el.play(), signal);
      if (Math.abs(el.currentTime - job.old.currentTime) < 0.25) break;
    }
    if (!valid()) return;
    if (job.old.paused) el.pause();
    else {
      if (el.paused) await versionAwait(el.play(), signal);
      if (!valid()) return;
      if (Math.abs(el.currentTime - job.old.currentTime) > 0.6) throw new Error("не удалось синхронизировать поток");
    }
    const old = job.old,
      oldHls = hls,
      paused = old.paused;
    VERSION.job = null;
    clearTimeout(job.timer);
    setActive(el);
    hls = job.hls;
    job.el = job.hls = null;
    if (paused) {
      el.pause();
      stopEl(old, oldHls);
      setLevel(el, 1);
      applyGain();
    } else {
      XF.old = { el: old, hls: oldHls, timer: setTimeout(killOld, 300) };
      applyGain();
      fadeLevel(old, 0, 0.1);
      fadeLevel(el, 1, 0.1);
    }
    S.stream = stream;
    updateNow(S.current, stream);
    setPlayIcons();
    lastTu = 0;
    onTimeUpdate();
    toast("Версия переключена", 2200);
  } catch (e) {
    if (VERSION.job !== job) return;
    const message = job.timeout
      ? "источник слишком долго отвечает"
      : e.message === "cancelled"
        ? "источник недоступен"
        : e.message;
    cancelVersionSwitch();
    toast("Версия сохранена, но не переключилась: " + message + ". Текущий поток не изменён.", 7000);
  } finally {
    if (VERSION.job === job && !valid()) cancelVersionSwitch();
  }
}
function setLevel(el, v) {
  el._lvl = v;
  clearInterval(el._fadeIv);
  const d = AX.decks.get(el);
  if (d) {
    const now = AX.ctx.currentTime;
    d.g.gain.cancelScheduledValues(now);
    d.g.gain.setValueAtTime(v, now);
    deckNeutral(d);
  } else el.volume = Math.min(1, volNow()) * v;
}
// element volume: a JS ramp along f(0…1) (timers keep running in the background — audible pages are not throttled)
function elRamp(el, f, dur) {
  clearInterval(el._fadeIv);
  const t0 = performance.now();
  const step = () => {
    const x = Math.min(1, (performance.now() - t0) / (dur * 1000));
    el.volume = Math.max(0, Math.min(1, Math.min(1, volNow()) * f(x)));
    if (x >= 1) clearInterval(el._fadeIv);
  };
  step();
  el._fadeIv = setInterval(step, 40);
}
function fadeLevel(el, to, dur) {
  const from = el._lvl ?? 1;
  el._lvl = to;
  clearInterval(el._fadeIv);
  if (dur <= 0.02) return setLevel(el, to);
  const curve = (x) =>
    to > from ? from + (to - from) * Math.sin((x * Math.PI) / 2) : to + (from - to) * Math.cos((x * Math.PI) / 2);
  const d = AX.decks.get(el);
  if (d) {
    const n = 64,
      c = new Float32Array(n);
    for (let k = 0; k < n; k++) c[k] = curve(k / (n - 1));
    const now = AX.ctx.currentTime,
      g = d.g.gain;
    g.cancelScheduledValues(now);
    try {
      g.setValueCurveAtTime(c, now, dur);
    } catch {
      g.setValueAtTime(from, now);
      g.linearRampToValueAtTime(to, now + dur);
    }
    return;
  }
  elRamp(el, curve, dur);
}
function nextIndex() {
  if (window.WaveSocial?.follower()) return -1;
  if ((S.repeat === "one" && !S.ctx?.preview) || S.index < 0) return -1;
  if (S.index < S.queue.length - 1) return S.index + 1;
  if (S.repeat === "all" && S.queue.length > 1) return 0;
  return -1;
}
function streamFor(t, prefetch) {
  const pid = /^(?:playlist|mix):(.+)$/.exec(S.ctx?.go || "")?.[1] || null;
  const prefer = pid ? S.playlists.find((p) => p.id === pid)?.matchSource : null;
  return api("stream", {
    track: t,
    exact: !!window.WaveSocial?.follower() || undefined,
    prefer: prefer || undefined,
    prefetch: prefetch || undefined,
    wave: (S.wave && S.queue.includes(t)) || undefined,
  });
}
function prefetchNext() {
  const i = nextIndex();
  if (i < 0) return;
  const t = S.queue[i];
  const saved = WARM.get(t.id);
  if (saved && saved.queue === S.queue && !saved.el.error && Date.now() - saved.at < WARM_TTL) {
    XF.pre = { id: t.id, queue: S.queue, at: saved.at, s: saved.s };
    return;
  }
  if (XF.pre?.id === t.id && XF.pre.queue === S.queue && Date.now() - XF.pre.at < WARM_TTL) {
    if (XF.pre.s) prepareWarm(XF.pre, t);
    return;
  }
  const p = { id: t.id, queue: S.queue, at: Date.now(), s: null };
  XF.pre = p;
  streamFor(t, true)
    .then((s) => {
      if (XF.pre !== p || p.queue !== S.queue || S.queue[nextIndex()]?.id !== t.id) return;
      p.s = s;
      prepareWarm(p, t);
    })
    .catch(() => { if (XF.pre === p) p.at = Date.now() - WARM_TTL + 15000; });
}
// a stream resolved ahead is used once, if it is fresh (signed CDN links expire)
function takePre(t) {
  const p = XF.pre;
  if (!p || p.id !== t.id || p.queue !== S.queue || !p.s || Date.now() - p.at > WARM_TTL) return null;
  XF.pre = null;
  api("played", { track: t }).catch(() => {});
  return p.s;
}
function makeHls(el, url, onFatal, start, warm = false) {
  const h = new Hls({ enableWorker: false, maxBufferLength: warm ? 12 : 60, ...(warm ? { maxBufferSize: 8 * 1024 * 1024 } : {}), ...(start > 0 ? { startPosition: start } : {}) });
  h.loadSource(url);
  h.attachMedia(el);
  h.on(Hls.Events.ERROR, (_e, d) => {
    if (!d.fatal) return;
    if (d.type === Hls.ErrorTypes.NETWORK_ERROR && !d._retried) {
      d._retried = true;
      h.startLoad();
    } else onFatal();
  });
  return h;
}
function killOld() {
  const o = XF.old;
  if (!o) return;
  XF.old = null;
  clearTimeout(o.timer);
  if (o.t && o.s) keepOldDeck(o.el, o.hls, o.t, o.s);
  else stopEl(o.el, o.hls);
}
function dropPending() {
  const nx = XF.nx;
  if (!nx) return;
  XF.nx = null;
  clearTimeout(nx.timer);
  stopEl(nx.el, nx.hls);
}
const stopFades = () => {
  dropPending();
  killOld();
  mixFxStop();
  setLevel(audio, 1); // a fade-in cut short (pause, manual switch) must not leave the track quiet
};
function xfCheck() {
  if (window.WaveSocial?.inRoom()) return;
  if (!S.current || audio.paused || seekDrag != null || VERSION.job) return;
  const d = audio.duration;
  if (!d || !isFinite(d)) return;
  const left = (d - audio.currentTime) / (audio.playbackRate || 1);
  // 4.14: «Микс» has its own timing (the next track is armed ahead, styles); the plain crossfade otherwise
  const mx = mixNext();
  if (mx) return mixCheck(mx, d, left);
  if (XF.nx?.mx && !XF.nx.going) dropPending(); // «Микс» was switched off while the next track waited
  if (XF.nx) return;
  if (left < 25) prefetchNext();
  const cf = SND.xf;
  if (!cf || d < cf * 2 + 4 || left > cf || left < 0.6) return;
  const i = nextIndex();
  if (i < 0) return;
  const t = S.queue[i];
  if (XF.pre?.id !== t.id || !XF.pre.s) return; // not resolved in time: the usual switch at the end
  crossfadeTo(i, t, takePre(t), left);
}
function crossfadeTo(i, t, s, left) {
  const useHls = s.type === "hls" && window.Hls && Hls.isSupported();
  const cors = !AX.failed && (useHls || !noCorsHosts.has(hostOf(s.url)));
  const prepared = takeWarm(t);
  const el = prepared?.el || newAudio(cors);
  el._lvl = 0;
  if (el.hasAttribute("crossorigin")) attachDeck(el);
  setLevel(el, 0);
  const nx = { el, hls: prepared?.hls || null, t, i, s, started: false };
  XF.nx = nx;
  const fail = () => XF.nx === nx && dropPending(); // the current track then simply ends and the next one loads
  if (!prepared && useHls) nx.hls = makeHls(el, s.url, fail);
  else if (!prepared) el.src = s.url;
  el.addEventListener("error", fail, { once: true });
  el.addEventListener("playing", () => XF.nx === nx && startFade(nx), { once: true });
  nx.timer = setTimeout(fail, Math.max(2500, left * 1000 + 400));
  AX.ctx?.resume().catch(() => {});
  el.play().catch(fail);
}
/* ---- 4.14: «Микс» — DJ-like transitions in own playlists (like Spotify Mix) ----
   A playlist with «Микс» on (or anything started from its «Микс» page) plays without pauses: before a transition
   the next track is armed — loaded and paused at its start point («Начать следующий с») — and starts exactly when
   the transition begins: its length before the end of the current track, minus «Убрать конец трека». The style
   moves the levels and the filters of both decks along curves (MIX_SHAPE); «Авто» also listens to the end of the
   track: a long quiet stretch (a fade-out, silence) starts the transition at once. */
const MIX_ST = [
  [
    "auto",
    "Авто",
    "Wave сам выбирает момент: тихие концовки не тянутся, а бас текущего трека мягко уступает следующему",
  ],
  ["fade", "Плавно", "Классический кроссфейд: один трек растворяется в другом"],
  ["rise", "Подъём", "Следующий трек поднимается из высоких частот, а текущий уходит под воду"],
  ["blend", "Смешивание", "Как у диджея: треки звучат вместе, а в середине перехода бас переходит к следующему"],
  ["echo", "Эхо", "Текущий трек улетает в эхо, пока вступает следующий"],
  ["cut", "Склейка", "Встык: следующий трек начинается ровно там, где закончился текущий"],
];
const seg = (x, a, b) => Math.max(0, Math.min(1, (x - a) / (b - a)));
const sstep = (x) => x * x * (3 - 2 * x);
const cosDown = (x) => Math.cos((x * Math.PI) / 2),
  sinUp = (x) => Math.sin((x * Math.PI) / 2);
// x = 0…1 of a transition → the level of the current (a) and of the next (b) deck; filters in Hz, shelves in dB
const MIX_SHAPE = {
  auto: {
    a: (x) => cosDown(seg(x, 0.12, 1)),
    b: (x) => sinUp(seg(x, 0, 0.85)),
    bHp: (x) => 400 * Math.pow(20 / 400, seg(x, 0, 0.6)),
    aLo: (x) => -14 * sstep(seg(x, 0.25, 0.75)),
  },
  fade: { a: cosDown, b: sinUp },
  rise: {
    a: (x) => cosDown(seg(x, 0.3, 1)),
    b: (x) => sinUp(seg(x, 0, 0.7)),
    bHp: (x) => 1800 * Math.pow(20 / 1800, sstep(seg(x, 0, 0.9))),
    aLp: (x) => 20000 * Math.pow(350 / 20000, sstep(seg(x, 0.1, 1))),
  },
  blend: {
    a: (x) => (1 - 0.2 * sstep(seg(x, 0.3, 0.5))) * cosDown(seg(x, 0.5, 1)),
    b: (x) => 0.8 * sinUp(seg(x, 0, 0.45)) + 0.2 * sstep(seg(x, 0.45, 0.65)),
    aLo: (x) => -24 * sstep(seg(x, 0.42, 0.52)),
    bLo: (x) => -24 * (1 - sstep(seg(x, 0.42, 0.52))),
  },
  echo: {
    a: (x) => cosDown(seg(x, 0.15, 0.5)),
    b: (x) => sinUp(seg(x, 0.3, 1)),
    send: (x) => (x < 0.45 ? sstep(seg(x, 0, 0.25)) : 1 - seg(x, 0.45, 0.5)),
  },
  cut: { a: (x) => (x < 0.5 ? 1 : 0), b: (x) => (x < 0.5 ? 0 : 1) },
};
// the «Микс» of what plays now: started from a «Микс» page, or from an own playlist with «Микс» on
function mixCfg() {
  if (S.wave) return null;
  const m = /^(mix|playlist):(.+)$/.exec(S.ctx?.go || "");
  const p = m && (m[2] === "@all" ? globalMix() : S.playlists.find((x) => x.id === m[2]));
  if (!mixable(p) || (m[1] === "playlist" && !p.mix?.on)) return null;
  return mixOf(p);
}
const mixKey = (a, b) => a.id + ">" + b.id;
// the transition A → B: the hand-made one of the pair, else the style and the length of the playlist
function mixPair(a, b, m) {
  const h = m.tr?.[mixKey(a, b)] || {};
  const style = h.style === "custom" ? "custom" : MIX_SHAPE[h.style] ? h.style : MIX_SHAPE[m.style] ? m.style : "auto";
  const custom = Number.isFinite(+h.bars) && +h.bars > 0;
  return {
    style,
    len: style === "cut" ? 0 : custom ? mxBarsLength(h.bars, h.bpmA) : h.len || m.len || 8,
    out: h.out || 0,
    in: h.in || 0,
    custom,
    vol: h.vol || "overlap",
    eq: h.eq || "end",
    fx: h.fx || "lowpass",
    curveVol: h.curveVol || 50,
    curveEq: h.curveEq || 50,
    curveFx: h.curveFx || 50,
    own: !!m.tr?.[mixKey(a, b)],
  };
}
function mixNext() {
  const m = S.current && mixCfg();
  if (!m) return null;
  const i = nextIndex();
  const t = i < 0 ? null : S.queue[i];
  return t && t.id !== S.current.id ? { ...mixPair(S.current, t, m), i, t } : null;
}
// «Авто»: the level of the current track (the analyser before the volume, so it does not depend on it)
const MQ = { id: null, sum: 0, n: 0, since: 0, buf: null };
function mixMeter() {
  if (!AX.ok || !AX.fx || !S.current) return null;
  if (!MQ.buf || MQ.buf.length !== AX.fx.fftSize) MQ.buf = new Float32Array(AX.fx.fftSize);
  AX.fx.getFloatTimeDomainData(MQ.buf);
  let e = 0;
  for (let k = 0; k < MQ.buf.length; k++) e += MQ.buf[k] * MQ.buf[k];
  const db = 10 * Math.log10(e / MQ.buf.length + 1e-12);
  if (MQ.id !== S.current.id) Object.assign(MQ, { id: S.current.id, sum: 0, n: 0, since: 0 });
  if (db > -60) {
    MQ.sum += db;
    MQ.n++;
  }
  return db;
}
// a long quiet stretch near the end — 20 dB under the average of the track for 1.6 s: the music is over
function mixQuiet(db) {
  if (db == null || MQ.n < 40) return false;
  if (db > Math.max(-48, MQ.sum / MQ.n - 20)) return ((MQ.since = 0), false);
  const now = performance.now();
  if (!MQ.since) MQ.since = now;
  return now - MQ.since > 1600;
}
function mixCheck(mx, d, left) {
  const nx = XF.nx;
  const db = mx.style === "auto" ? mixMeter() : null;
  if (nx && (!nx.mx || nx.going)) return;
  if (nx && nx.t.id !== mx.t.id) return dropPending(); // the queue changed while the next track waited
  const rate = audio.playbackRate || 1;
  // a short track gets a short transition; «out» never cuts more than a third of it
  const out = Math.min(mx.out, d / 3);
  const len = Math.min(mx.len, Math.max(0, (d - out) / 3));
  const toEnd = (d - out - audio.currentTime) / rate;
  const lead = toEnd - len; // seconds until the transition starts
  const arm = mx.style === "auto" ? 30 : 14;
  if (!nx) {
    if (lead < arm + 16) prefetchNext(); // once: an armed track has taken its stream already
    if (lead > arm || left < 1.2) return;
    if (XF.pre?.id !== mx.t.id || !XF.pre.s) return; // not resolved yet: the next timeupdate tries again
    return mixArm({ ...mx, out, len }, takePre(mx.t));
  }
  if (mx.style === "auto" && lead > 0.5 && mixQuiet(db)) {
    nx.mx.len = Math.min(len, 5);
    return nx.go(0);
  }
  if (lead <= 0.3) nx.go(Math.max(0, lead * 1000));
}
// the next track waits paused at its start point; go() starts it on time, startFade() takes over on «playing»
function mixArm(mx, s) {
  if (!s) return;
  const useHls = s.type === "hls" && window.Hls && Hls.isSupported();
  const cors = !AX.failed && (useHls || !noCorsHosts.has(hostOf(s.url)));
  const prepared = takeWarm(mx.t);
  const el = prepared?.el || newAudio(cors);
  el._lvl = 0;
  if (el.hasAttribute("crossorigin")) attachDeck(el);
  setLevel(el, 0);
  const nx = { el, hls: prepared?.hls || null, t: mx.t, i: mx.i, s, started: false, mx, going: false, played: false };
  XF.nx = nx;
  const fail = () => XF.nx === nx && dropPending(); // the current track then ends and the next one loads as usual
  if (!prepared && useHls) nx.hls = makeHls(el, s.url, fail, mx.in);
  else if (!prepared) el.src = s.url;
  if (prepared && mx.in) try { el.currentTime = mx.in; } catch {}
  if (mx.in && !useHls)
    el.addEventListener(
      "loadedmetadata",
      () => !nx.played && el.currentTime < mx.in - 0.5 && el.duration > mx.in + 5 && (el.currentTime = mx.in),
      { once: true },
    );
  el.addEventListener("error", fail, { once: true });
  el.addEventListener("playing", () => XF.nx === nx && startFade(nx), { once: true });
  nx.play = () => {
    if (nx.played) return;
    nx.played = true;
    AX.ctx?.resume().catch(() => {});
    el.play().catch(() => (XF.nx === nx ? dropPending() : audio === el && next()));
  };
  nx.go = (ms) => {
    if (nx.going) return;
    nx.going = true;
    clearTimeout(nx.timer);
    nx.timer = setTimeout(() => {
      if (XF.nx !== nx) return;
      nx.play();
      nx.timer = setTimeout(fail, 6000);
    }, ms);
  };
}
// Independent Volume / EQ / Effects controls of a custom transition.
function mixCustomShape(mx) {
  const sh =
    mx.vol === "cut"
      ? { a: (x) => (x < 0.98 ? 1 : 0), b: (x) => (x < 0.98 ? 0 : 1) }
      : mx.vol === "fade"
        ? { a: cosDown, b: sinUp }
        : { a: (x) => cosDown(seg(x, 0.3, 1)), b: (x) => sinUp(seg(x, 0, 0.7)) };
  if (mx.eq === "mid" || mx.eq === "end") {
    const lo = mx.eq === "end" ? 0.72 : 0.42,
      hi = mx.eq === "end" ? 0.95 : 0.6;
    sh.aLo = (x) => -24 * sstep(seg(x, lo, hi));
    sh.bLo = (x) => -24 * (1 - sstep(seg(x, lo, hi)));
  }
  if (mx.fx === "lowpass") sh.aLp = (x) => 20000 * Math.pow(350 / 20000, sstep(seg(x, 0.1, 1)));
  if (mx.fx === "highpass") sh.bHp = (x) => 1800 * Math.pow(20 / 1800, sstep(seg(x, 0, 0.9)));
  if (mx.fx === "echo") sh.send = (x) => (x < 0.45 ? sstep(seg(x, 0, 0.25)) : 1 - seg(x, 0.45, 0.5));
  // Adjustable midpoint: same functions are used by playback and the editor.
  const warp = (x, value) => {
    const p = Math.max(0.1, Math.min(0.9, (+value || 50) / 100));
    return x < p ? (x * 0.5) / p : 0.5 + ((x - p) * 0.5) / (1 - p);
  };
  for (const [key, control] of [
    ["a", "curveVol"],
    ["b", "curveVol"],
    ["aLo", "curveEq"],
    ["bLo", "curveEq"],
    ["aLp", "curveFx"],
    ["bHp", "curveFx"],
    ["send", "curveFx"],
  ]) {
    if (sh[key]) {
      const f = sh[key];
      sh[key] = (x) => f(warp(x, mx[control]));
    }
  }
  return sh;
}
// one transition: the deck gains and filters along the curves of the style (Web Audio), element volumes otherwise
function mixCurves(a, b, style, dur, mx) {
  const sh = mx?.custom ? mixCustomShape(mx) : MIX_SHAPE[style] || MIX_SHAPE.fade;
  a._lvl = 0;
  b._lvl = 1;
  const da = AX.decks.get(a),
    db = AX.decks.get(b);
  const t0 = AX.ctx?.currentTime || 0;
  const n = Math.max(32, Math.min(480, Math.round(dur * 40)));
  const put = (prm, f, end) => {
    const c = new Float32Array(n);
    for (let k = 0; k < n; k++) c[k] = f(k / (n - 1));
    try {
      prm.cancelScheduledValues(t0);
      prm.setValueCurveAtTime(c, t0, dur);
      if (end != null) prm.setValueAtTime(end, t0 + dur + 0.02);
    } catch {
      try {
        prm.setValueAtTime(end ?? c[n - 1], t0);
      } catch {}
    }
  };
  if (da) {
    put(da.g.gain, sh.a);
    if (sh.aLp && da.lp) put(da.lp.frequency, sh.aLp);
    if (sh.aLo && da.lo) put(da.lo.gain, sh.aLo);
    if (sh.send) mixEcho(da, sh.send, t0, dur);
  } else elRamp(a, sh.a, dur);
  if (db) {
    put(db.g.gain, sh.b, 1);
    if (sh.bHp && db.hp) put(db.hp.frequency, sh.bHp, 0);
    if (sh.bLo && db.lo) put(db.lo.gain, sh.bLo, 0);
  } else elRamp(b, sh.b, dur);
}
// «Эхо»: a feedback delay fed from the current deck before its fader; its tail outlives the deck
const MIXFX = new Set();
function mixEcho(d, send, t0, dur) {
  const c = AX.ctx;
  try {
    const tap = c.createGain(),
      dl = c.createDelay(2),
      fb = c.createGain(),
      hp = c.createBiquadFilter(),
      lp = c.createBiquadFilter(),
      wet = c.createGain();
    dl.delayTime.value = 0.375;
    fb.gain.value = 0.52;
    hp.type = "highpass";
    hp.frequency.value = 220;
    lp.type = "lowpass";
    lp.frequency.value = 3400;
    wet.gain.value = 0.7;
    tap.gain.value = 0;
    const n = 64,
      cv = new Float32Array(n);
    for (let k = 0; k < n; k++) cv[k] = send(k / (n - 1));
    tap.gain.setValueCurveAtTime(cv, t0, dur);
    d.src.connect(tap);
    tap.connect(dl);
    dl.connect(hp);
    hp.connect(lp);
    lp.connect(fb);
    fb.connect(dl);
    lp.connect(wet);
    wet.connect(AX.bus);
    const fx = { nodes: [tap, dl, fb, hp, lp, wet], timer: 0 };
    fx.timer = setTimeout(() => mixFxEnd(fx), (dur + 5) * 1000);
    MIXFX.add(fx);
  } catch {}
}
function mixFxEnd(fx) {
  clearTimeout(fx.timer);
  MIXFX.delete(fx);
  for (const x of fx.nodes)
    try {
      x.disconnect();
    } catch {}
}
const mixFxStop = () => [...MIXFX].forEach(mixFxEnd);
function startFade(nx, quick) {
  clearTimeout(nx.timer);
  XF.nx = null;
  nx.started = true;
  killOld();
  const old = audio,
    oldHls = hls,
    oldTrack = S.current,
    oldStream = S.stream;
  const d = old.duration;
  const left = d && isFinite(d) ? (d - old.currentTime) / (old.playbackRate || 1) : 0;
  const mx = nx.mx; // 4.14: a «Микс» transition: its own length and curves
  const dur =
    quick || old.ended
      ? 0.05
      : mx
        ? mx.style === "cut"
          ? 0.06
          : Math.max(0.3, Math.min(mx.len, left))
        : Math.max(0.3, Math.min(SND.xf, left));
  setActive(nx.el);
  hls = nx.hls;
  ++playSeq; // a playAt still waiting for its stream must not take over
  S.index = nx.i;
  S.current = nx.t;
  XF.old = { el: old, hls: oldHls, t: oldTrack, s: oldStream, timer: setTimeout(killOld, dur * 1000 + 200) };
  applyGain();
  if (mx && dur > 0.1) mixCurves(old, audio, mx.style, dur, mx);
  else {
    fadeLevel(old, 0, dur);
    fadeLevel(audio, 1, dur);
  }
  afterStart(nx.t, nx.s);
  renderQueue();
  markRows();
  setPlayIcons();
  progStart();
}
const np = (k) => document.querySelectorAll(`[data-np="${k}"]`);
function syncVolUi() {
  const pc = (vol / VOL_MAX) * 100;
  np("vol").forEach((e) => {
    if (e.parentElement?.hasAttribute("data-vert")) {
      e.style.height = pc + "%";
      e.style.width = "";
    } else {
      e.style.width = pc + "%";
      e.style.height = "";
    }
  });
  np("volval").forEach((e) => (e.textContent = Math.round(vol * 100) + "%"));
  const ic = icon(muted || vol === 0 ? "mute" : "volume");
  np("volicon").forEach((e) => (e.innerHTML = ic));
  $$("[data-vol]").forEach((e) => e.classList.toggle("boost", vol > 1));
}
function setVol(v, persist) {
  vol = Math.max(0, Math.min(VOL_MAX, Math.round(v * 1000) / 1000));
  if (vol > 1 && !AX.ok && !AX.failed && S.current) audioGraph();
  applyGain();
  syncVolUi();
  if (persist) {
    clearTimeout(volSave);
    volSave = setTimeout(() => api("settings", { volume: vol }).catch(() => {}), 400);
  }
}
const nudgeVol = (d) => {
  muted = false;
  let v = vol + d;
  if ((vol < 1 && v > 1) || (vol > 1 && v < 1)) v = 1; // stop at 100 % on the way up/down
  setVol(v, true);
};
document.addEventListener(
  "wheel",
  (e) => {
    const w = e.target.closest(".vol-wrap,[data-vol],.fpb-vol");
    if (!w) return;
    e.preventDefault();
    nudgeVol(-Math.sign(e.deltaY) * 0.05);
  },
  { passive: false },
);
// «Моя волна»: the track pill is a seek bar too — hover shows the time under the cursor
document.addEventListener(
  "pointermove",
  (e) => {
    const p = e.target.closest?.(".wpill[data-seek]");
    if (!p) return;
    const r = p.getBoundingClientRect(),
      f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    p.style.setProperty("--hx", (f * 100).toFixed(2) + "%");
    const tip = p.querySelector(".wpill-tip"),
      d = curDur();
    if (tip) tip.textContent = d ? fmt(f * d) : "";
  },
  { passive: true },
);
// seek & volume bars (all copies: player bar, full-screen variants, Моя волна)
let seekDrag = null;
const curDur = () => {
  const d = audio.duration;
  return d && isFinite(d) ? d : S.current?.duration || 0;
};
const curPct = () => {
  const d = curDur();
  return d && S.current ? Math.min(100, (audio.currentTime / d) * 100) : 0;
};
// A failed stream seek must not silently skip or restart the track.
const manualSeek = { id: null, until: 0, pending: null };
function seekToTime(seconds) {
  if (!S.current || !Number.isFinite(seconds)) return;
  const el = audio, id = S.current.id, duration = curDur();
  const target = Math.max(0, duration > 0 ? Math.min(seconds, Math.max(0, duration - 0.15)) : seconds);
  manualSeek.id = id;
  manualSeek.until = Date.now() + 8000;
  manualSeek.pending = null;
  stopFades();
  if (el.readyState === 0 && !Number.isFinite(el.duration)) {
    manualSeek.pending = { id, target };
    return;
  }
  try { el.currentTime = target; }
  catch (_) { toast("Не удалось перемотать этот поток", 3000); }
}
document.addEventListener("pointerdown", (e) => {
  const bar = e.target.closest("[data-seek],[data-vol]");
  if (!bar || e.button !== 0 || !e.isPrimary) return;
  // Mobile touch hit-testing can snap a finger above the narrow rail onto it.
  // Only start seeking when the actual contact is inside the mini-player rail.
  if (bar.id === "seekbar" && root.hasAttribute("data-mobile")) {
    const r = bar.getBoundingClientRect();
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return;
  }
  const btn = e.target.closest("button");
  if (btn && bar.contains(btn) && btn !== bar) return;
  e.preventDefault();
  const isVol = bar.hasAttribute("data-vol");
  const pointerId = e.pointerId;
  const trackId = S.current?.id;
  const vert = bar.hasAttribute("data-vert");
  let last = null;
  try { bar.setPointerCapture(pointerId); } catch {}
  bar.classList.add("drag");
  if (!isVol) stopFades();
  const pos = (ev) => {
    const r = bar.getBoundingClientRect();
    if (!r.width || !r.height) return last;
    return vert ? Math.max(0, Math.min(1, 1 - (ev.clientY - r.top) / r.height))
      : Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width));
  };
  const move = (ev) => {
    if (ev.pointerId !== pointerId) return;
    const p = pos(ev);
    if (p == null || !Number.isFinite(p)) return;
    last = p;
    if (isVol) {
      muted = false;
      let v = p * VOL_MAX;
      if (Math.abs(v - 1) < 0.035) v = 1;
      setVol(v, true);
    } else {
      seekDrag = p;
      setFill(p * 100);
      $("#player").style.setProperty("--pf", p.toFixed(5));
      np("cur").forEach((c) => (c.textContent = fmt(p * curDur())));
    }
  };
  const end = (ev) => {
    if (ev.pointerId !== pointerId) return;
    const cancelled = ev.type !== "pointerup";
    if (!cancelled) move(ev);
    document.removeEventListener("pointermove", move, true);
    document.removeEventListener("pointerup", end, true);
    document.removeEventListener("pointercancel", end, true);
    bar.classList.remove("drag");
    if (!isVol) {
      const fraction = seekDrag;
      seekDrag = null;
      if (!cancelled && fraction != null && S.current?.id === trackId) {
        const d = curDur();
        if (d > 0) seekToTime(fraction * d);
        else toast("Длительность ещё не загружена", 2200);
      }
      lastPc = -1;
      paintProgress();
    }
  };
  move(e);
  document.addEventListener("pointermove", move, true);
  document.addEventListener("pointerup", end, true);
  document.addEventListener("pointercancel", end, true);
});

/* ---------------- player ---------------- */
// what is playing: shown on «Моя волна» as the «Мне нравится ⌄» pill (like Yandex Music)
const PAGE_CTX = {
  likes: "Мне нравится",
  history: "История",
  home: "Для вас и тренды",
  search: "Поиск",
  collection: "Коллекция",
  profile: "Профиль",
};
function routeCtx() {
  const r = S.route || "";
  const name = r.split(":")[0];
  if (S.pageTitle && S.pageTitle.route === r) return { title: S.pageTitle.title, go: r };
  if (PAGE_CTX[name]) return { title: PAGE_CTX[name], go: name === "search" ? "search" : r };
  return null;
}
function playFromRow(list, i, lid) {
  const pop = S.popularQueue;
  if (!pop || pop.lid !== lid) return playList(list, i);
  const all = pop.list.slice();
  const at = all.findIndex((t) => t.id === list[i]?.id);
  playList(all, Math.max(0, at), { title: pop.name + " · популярные треки", go: pop.route });
  const queue = S.queue;
  api("artist-tracks", { id: pop.id, name: pop.name })
    .then((r) => {
      if (S.queue !== queue || S.shuffle) return;
      const ids = new Set(queue.map((t) => t.id));
      for (const t of r.tracks || [])
        if (!ids.has(t.id)) {
          ids.add(t.id);
          queue.push(t);
        }
      renderQueue();
    })
    .catch(() => {});
}
function playList(list, i, ctx) {
  if (window.WaveSocial && !window.WaveSocial.canPlay()) return;
  if (S.route?.startsWith("search") && S.lastSearch) pushSearch(S.lastSearch);
  S.wave = false;
  S.ctx = ctx || routeCtx();
  S.queue = [...list];
  S.lists.q = S.queue;
  S.index = -1;
  if (S.shuffle) {
    const t = S.queue.splice(i, 1)[0];
    for (let k = S.queue.length - 1; k > 0; k--) {
      const j = Math.floor(Math.random() * (k + 1));
      [S.queue[k], S.queue[j]] = [S.queue[j], S.queue[k]];
    }
    S.queue.unshift(t);
    i = 0;
  }
  playAt(i);
}
// a Yandex wave card: the station of Yandex with the account; without it — the closest own wave
function playStation(id) {
  if (S.settings.ymToken) return startWave({ station: id });
  const [type, tag] = String(id).split(":");
  if (type === "mood" && MOODS.some(([k]) => k === tag)) return startWave({ mood: tag });
  if (type === "genre" && tag) return go("genre:" + encodeURIComponent(tag));
  toast("Волны Яндекса играют с подключённым аккаунтом (Настройки → Подключения) — включаю Мою волну", 3200);
  startWave({});
}
// Space artists in recommendation queues without changing likes or user-made playlists.
// Collaboration credits count too; when alternatives run out, retain the remaining tracks instead of stopping.
function waveArtistKeys(t) {
  const names = artistList(t).flatMap((a) => String(a.name || "").split(/\s*(?:,|;|&|\bfeat\.?\b|\bft\.?\b|\bи\b)\s*/i));
  return [...new Set(names.map(nKey).filter((x) => x && x !== "неизвестныйисполнитель" && x !== "unknownartist"))];
}
function arrangeWave(list, prior = []) {
  const pool = [], ids = new Set(), songs = new Set();
  for (const t of list || []) {
    if (!t || !t.id || ids.has(t.id)) continue;
    const artists = waveArtistKeys(t);
    const title = nKey(t.title || "");
    const key = artists.length && title ? artists.slice().sort().join("+") + "|" + title : "";
    if (key && songs.has(key)) continue;
    ids.add(t.id);
    if (key) songs.add(key);
    pool.push({t, artists});
  }
  const output = [], recent = prior.slice(-3).map(waveArtistKeys);
  while (pool.length) {
    // Prefer the earliest recommendation that does not share an artist with the previous three tracks.
    // If there is no such option, choose the least recently heard artist rather than discard music.
    let best = 0, bestPenalty = Infinity;
    for (let i=0; i<pool.length; i++) {
      const a = pool[i].artists;
      let penalty = 0;
      for (let j=0; j<recent.length; j++)
        if (a.some((key) => recent[j].includes(key))) penalty += 1 << j;
      if (penalty < bestPenalty) { best = i; bestPenalty = penalty; if (!penalty) break; }
    }
    const item = pool.splice(best, 1)[0];
    output.push(item.t);
    recent.push(item.artists);
    if (recent.length > 3) recent.shift();
  }
  return output;
}
let autoWaveJob = null;
// 4.20.3: «Моя волна» starts without a wait — the list and the first track's stream are prepared in advance
const WAVE_WARM_TTL = 2 * 60e3;
let waveWarm = null;
function waveWarmKey(opts) {
  return JSON.stringify([opts || {}, S.settings?.wave || null, S.settings?.waveSource || "wave", S.wavePreset || ""]);
}
function waveWarmup(opts = {}) {
  if (!window.wave || opts.seed || (S.wave && S.current)) return;
  if (window.WaveSocial?.follower?.()) return;
  const key = waveWarmKey(opts);
  if (waveWarm && waveWarm.key === key && Date.now() - waveWarm.at < WAVE_WARM_TTL) return;
  const w = { key, at: Date.now(), first: null };
  w.job = api("wave", opts).then((list) => {
    if (!list?.length) throw new Error("empty");
    const recentIds = new Set(S.history.slice(0, 30).map((x) => x.id));
    const t = list.find((x) => x && !recentIds.has(x.id)) || list[0];
    api("stream", { track: t, prefetch: true, wave: true })
      .then((s) => { if (s?.url) w.first = { id: t.id, s, at: Date.now() }; })
      .catch(() => {});
    return list;
  });
  w.job.catch(() => { if (waveWarm === w) waveWarm = null; });
  waveWarm = w;
}
function takeWaveWarm(opts) {
  const w = waveWarm;
  if (!w || opts.seed || w.key !== waveWarmKey(opts) || Date.now() - w.at > WAVE_WARM_TTL) return null;
  waveWarm = null;
  return w;
}
async function startWave(opts = {}) {
  if (window.WaveSocial && !window.WaveSocial.canPlay()) return;
  window.lastWaveStart = Date.now();
  const guard = playSeq;
  toast("Настраиваю Мою волну…", 2500);
  try {
    const prefetched = opts.seed && autoWaveJob?.id === opts.seed.id ? autoWaveJob.job : null;
    autoWaveJob = null;
    const warm = !prefetched ? takeWaveWarm(opts) : null;
    let list = await (prefetched || (warm && warm.job.catch(() => null)) || api("wave", opts));
    if (guard !== playSeq) return;
    if (opts.seed) list = (list || []).filter((t) => t.id !== opts.seed.id && songKey(t) !== songKey(opts.seed));
    if (!list?.length && (prefetched || warm)) list = await api("wave", opts);
    if (guard !== playSeq) return;
    if (opts.seed) list = (list || []).filter((t) => t.id !== opts.seed.id && songKey(t) !== songKey(opts.seed));
    if (!list?.length) throw new Error("не удалось подобрать треки — проверьте интернет и источники в настройках");
    S.wave = true;
    S.ctx = null;
    S.waveOpts = opts;
    const recent = S.history.slice(0, 30);
    const recentIds = new Set(recent.map((x) => x.id));
    const fresh = list.filter((x) => x && !recentIds.has(x.id));
    S.queue = arrangeWave(fresh.length ? fresh : list, recent.slice(0, 3).reverse());
    // the track whose stream is already resolved goes first: playback starts at once
    const first = warm?.first;
    if (first && Date.now() - first.at < WARM_TTL) {
      const k = S.queue.findIndex((x) => x.id === first.id);
      if (k > 0) S.queue.unshift(S.queue.splice(k, 1)[0]);
      if (k >= 0) XF.pre = { id: first.id, queue: S.queue, at: first.at, s: first.s };
    }
    S.lists.q = S.queue;
    S.index = -1;
    playAt(0);
  } catch (e) {
    if (guard === playSeq) toast("Моя волна: " + e.message, 6000);
  }
}
let playSeq = 0;
async function playAt(i) {
  if (window.WaveSocial && !window.WaveSocial.canPlay()) return;
  if (i < 0 || i >= S.queue.length) return;
  cancelVersionSwitch();
  const oldTrack = S.current, oldStream = S.stream, oldIndex = S.index;
  S.index = i;
  const t = S.queue[i];
  S.current = t;
  manualSeek.pending = null;
  manualSeek.until = 0;
  S.stream = null;
  S.pendingResume = false;
  // 4.14: a start position — {t} seconds (Ctrl+R continues from the same second) or {end} seconds before the end
  const st = S.startAt?.id === t.id ? S.startAt : null;
  S.startAt = null;
  const my = ++playSeq;
  if (document.documentElement.hasAttribute("data-mobile")) S.mobileSwitching = my;
  stopFades(); // a manual switch cancels a running crossfade
  if (S.ctx?.preview) audio.pause(); // don't display one track while the previous one is still playing
  updateNow(t, null);
  renderQueue();
  markRows();
  if (!AX.ok && !AX.failed) {
    audioGraph();
    applyGain();
  }
  AX.ctx?.resume().catch(() => {});
  try {
    const prepared = !st ? takeWarm(t) : null;
    const pre = window.WaveSocial?.follower() ? null : takePre(t);
    const s = prepared?.s || pre || (await streamFor(t));
    if (prepared && !pre) api("played", { track: t }).catch(() => {});
    if (my !== playSeq) { if (prepared) stopEl(prepared.el, prepared.hls); return; }
    const useHls = s.type === "hls" && window.Hls && Hls.isSupported();
    const cors = !AX.failed && (useHls || !noCorsHosts.has(hostOf(s.url)));
    const adjacent = oldTrack && oldStream && oldTrack.id !== t.id && Math.abs(oldIndex - i) === 1 && warmNeighbors().has(oldTrack.id);
    if (prepared || adjacent) {
      const old = audio, oldHls = hls;
      const el = prepared?.el || newAudio(cors);
      setActive(el);
      hls = prepared?.hls || null;
      keepOldDeck(old, oldHls, oldTrack, oldStream);
      if (el.hasAttribute("crossorigin")) audioGraph();
    } else {
      if (hls) { hls.destroy(); hls = null; }
      swapAudio(cors);
    }
    setLevel(audio, 1);
    applyRate(audio);
    const d0 = t.duration || 0;
    const at = !st ? 0 : st.end != null ? (d0 > st.end + 2 ? d0 - st.end : 0) : Math.max(0, st.t || 0);
    if (!prepared && useHls) {
      const h = makeHls(audio, s.url, () => hls === h && onError(new Error("Ошибка потока HLS")), at);
      hls = h;
    } else if (!prepared) {
      audio.src = s.url;
      if (at > 0) audio.currentTime = at;
    } else {
      try { audio.currentTime = at; } catch {}
    }
    applyGain();
    try {
      if (!window.WaveSocial?.follower() || window.WaveSocial.shouldPlay()) await audio.play();
    } catch (err) {
      if (my === playSeq) {
        setPlayIcons();
        toast("Не удалось начать воспроизведение. Проверьте источник и нажмите Play ещё раз.", 5000);
      }
      return;
    }
    if (my !== playSeq) return;
    // the stream may be longer or shorter than the catalogue says: «before the end» is counted on the real one
    const dd = audio.duration;
    if (st?.end != null && isFinite(dd) && dd > st.end + 2 && Math.abs(audio.currentTime - (dd - st.end)) > 1.5)
      audio.currentTime = dd - st.end;
    afterStart(t, s);
  } catch (e) {
    if (my === playSeq) onError(e);
  } finally {
    if (S.mobileSwitching === my) { S.mobileSwitching = 0; waveTitle(); }
  }
}
// shared by a normal start and a crossfade
function afterStart(t, s) {
  window.WaveSocial?.publish();
  S.errors = 0;
  if (RECOVER.id !== t.id) Object.assign(RECOVER, { id: t.id, n: 0 });
  S.stream = s;
  pruneWarm();
  prefetchNext(); // resolve and buffer the next neighbour as soon as playback begins
  updateNow(t, s);
  if (s.preview && !s.matched) toast("Доступно только превью (SoundCloud Go+)", 3500);
  S.history = [t, ...S.history.filter((x) => x.id !== t.id)].slice(0, 200);
  // 4.8: refill earlier and never add a song that is already queued or was just played (also under another id)
  if (S.wave && S.queue.length - S.index < 6 && !S.refilling) {
    S.refilling = true;
    const waveQueue = S.queue;
    api("wave", S.waveOpts || {})
      .then((l) => {
        if (!S.wave || S.queue !== waveQueue) return;
        const ids = new Set([...S.queue, ...S.history.slice(0, 100)].map((x) => x.id));
        const keys = new Set([...S.queue.slice(S.index), ...S.history.slice(0, 100)].map(songKey));
        const candidates = [];
        for (const x of l) {
          const k = songKey(x);
          if (ids.has(x.id) || keys.has(k)) continue;
          ids.add(x.id);
          keys.add(k);
          candidates.push(x);
        }
        S.queue.push(...arrangeWave(candidates, S.queue.slice(-3)));
        renderQueue();
        prefetchNext();
      })
      .catch(() => {})
      .finally(() => (S.refilling = false));
  }
}
// «Artist|title» without versions — the same as extras.songKey in the main process
const nKey = (s) =>
  String(s || "")
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}]+/gu, "");
function songKey(t) {
  if (!t) return "";
  const a = t.artists?.[0]?.name || String(t.artist || "").split(/,|&| feat\.? | ft\.? /i)[0];
  const title = String(t.title || "")
    .replace(/\s*[([][^)\]]*[)\]]/g, "")
    .replace(/\s+(feat|ft)\.?\s.*$/i, "")
    .replace(/\s+-\s+.*$/, "");
  return nKey(a) + "|" + nKey(title || t.title);
}
function onError(e) {
  if (manualSeek.id === S.current?.id && Date.now() < manualSeek.until) {
    manualSeek.until = 0;
    toast("Не удалось перемотать этот поток. Попробуйте другую версию трека", 4000);
    return;
  }
  // 4.20.1: first the same track again — a fresh link from the same second (a dropped connection, an expired CDN
  // link, a stream that froze); only after three failed tries (or without a track) the queue moves on
  if (S.current && !S.ctx?.preview) {
    recoverStream(e).then((ok) => ok || skipBroken(e));
    return;
  }
  skipBroken(e);
}
function skipBroken(e) {
  S.errors++;
  toast((S.current ? S.current.title + ": " : "") + e.message, 4000);
  if (S.errors < 6 && S.index < S.queue.length - 1) setTimeout(() => playAt(S.index + 1), 1200);
}
/* ---- 4.20.1: reliable playback ----
   A broken or frozen stream is opened again from the second it stopped at, up to three times (right away, after
   1.5 s, after 4 s). Without internet it waits for the network and continues by itself; a track saved for offline
   listening comes back at once from the file (the core gives the saved copy instead of a link). */
const RECOVER = { id: null, n: 0, busy: false, wait: null };
const pauseMs = (ms) => new Promise((r) => setTimeout(r, ms));
function waitOnline() {
  if (navigator.onLine) return Promise.resolve();
  if (!RECOVER.wait)
    RECOVER.wait = new Promise((r) => addEventListener("online", () => { RECOVER.wait = null; r(); }, { once: true }));
  return RECOVER.wait;
}
async function recoverStream(e) {
  const t = S.current;
  if (!t || RECOVER.busy) return true;
  if (RECOVER.id !== t.id) Object.assign(RECOVER, { id: t.id, n: 0 });
  if (RECOVER.n >= 3) return false;
  RECOVER.busy = true;
  const my = playSeq;
  const pos = audio.currentTime > 1 ? audio.currentTime : S.startAt?.id === t.id ? S.startAt.t || 0 : 0;
  try {
    while (RECOVER.n < 3) {
      if (!navigator.onLine) {
        toast("Нет интернета — трек продолжится, когда сеть вернётся", 4000);
        // a saved copy plays at once; otherwise wait for the network
        const saved = await api("offline-has", { ids: [t.id] }).catch(() => ({}));
        if (!saved?.[t.id]) await waitOnline();
        if (my !== playSeq || S.current !== t) return true;
      }
      RECOVER.n++;
      await pauseMs([0, 1500, 4000][RECOVER.n - 1]);
      if (my !== playSeq || S.current !== t) return true;
      try {
        const s = await streamFor(t);
        if (my !== playSeq || S.current !== t) return true;
        if (hls) { hls.destroy(); hls = null; }
        if (s.type === "hls" && window.Hls && Hls.isSupported()) {
          const h = makeHls(audio, s.url, () => hls === h && onError(new Error("Ошибка потока HLS")), pos);
          hls = h;
        } else {
          audio.src = s.url;
          if (pos > 0) audio.currentTime = pos;
        }
        applyRate(audio);
        await audio.play();
        S.stream = s;
        S.errors = 0;
        if (pos > 1) toast("Связь восстановлена — продолжаю с того же места", 2200);
        return true;
      } catch {}
    }
    return false;
  } finally {
    RECOVER.busy = false;
  }
}
// a stream that stopped giving data while «playing» (waiting > 12 s with the network up) is opened again
(() => {
  let stuck = 0;
  setInterval(() => {
    if (!S.current || audio.paused || audio.readyState >= 3 || RECOVER.busy || !navigator.onLine) return void (stuck = 0);
    if ((stuck += 2) >= 12) {
      stuck = 0;
      onError(new Error("Поток завис"));
    }
  }, 2000);
})();
let socialNextJob = null;
function next(autoplay = false) {
  if (window.WaveSocial?.follower()) return;
  if (window.WaveSocial?.inRoom()) {
    if (socialNextJob) return socialNextJob;
    socialNextJob = (async () => {
      try {
        if (!(await window.WaveSocial.playNextProposal())) await normalNext(autoplay);
      } catch (e) {
        toast("Очередь комнаты: " + e.message, 5000);
        throw e;
      }
    })().finally(() => (socialNextJob = null));
    socialNextJob.catch(() => {});
    return socialNextJob;
  }
  return normalNext(autoplay);
}
function normalNext(autoplay = false) {
  if (S.repeat === "all" && S.index >= S.queue.length - 1) return playAt(0);
  if (S.index < S.queue.length - 1) playAt(S.index + 1);
  else if (S.wave) startWave(S.waveOpts || {});
  else if (autoplay && S.current && !S.ctx?.preview) startWave({ seed: S.current });
}
function prev() {
  if (window.WaveSocial && !window.WaveSocial.canPlay()) return;
  if (audio.currentTime > 4) {
    audio.currentTime = 0;
    return;
  }
  if (S.index > 0) playAt(S.index - 1);
  else audio.currentTime = 0;
}
function togglePlay() {
  if (window.WaveSocial && !window.WaveSocial.canPlay()) return;
  // 4.14: after Ctrl+R a paused track starts from the second it was paused at
  if (S.pendingResume && S.current && S.index >= 0) return void playAt(S.index);
  if (!S.current) {
    if (S.likes.length) playList(S.likes, 0);
    else startWave({});
    return;
  }
  AX.ctx?.resume().catch(() => {});
  if (audio.paused) audio.play().catch(() => {});
  else {
    stopFades(); // pause during a crossfade: the fading track stops too
    audio.pause();
  }
}
// «SoundCloud · AAC 160», «▶ Audius · MP3 320 · лучшая копия», «▶ SoundCloud · AAC 160 · подбор»
const qLabel = (q) => (q?.kbps ? `${q.codec || ""} ${q.kbps}`.trim() : q?.codec || "");
function srcBadge(t, s) {
  if (!s) return "Загрузка…";
  if (s.local) return "Свой файл";
  const by = s.hq || (s.matched ? s.via : t);
  const bid = String(by?.id || "");
  const name =
    SRC_NAME[by?.source] ||
    (bid.startsWith("au:")
      ? "Audius"
      : bid.startsWith("yt:")
        ? "YouTube Music"
        : bid.startsWith("ym:")
          ? "Яндекс Музыка"
          : "SoundCloud");
  const q = qLabel(s.q);
  const tail = s.hq
    ? " · лучшая копия"
    : s.drm
      ? " · вместо DRM"
      : s.matched
        ? " · подбор"
        : s.preview
          ? " · превью"
          : "";
  return (s.hq || s.matched ? "▶ " : "") + name + (q ? " · " + q : "") + tail;
}
function srcTip(t, s) {
  if (!s || s.local) return "";
  const q = s.q?.kbps ? `${s.q.codec || "Поток"} ${s.q.kbps} кбит/с` : "";
  if (s.hq) return `Играет та же запись в лучшем качестве: ${s.hq.artist} — ${s.hq.title}${q ? " (" + q + ")" : ""}`;
  if (s.drm) return "Оригинал на SoundCloud защищён DRM — играет полная версия из другого источника";
  if (s.matched && s.via) return `Играет подобранная полная версия: ${s.via.artist} — ${s.via.title}`;
  return q ? "Качество потока: " + q : "";
}
function updateNow(t, s) {
  const [m, v] = splitTitle(t.title);
  const pt = $("#pl-title");
  pt.innerHTML = isGlass() ? `<b>${esc(m)}</b>${v ? ` <span class="tv">${esc(v)}</span>` : ""}` : esc(t.title);
  pt.title = t.title;
  $("#pl-artist").innerHTML = artistsHtml(t) || esc(t.artist);
  const cv = $("#pl-cover");
  cv.style.backgroundImage = t.cover ? cssUrl(thumb(t.cover, "m")) : "";
  cv.innerHTML = (t.cover ? "" : icon("note")) + `<i class="pl-exp">${icon("expand")}</i>`;
  np("title").forEach((e) => (e.textContent = t.title));
  np("tmain").forEach((e) => (e.textContent = m));
  np("tver").forEach((e) => (e.textContent = v));
  const ah = artistsHtml(t) || esc(t.artist);
  np("artist").forEach((e) => (e.innerHTML = ah));
  const big = t.cover ? cssUrl(thumb(t.cover, "l")) : "";
  np("cover").forEach((e) => (e.style.backgroundImage = big));
  np("bgimg").forEach((e) => (e.style.backgroundImage = t.cover ? cssUrl(thumb(t.cover, "m")) : ""));
  const b = $("#src-badge");
  b.hidden = false;
  b.textContent = srcBadge(t, s);
  b.title = srcTip(t, s);
  if (sndOpen()) paintSndQ();
  const tq = document.getElementById("tp-q");
  if (tq && TP.t?.id === t.id) tq.textContent = srcBadge(t, s);
  document.title = t.artist + " — " + t.title + " · Wave";
  const wn = $("#wave-now");
  if (wn && S.wave) wn.textContent = t.artist + " — " + t.title;
  if (t.cover !== S.palCover || t.colors !== S.palColors) {
    S.palCover = t.cover;
    S.palColors = t.colors;
    loadPalette(t.cover, t.colors);
  }
  renderWaveNow();
  if (spDesk() && S.route === "wave") spotifyWaveCurrent();
  if (spDesk() && !$("#queue").hidden) renderQueue();
  refreshLikeButtons();
  renderQList();
  probeLyrics(t);
  if (lyOpen() && LY.id !== t.id) loadLyrics();
  if (TP.open && S.current?.id === t.id && TP.t?.id !== t.id && TP.follow) openTrackPanel(t, { follow: true });
  if ("mediaSession" in navigator) {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: t.title,
      artist: t.artist,
      album: "Wave",
      // the system media overlay only accepts http(s)/data/blob artwork (not covers of own files)
      artwork: /^https:/.test(t.cover || "") ? [{ src: thumb(t.cover, "l"), sizes: "500x500" }] : [],
    });
  }
}
function markRows() {
  $$(".qrow.cur .ov").forEach(
    (o) => (o.innerHTML = audio.paused ? icon("play") : '<span class="eq"><i></i><i></i><i></i></span>'),
  );
  $$(".tr[data-l]").forEach((r) => {
    const t = S.lists[r.dataset.l]?.[+r.dataset.i];
    const cur = !!(t && S.current && t.id === S.current.id);
    const was = r.classList.contains("cur");
    r.classList.toggle("cur", cur);
    if (!cur && !was) return;
    const ov = r.querySelector(".ov");
    if (ov) ov.innerHTML = cur && !audio.paused ? '<span class="eq"><i></i><i></i><i></i></span>' : icon("play");
  });
}
const Q_LIMIT = 120;
function renderQueue() {
  renderQList();
  if ($("#queue").hidden) return;
  if (spDesk()) return renderSpotifyQueue();
  S.lists.q = S.queue;
  const base = Math.max(0, S.index);
  const up = S.queue.slice(base, base + Q_LIMIT);
  const more = S.queue.length - base - up.length;
  $("#queue-list").innerHTML = up.length
    ? `<div class="tracks">${up.map((t, k) => trackRow(t, "q", base + k)).join("")}</div>${more > 0 ? `<div class="q-more">и ещё ${plural(more, "трек", "трека", "треков")}</div>` : ""}`
    : '<div class="empty">Очередь пуста</div>';
}
// over the full-screen player the queue must live outside .app (its own stacking context)
function placeQueue() {
  const q = $("#queue"),
    host = document.body.classList.contains("fp-open") ? document.body : $("#app");
  if (q.parentElement !== host) host.appendChild(q);
}
function toggleQueue() {
  const q = $("#queue");
  placeQueue();
  q.hidden = !q.hidden;
  if (spDesk() && !q.hidden) closeTrackPanel(true);
  $$('[data-cmd="queue"]').forEach((b) => b.id !== "queue-close" && b.classList.toggle("on", !q.hidden));
  renderQueue();
}
function syncModes() {
  pruneWarm();
  prefetchNext();
  $$('[data-cmd="shuffle"]').forEach((b) => b.classList.toggle("on", S.shuffle));
  $$('[data-cmd="repeat"]').forEach((b) => {
    b.classList.toggle("on", S.repeat !== "off");
    b.classList.toggle("one", S.repeat === "one");
  });
}
function setPlayIcons() {
  const p = audio.paused;
  $$('[data-cmd="play"]').forEach((b) => {
    b.innerHTML = icon(p ? "play" : "pause");
    b.title = p ? "Играть" : "Пауза";
  });
  if (typeof mxSyncPlayhead === "function") mxSyncPlayhead();
  $$('[data-cmd="wave-play"]').forEach((b) => {
    b.innerHTML = icon(S.current && !p ? "pause" : "play");
    b.title = S.current && !p ? "Пауза" : "Играть";
  });
  $$('[data-cmd="sp-wave-play"]').forEach(b => { b.innerHTML = icon(S.wave && S.current && !p ? "pause" : "play"); });
  document.body.classList.toggle("paused", p);
  waveRamp();
  const wp = $("#wave-play");
  if (wp) wp.innerHTML = icon(S.wave && !p ? "pause" : "play");
  const wh = $("#wave-hero");
  if (wh) wh.classList.toggle("playing", S.wave && !p);
  waveCut();
  markRows();
  const tp = $("#tpanel .tp-play");
  if (tp && TP.t) {
    const on = S.current?.id === TP.t.id && !p;
    tp.innerHTML = icon(on ? "pause" : "play") + (on ? "Пауза" : "Слушать");
  }
  const trp = $("#trp");
  if (trp && S.route === "track:" + S.current?.id)
    trp.innerHTML = icon(p ? "play" : "pause") + (p ? "Слушать" : "Пауза");
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = p ? "paused" : "playing";
}
function onAudioError(e) {
  if (e && e.target !== audio) return;
  if (hls || !audio.src) return;
  if (manualSeek.id === S.current?.id && Date.now() < manualSeek.until) return onError(new Error("Ошибка перемотки"));
  // CDN without CORS headers: remember the host and replay through a plain <audio> element
  if (audio.hasAttribute("crossorigin")) {
    const src = audio.src;
    noCorsHosts.add(hostOf(src));
    swapAudio(false);
    applyRate(audio);
    audio.src = src;
    audio.play().catch(() => {});
    return;
  }
  onError(new Error("Не удалось воспроизвести поток"));
}
let lastTu = 0,
  progRaf = 0,
  lastPc = -1;
// 4.7: the played part is a full-width bar moved with a GPU transform (sub-pixel, no layout), not a
// width in % (that snaps to whole pixels → visible steps on long tracks); see v47.css
const fillTf = (pc) => `translate3d(${(Math.max(0, Math.min(100, pc)) - 100).toFixed(4)}%,0,0)`;
// 4.15: --pc moves the dot inside the bar at the ends — the clip at the left edge no longer cuts it in half
const setFill = (pc) =>
  np("fill").forEach((e) => {
    e.style.transform = fillTf(pc);
    e.style.setProperty("--pc", Math.max(0, Math.min(100, pc)).toFixed(2));
    const miniBar = e.closest("#seekbar");
    if (miniBar) miniBar.style.setProperty("--pc", Math.max(0, Math.min(100, pc)).toFixed(2));
  });
// currentTime between the decoder's updates: extrapolated by the wall clock (never runs backwards a little)
const PT = { c: -1, at: 0, shown: 0, src: "" };
function smoothTime() {
  const c = audio.currentTime,
    now = performance.now();
  if (audio.paused || audio.seeking || PT.src !== audio.src || c < PT.c - 0.001 || c > PT.c + 2) {
    PT.src = audio.src;
    PT.c = c;
    PT.at = now;
    return (PT.shown = c);
  }
  if (c !== PT.c) {
    PT.c = c;
    PT.at = now;
  }
  let t = PT.c + Math.min(0.3, ((now - PT.at) / 1000) * (audio.playbackRate || 1));
  if (t < PT.shown && PT.shown - t < 0.3) t = PT.shown;
  return (PT.shown = t);
}
// the bars move every frame (smooth like Yandex Music); text and buffer only once per ~second
function paintProgress() {
  if (seekDrag != null) return;
  const d = curDur(),
    c = smoothTime();
  const pc = d ? Math.min(100, (c / d) * 100) : 0;
  if (Math.abs(pc - lastPc) < 0.0005) return;
  lastPc = pc;
  setFill(pc);
  // 4.6: the lighter «played» part of the mini-player ends exactly at the dot of the bar (the bar is inset)
  $("#player").style.setProperty("--pf", (pc / 100).toFixed(5));
  if (typeof mxSyncPlayhead === "function") mxSyncPlayhead();
}
function progLoop() {
  progRaf = 0;
  if (audio.paused || S.bg || !S.current) return;
  paintProgress();
  progRaf = requestAnimationFrame(progLoop);
}
const progStart = () => {
  if (!progRaf && !audio.paused && !S.bg) progRaf = requestAnimationFrame(progLoop);
};
// 4.6: listening time per artist — wall-clock seconds of real playback, sent every ~20 s and on track change
const LT = { t: null, sec: 0, at: 0 };
function countListen(now) {
  const t = S.current;
  if (!t || audio.paused) return void (LT.at = 0);
  if (LT.t?.id !== t.id) {
    flushListen();
    LT.t = t;
  }
  if (LT.at && now - LT.at < 1500) LT.sec += (now - LT.at) / 1000;
  LT.at = now;
  if (LT.sec >= 20) flushListen();
}
function flushListen() {
  const t = LT.t,
    sec = Math.round(LT.sec);
  LT.sec = 0;
  if (!t || sec < 1 || (t.id.startsWith("lf:") && !t.artist)) return;
  api("listen", { track: t, sec }).catch(() => {});
  const list = t.artists?.length
    ? t.artists
    : String(t.artist || "")
        .split(/\s*,\s*/)
        .map((name) => ({ name }));
  S.artistTime ||= [];
  for (const a of list.slice(0, 4)) {
    const k = artKey(a.name);
    if (!k) continue;
    let e = S.artistTime.find((x) => artKey(x.name) === k);
    if (!e) S.artistTime.push((e = { name: a.name, id: a.id || null, sec: 0, cover: t.cover || null }));
    e.sec += sec;
  }
}
addEventListener("beforeunload", flushListen);
function onTimeUpdate() {
  const now = performance.now();
  if (lyOpen() && !S.bg) { lySync(); lyStart(); }
  countListen(now);
  mxTempoStart();
  const remaining = curDur() - audio.currentTime;
  if (
    !S.wave &&
    !S.ctx?.preview &&
    S.current &&
    S.repeat === "off" &&
    S.index === S.queue.length - 1 &&
    remaining > 0 &&
    remaining < 25 &&
    autoWaveJob?.id !== S.current.id
  ) {
    const seed = S.current;
    autoWaveJob = { id: seed.id, job: api("wave", { seed }).catch(() => null) };
  }
  if (seekDrag != null) return;
  xfCheck();
  // 4.9: minimized / hidden — no DOM work (everything is repainted on restore), only the position for the system
  // media controls, every few seconds
  if (S.bg) {
    if (now - lastTu < 5000) return;
    lastTu = now;
    return void mediaPos(curDur(), audio.currentTime);
  }
  if (audio.paused) paintProgress();
  else progStart();
  if (now - lastTu < 900) return;
  lastTu = now;
  const d = curDur(),
    c = audio.currentTime;
  const cs = fmt(c),
    ds = fmt(d);
  np("cur").forEach((e) => e.textContent !== cs && (e.textContent = cs));
  np("dur").forEach((e) => e.textContent !== ds && (e.textContent = ds));
  try {
    if (audio.buffered.length && d) {
      const bw = (audio.buffered.end(audio.buffered.length - 1) / d) * 100 + "%";
      np("buf").forEach((e) => (e.style.width = bw));
    }
  } catch {}
  mediaPos(d, c);
}
function mediaPos(d, c) {
  if ("mediaSession" in navigator && d && isFinite(d))
    try {
      navigator.mediaSession.setPositionState({ duration: d, position: Math.min(c, d), playbackRate: SND.speed });
    } catch {}
}
function bindAudio(el) {
  const on = (type, fn) => el.addEventListener(type, (e) => el === audio && fn(e));
  on("play", () => {
    window.WaveSocial?.audioEvent();
    AX.ctx?.resume().catch(() => {});
    setPlayIcons();
    progStart();
    mixerInit();
  });
  on("pause", () => {
    window.WaveSocial?.audioEvent();
    setPlayIcons();
    paintProgress();
  });
  on("seeked", () => {
    window.WaveSocial?.audioEvent();
    if (manualSeek.id === S.current?.id) manualSeek.until = Date.now() + 1500;
    if (lyOpen()) { lySync(true); lyStart(); }
    lastPc = -1;
    paintProgress();
    lastTu = 0;
    onTimeUpdate();
  });
  // own files: the duration is known only after the browser reads the file
  on("loadedmetadata", () => {
    if (manualSeek.pending && manualSeek.pending.id === S.current?.id) {
      const target = manualSeek.pending.target;
      manualSeek.pending = null;
      try { el.currentTime = Math.min(target, Math.max(0, (Number.isFinite(el.duration) ? el.duration : target + 1) - 0.15)); } catch (_) {}
    }
    const t = S.current;
    if (t && t.id.startsWith("lf:") && !t.duration && isFinite(el.duration) && el.duration > 0) {
      t.duration = Math.round(el.duration);
      api("local-meta", { id: t.id, duration: t.duration }).catch(() => {});
    }
  });
  on("ended", () => {
    if (window.WaveSocial?.follower()) return;
    cancelVersionSwitch();
    const nx = XF.nx;
    if (nx) {
      nx.play?.(); // 4.14: an armed «Микс» track that did not start yet
      return startFade(nx, true); // the next track is still starting: take it over right away
    }
    if (S.repeat === "one") {
      audio.currentTime = 0;
      audio.play();
    } else next(true);
  });
  on("seeking", () => XF.nx && dropPending()); // a jump away from the end cancels a pending crossfade
  on("error", onAudioError);
  on("timeupdate", onTimeUpdate);
  // HLS / file switches reset the rate to defaultPlaybackRate — keep both in sync
  on("loadstart", () => applyRate(el));
}
bindAudio(audio);
// 4.9.1: a track that stops in the middle and waits (the connection broke, the link of the CDN expired, Yandex
// «Моя волна» froze until a manual seek): after 4 s without progress the position is set again (like a manual
// seek), after 10 s the stream is resolved again and continues from the same second
const STALL = { id: null, t: -1, since: 0, step: 0, fixing: false };
function stallCheck() {
  const t = S.current,
    el = audio;
  const now = performance.now();
  const pending = XF.nx && (!XF.nx.mx || XF.nx.going); // 4.14: an armed «Микс» track waits — not a stall
  if (!t || !el || el.paused || el.ended || !el.currentSrc || pending || XF.old || seekDrag != null || STALL.fixing) {
    STALL.since = 0;
    return;
  }
  if (STALL.id !== t.id || !STALL.since || Math.abs(el.currentTime - STALL.t) > 0.05 || el.readyState >= 3) {
    Object.assign(STALL, { id: t.id, t: el.currentTime, since: now, step: 0 });
    return;
  }
  const idle = now - STALL.since;
  if (idle > 4000 && STALL.step === 0) {
    STALL.step = 1;
    console.warn("[wave] stalled at", el.currentTime.toFixed(1), "— nudging");
    try {
      el.currentTime = el.currentTime;
    } catch {}
  } else if (idle > 10000 && STALL.step === 1 && !hls) {
    STALL.step = 2;
    STALL.fixing = true;
    const pos = el.currentTime,
      my = playSeq;
    console.warn("[wave] stalled at", pos.toFixed(1), "— re-opening the stream");
    streamFor(t)
      .then((s) => {
        if (my !== playSeq || S.current !== t || audio.paused || s.type === "hls") return;
        S.stream = { ...S.stream, ...s };
        audio.src = s.url;
        audio.currentTime = pos;
        return audio.play();
      })
      .catch(() => {})
      .finally(() => {
        STALL.fixing = false;
        STALL.since = 0;
      });
  }
}
setInterval(stallCheck, 1000);

/* ---------------- sound panel: speed, pitch, crossfade, equalizer (like «Настройки звука» in Yandex Music) ----------------
   All values live in SND (applied to the audio engine at once) and are saved to the settings 350 ms after the last change. */
const RATE_CHIPS = [0.75, 0.85, 1, 1.15, 1.25, 1.5];
const fmtRate = (v) => String(Math.round(v * 100) / 100).replace(".", ",") + "×";
const xfLbl = (v) => (v > 0 ? v + " с" : "Выкл");
const fmtDb = (v) => (v > 0 ? "+" : "") + String(v).replace(".", ",");
const clampDb = (v) => Math.max(-12, Math.min(12, Math.round((+v || 0) * 2) / 2));
const presetName = (id = SND.eq.preset) =>
  id === "custom" ? "Свой" : (EQ_PRESETS.find((p) => p[0] === id) || EQ_PRESETS[0])[1];
function sndBox() {
  return document.getElementById("sndp");
}
let sndOut = null; // the closing animation of the panel
function sndOpen() {
  const el = sndBox();
  return !!el && !el.hidden && !sndOut;
}
function loadSnd(s = S.settings || {}) {
  SND.speed = Math.max(0.5, Math.min(2, +s.speed || 1));
  SND.pitch = s.keepPitch !== false;
  SND.xf = Number.isFinite(+s.crossfade) && s.crossfade !== null ? Math.max(0, Math.min(12, +s.crossfade)) : 5;
  const e = s.eq || {},
    b10 = (a) => (Array.isArray(a) && a.length === 10 ? a.map(clampDb) : null);
  SND.eq = {
    on: !!e.on,
    preset: e.preset || "flat",
    pre: clampDb(e.pre),
    bands: b10(e.bands) || Array(10).fill(0),
    custom: b10(e.custom),
  };
  liveEls().forEach(applyRate);
  applyEq(true);
  syncSndBtn();
  if (sndOpen()) {
    renderSnd();
    drawCurve();
  }
}
let sndT = 0;
function sndSave() {
  const patch = {
    speed: SND.speed,
    keepPitch: SND.pitch,
    crossfade: SND.xf,
    eq: { ...SND.eq, bands: [...SND.eq.bands], custom: SND.eq.custom && [...SND.eq.custom] },
  };
  Object.assign(S.settings, patch); // other settings saved in the meantime keep these values
  clearTimeout(sndT);
  sndT = setTimeout(
    () =>
      api("settings", patch)
        .then((s) => {
          for (const k of ["speed", "keepPitch", "crossfade", "eq"]) if (k in s) S.settings[k] = s[k];
        })
        .catch(() => {}),
    350,
  );
}
function syncSndBtn() {
  const fast = Math.abs(SND.speed - 1) > 0.001;
  $$('[data-cmd="sound"]').forEach((b) => {
    b.classList.toggle("on", SND.eq.on || fast);
    b.title =
      "Настройки звука" + (fast ? " · скорость " + fmtRate(SND.speed) : "") + (SND.eq.on ? " · " + presetName() : "");
    const r = b.querySelector(".snd-rate");
    if (r) {
      r.hidden = !fast;
      r.textContent = fmtRate(SND.speed);
    }
  });
  const sp = $("#set-speed"),
    eq = $("#set-eq");
  if (sp) sp.textContent = "Сейчас: " + fmtRate(SND.speed) + (root.hasAttribute("data-mobile") ? "" : " · Shift+, и Shift+. — медленнее и быстрее");
  if (eq) eq.textContent = SND.eq.on ? "Включён: " + presetName() : "Выключен";
}
function setSpeed(v, say) {
  if (window.WaveSocial?.follower()) { toast("Скорость задаёт ведущий комнаты"); return; }
  SND.speed = Math.max(0.5, Math.min(2, Math.round(v * 100) / 100));
  liveEls().forEach(applyRate);
  syncSndBtn();
  if (sndOpen()) paintSpeed();
  if (say) toast("Скорость " + fmtRate(SND.speed), 1600);
  sndSave();
}
function setPreset(id) {
  const e = SND.eq;
  if (id === "custom") {
    if (!e.custom) e.custom = [...e.bands];
    e.bands = [...e.custom];
  } else e.bands = [...(EQ_PRESETS.find((p) => p[0] === id) || EQ_PRESETS[0])[2]];
  e.preset = id;
  if (id !== "flat") e.on = true;
  applyEq();
  if (sndOpen()) paintEq();
  syncSndBtn();
  sndSave();
}
let sndAnchor = null;
function openSound(anchor) {
  if (sndOpen()) return closeSound();
  if (sndOut) {
    sndOut.cancel();
    sndOut = null;
    $$('[data-cmd="sound"]').forEach((b) => b.classList.add("open"));
    return;
  }
  let el = sndBox();
  if (!el) {
    el = document.createElement("div");
    el.id = "sndp";
    el.className = "sndp";
    el.hidden = true;
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-label", "Настройки звука");
    document.body.appendChild(el);
    bindSnd(el);
  }
  const vis = (b) => b && b.getClientRects().length && b.getBoundingClientRect().width > 0;
  // the mini-player is covered by the full-screen player: then the panel opens in the middle
  sndAnchor = vis(anchor) ? anchor : fpEl().hidden && vis($("#snd-btn")) ? $("#snd-btn") : null;
  renderSnd();
  el.hidden = false;
  placeSnd();
  drawCurve();
  $$('[data-cmd="sound"]').forEach((b) => b.classList.add("open"));
}
function closeSound(instant) {
  const el = sndBox();
  if (!el || el.hidden || sndOut) return;
  $$('[data-cmd="sound"]').forEach((b) => b.classList.remove("open"));
  if (instant === true || S.settings?.animation === false) {
    el.hidden = true;
    return;
  }
  // fades out the way it came in (a little down)
  sndOut = el.animate(
    [
      { opacity: 1, transform: "none" },
      { opacity: 0, transform: "translateY(8px) scale(0.985)" },
    ],
    { duration: 170, easing: "cubic-bezier(.4,0,1,1)" },
  );
  sndOut.onfinish = () => {
    sndOut = null;
    el.hidden = true;
  };
}
function placeSnd() {
  const el = sndBox();
  if (!el || el.hidden) return;
  const st = el.style;
  st.top = st.bottom = "";
  st.maxHeight = innerHeight - 32 + "px";
  const w = el.offsetWidth,
    a = sndAnchor?.isConnected && sndAnchor.getClientRects().length ? sndAnchor.getBoundingClientRect() : null;
  if (!a) {
    st.left = Math.max(8, (innerWidth - w) / 2) + "px";
    st.top = Math.max(16, (innerHeight - el.offsetHeight) / 2) + "px";
    return;
  }
  st.left = Math.max(8, Math.min(innerWidth - w - 8, a.right - w + 4)) + "px";
  if (a.top > innerHeight / 2) {
    st.bottom = innerHeight - a.top + 10 + "px";
    st.maxHeight = Math.max(180, a.top - 26) + "px";
  } else {
    st.top = a.bottom + 8 + "px";
    st.maxHeight = Math.max(180, innerHeight - a.bottom - 24) + "px";
  }
}
const eqCol = (i, l) =>
  `<div class="eqs${i < 0 ? " pre" : ""}" data-band="${i}" tabindex="0" role="slider" aria-label="${i < 0 ? "Уровень" : l + " Гц"}" aria-valuemin="-12" aria-valuemax="12"><span class="eqs-v"></span><div class="eqs-t"><i class="eqs-f"></i><i class="eqs-k"></i></div><span class="eqs-l">${l}</span></div>`;
function renderSnd() {
  const el = sndBox();
  if (!el) return;
  el.innerHTML = `<div class="sndp-h"><b>Настройки звука</b><button class="icon-btn" data-snd="close" title="Закрыть">${icon("close")}</button></div>
  <section class="sndp-sec sndp-q" id="snd-q"></section>
  <section class="sndp-sec">
    <div class="sndp-row"><span class="sndp-l">Скорость</span><b class="sndp-v" id="snd-sv"></b></div>
    <input type="range" class="sndp-range" id="snd-speed" min="0.5" max="2" step="0.05" aria-label="Скорость">
    <div class="sndp-chips">${RATE_CHIPS.map((v) => `<button class="sndp-chip" data-rate="${v}">${fmtRate(v)}</button>`).join("")}</div>
    <div class="sndp-row"><span class="sndp-l">Сохранять тон<small>Если выключить — эффект slowed / sped up: голос станет ниже или выше</small></span><button class="switch" data-snd="pitch" aria-label="Сохранять тон"></button></div>
  </section>
  <section class="sndp-sec">
    <div class="sndp-row"><span class="sndp-l">Плавный переход<small>Следующий трек вступает, пока текущий затихает</small></span><b class="sndp-v" id="snd-xv"></b></div>
    <input type="range" class="sndp-range" id="snd-xf" min="0" max="12" step="1" aria-label="Плавный переход, секунды">
  </section>
  <section class="sndp-sec sndp-eqs">
    <div class="sndp-row"><span class="sndp-l">Эквалайзер</span><button class="sndp-preset" data-snd="preset" title="Пресет"><span id="snd-pn"></span>${icon("down")}</button><button class="switch" data-snd="eq" aria-label="Эквалайзер"></button></div>
    <div class="eqw" id="snd-eq">
      <div class="eq-scale"><span>12 dB</span><span>0 dB</span><span>-12 dB</span></div>
      ${eqCol(-1, "уровень")}
      <div class="eq-bands"><svg class="eq-curve" aria-hidden="true"><path class="eq-area"/><path class="eq-line"/></svg>${EQ_LBL.map((l, i) => eqCol(i, l)).join("")}</div>
    </div>
    <p class="sndp-note" id="snd-note" hidden></p>
    <div class="sndp-foot"><small>${root.hasAttribute("data-mobile") ? "Двойное нажатие — сброс полосы" : "Колёсико — по 0,5 dB, двойной клик — 0"}</small><button class="btn sm ghost" data-snd="reset">Сбросить</button></div>
  </section>`;
  paintSnd();
}
// 4.6: what is playing and in which quality («SoundCloud · AAC 160», «▶ Audius · MP3 320 · лучшая копия»)
function paintSndQ() {
  const box = document.getElementById("snd-q");
  if (!box) return;
  const t = S.current,
    s2 = S.stream;
  box.hidden = !t;
  if (!t) return;
  const q = s2?.q?.kbps ? `${s2.q.codec || ""} ${s2.q.kbps} кбит/с`.trim() : s2?.local ? "Свой файл" : s2 ? "—" : "…";
  // where the sound comes from; the bitrate itself is on the right
  const why = s2?.local
    ? (root.hasAttribute("data-mobile") ? "Файл с этого телефона" : "Файл с этого компьютера")
    : s2 && (s2.hq || s2.drm || (s2.matched && s2.via))
      ? srcTip(t, s2)
      : srcBadge(t, s2).split(" · ")[0] + (s2?.preview ? " · превью 30 сек" : s2 ? " · полная версия" : "");
  box.innerHTML = `<div class="sndp-row"><span class="sndp-l">Качество<small>${esc(why)}</small></span><b class="sndp-v">${esc(q)}</b></div>`;
}
function paintSnd() {
  const el = sndBox();
  if (!el) return;
  paintSndQ();
  paintSpeed();
  el.querySelector("#snd-xf").value = SND.xf;
  el.querySelector("#snd-xf").style.setProperty("--p", (SND.xf / 12) * 100 + "%");
  el.querySelector("#snd-xv").textContent = xfLbl(SND.xf);
  el.querySelector('[data-snd="pitch"]').classList.toggle("on", SND.pitch);
  paintEq();
}
function paintSpeed() {
  const el = sndBox(),
    r = el?.querySelector("#snd-speed");
  if (!r) return;
  r.value = SND.speed;
  r.style.setProperty("--p", ((SND.speed - 0.5) / 1.5) * 100 + "%");
  el.querySelector("#snd-sv").textContent = fmtRate(SND.speed);
  el.querySelectorAll("[data-rate]").forEach((b) =>
    b.classList.toggle("on", Math.abs(+b.dataset.rate - SND.speed) < 0.001),
  );
}
const bandVal = (c) => (+c.dataset.band < 0 ? SND.eq.pre : SND.eq.bands[+c.dataset.band]);
function paintEq() {
  const el = sndBox();
  if (!el?.querySelector("#snd-eq")) return;
  const e = SND.eq;
  el.querySelector('[data-snd="eq"]').classList.toggle("on", e.on);
  el.querySelector("#snd-pn").textContent = presetName();
  el.querySelector("#snd-eq").classList.toggle("off", !e.on);
  el.querySelectorAll(".eqs").forEach((c) => {
    const v = bandVal(c),
      p = (v + 12) / 24;
    c.style.setProperty("--p", p);
    c.style.setProperty("--lo", Math.min(p, 0.5));
    c.style.setProperty("--len", Math.abs(p - 0.5));
    c.querySelector(".eqs-v").textContent = fmtDb(v);
    c.setAttribute("aria-valuenow", v);
    c.setAttribute("aria-valuetext", fmtDb(v) + " dB");
  });
  drawCurve();
  sndNote();
}
// smooth line through the band knobs (Catmull-Rom → Bézier)
function drawCurve() {
  const box = sndBox()?.querySelector(".eq-bands"),
    svg = box?.querySelector("svg");
  if (!svg || !box.offsetWidth) return;
  const br = box.getBoundingClientRect(),
    tr = [...box.querySelectorAll(".eqs-t")].map((t) => t.getBoundingClientRect());
  const pts = tr.map((r, i) => [
    r.left - br.left + r.width / 2,
    r.top - br.top + (1 - (SND.eq.bands[i] + 12) / 24) * r.height,
  ]);
  const f = (n) => n.toFixed(1);
  let d = `M${f(pts[0][0])},${f(pts[0][1])}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i],
      p1 = pts[i],
      p2 = pts[i + 1],
      p3 = pts[i + 2] || p2;
    d += `C${f(p1[0] + (p2[0] - p0[0]) / 6)},${f(p1[1] + (p2[1] - p0[1]) / 6)} ${f(p2[0] - (p3[0] - p1[0]) / 6)},${f(p2[1] - (p3[1] - p1[1]) / 6)} ${f(p2[0])},${f(p2[1])}`;
  }
  const mid = tr[0].top - br.top + tr[0].height / 2;
  svg.setAttribute("viewBox", `0 0 ${f(br.width)} ${f(br.height)}`);
  svg.querySelector(".eq-line").setAttribute("d", d);
  svg.querySelector(".eq-area").setAttribute("d", `${d}L${f(pts.at(-1)[0])},${f(mid)}L${f(pts[0][0])},${f(mid)}Z`);
}
// the equalizer works only for elements that go through Web Audio (CORS-enabled hosts and own files)
function sndNote() {
  const n = sndBox()?.querySelector("#snd-note");
  if (!n) return;
  const bad = !!S.current && (AX.failed || !AX.ok);
  n.hidden = !bad;
  n.textContent = AX.failed
    ? "Обработка звука недоступна в этой системе — эквалайзер не работает. Скорость и плавный переход работают"
    : "Сервер этого трека не разрешает обработку звука — эквалайзер и усиление громкости к нему не применяются. Скорость и плавный переход работают";
}
function setBand(c, v) {
  v = clampDb(v);
  const i = +c.dataset.band,
    e = SND.eq;
  if (bandVal(c) === v && e.on) return;
  if (i < 0) e.pre = v;
  else {
    e.bands[i] = v;
    e.preset = "custom";
    e.custom = [...e.bands];
  }
  e.on = true;
  applyEq();
  paintEq();
  syncSndBtn();
  sndSave();
}
function presetMenu(ev) {
  const cur = SND.eq.preset;
  const items = EQ_PRESETS.map(([id, name]) => [name, id === cur ? "check" : "blank", () => setPreset(id)]);
  items.push("-", [
    SND.eq.custom ? "Свой" : "Свой (двигайте ползунки)",
    cur === "custom" ? "check" : "blank",
    () => setPreset("custom"),
  ]);
  menu(ev, items);
  const m = $("#menu");
  m.classList.add("menu-eq");
  const r = m.getBoundingClientRect();
  if (r.bottom > innerHeight - 8) m.style.top = Math.max(8, innerHeight - 8 - r.height) + "px";
  if (r.right > innerWidth - 8) m.style.left = Math.max(8, innerWidth - 8 - r.width) + "px";
}
function bindSnd(el) {
  el.addEventListener("click", (e) => {
    const b = e.target.closest("[data-snd],[data-rate]");
    if (!b) return;
    if (b.dataset.rate) return setSpeed(+b.dataset.rate);
    const k = b.dataset.snd;
    if (k === "close") closeSound();
    else if (k === "pitch") {
      SND.pitch = !SND.pitch;
      liveEls().forEach(applyRate);
      paintSnd();
      sndSave();
      if (S.route === "settings") $('[data-sw="keepPitch"]')?.classList.toggle("on", SND.pitch);
    } else if (k === "eq") {
      SND.eq.on = !SND.eq.on;
      applyEq();
      paintEq();
      syncSndBtn();
      sndSave();
    } else if (k === "preset") presetMenu(e);
    else if (k === "reset") {
      Object.assign(SND.eq, { preset: "flat", pre: 0, bands: Array(10).fill(0) });
      applyEq();
      paintEq();
      syncSndBtn();
      sndSave();
    }
  });
  el.addEventListener("input", (e) => {
    if (e.target.id === "snd-speed") setSpeed(+e.target.value);
    else if (e.target.id === "snd-xf") {
      SND.xf = +e.target.value;
      e.target.style.setProperty("--p", (SND.xf / 12) * 100 + "%");
      el.querySelector("#snd-xv").textContent = xfLbl(SND.xf);
      const s = $("#xf");
      if (s) {
        s.value = SND.xf;
        $("#xf-v").textContent = xfLbl(SND.xf);
      }
      sndSave();
    }
  });
  // equalizer sliders: drag, wheel, double click → 0 dB, arrow keys
  let drag = null;
  const valAt = (c, y) => {
    const r = c.querySelector(".eqs-t").getBoundingClientRect();
    return clampDb(12 - ((y - r.top) / r.height) * 24);
  };
  // 4.20.1: on a phone a finger that lands on a band column while scrolling the panel no longer moves it: a drag
  // starts only from the knob itself; elsewhere the touch scrolls, and a plain tap (no movement) still sets the band
  let pend = null;
  const knobNear = (c, y) => {
    const r = c.querySelector(".eqs-t").getBoundingClientRect();
    const ky = r.top + ((12 - bandVal(c)) / 24) * r.height;
    return Math.abs(y - ky) <= 26;
  };
  el.addEventListener("pointerdown", (e) => {
    const c = e.target.closest(".eqs-t")?.closest(".eqs");
    if (!c || e.button !== 0) return;
    if (e.pointerType === "touch" && root.hasAttribute("data-mobile") && !knobNear(c, e.clientY)) {
      pend = { c, x: e.clientX, y: e.clientY, at: Date.now() };
      return;
    }
    pend = null;
    e.preventDefault();
    c.focus({ preventScroll: true });
    drag = c;
    try {
      c.setPointerCapture(e.pointerId);
    } catch {}
    c.classList.add("drag");
    setBand(c, valAt(c, e.clientY));
  });
  el.addEventListener("pointermove", (e) => {
    if (pend && Math.hypot(e.clientX - pend.x, e.clientY - pend.y) > 8) pend = null;
    if (drag) setBand(drag, valAt(drag, e.clientY));
  });
  // while a knob is dragged the panel must not scroll under the finger
  el.addEventListener("touchmove", (e) => { if (drag && e.cancelable) e.preventDefault(); }, { passive: false });
  const end = (e) => {
    if (pend && e?.type === "pointerup" && Date.now() - pend.at < 450) setBand(pend.c, valAt(pend.c, pend.y));
    pend = null;
    drag?.classList.remove("drag");
    drag = null;
  };
  el.addEventListener("pointerup", end);
  el.addEventListener("pointercancel", end);
  el.addEventListener("dblclick", (e) => {
    const c = e.target.closest(".eqs");
    if (c) setBand(c, 0);
  });
  el.addEventListener(
    "wheel",
    (e) => {
      const c = e.target.closest(".eqs");
      if (!c) return;
      e.preventDefault();
      e.stopPropagation();
      setBand(c, bandVal(c) - Math.sign(e.deltaY) * 0.5);
    },
    { passive: false },
  );
  el.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.stopPropagation();
      if (!$("#menu").hidden) $("#menu").hidden = true;
      else closeSound();
      return;
    }
    const c = e.target.closest?.(".eqs");
    const d = { ArrowUp: 0.5, ArrowRight: 0.5, ArrowDown: -0.5, ArrowLeft: -0.5, PageUp: 3, PageDown: -3 }[e.key];
    if (c && (d || ["Home", "End", "0", "Delete", "Backspace"].includes(e.key))) {
      e.preventDefault();
      e.stopPropagation();
      setBand(c, d ? bandVal(c) + d : e.key === "Home" ? 12 : e.key === "End" ? -12 : 0);
    } else if (e.key.startsWith("Arrow")) e.stopPropagation(); // no seeking / volume while the panel has focus
  });
}
document.addEventListener(
  "pointerdown",
  (e) => {
    if (sndOpen() && !e.target.closest("#sndp,#menu,#dialog,[data-cmd='sound'],[data-snd-open]")) closeSound();
  },
  true,
);
addEventListener("resize", () => {
  if (!sndOpen()) return;
  placeSnd();
  drawCurve();
});

/* ---------------- full-screen player: open/close animation ---------------- */
const FP_VAR = { cover: ".fpa", nowplaying: ".fpb", classic: ".fpc" };
const fpEl = () => $("#fullplayer");
const fpArt = () => fpEl().querySelector((FP_VAR[fpEl().dataset.variant] || ".fpa") + " .fp-art");
function fpSourceRect() {
  for (const el of [$("#wv-cover"), $("#pl-cover")]) {
    if (!el) continue;
    const r = el.getBoundingClientRect();
    if (r.width > 8 && r.height > 8 && r.bottom > 0 && r.top < innerHeight) return r;
  }
  return null;
}
const flipTo = (a, b) => {
  // transform that moves box b onto box a
  const s = a.width / b.width;
  return `translate(${a.left + a.width / 2 - (b.left + b.width / 2)}px, ${a.top + a.height / 2 - (b.top + b.height / 2)}px) scale(${s})`;
};
// opens sliding up from the bottom edge with a fade from slight transparency (Yandex Music style)
const FP_EASE = "cubic-bezier(.2,.8,.2,1)";
function openFull(opt = {}) {
  if (!S.current) return toast("Сначала включите трек или Мою волну", 2200);
  if (lyOpen()) toggleLyrics(false, { back: false });
  const fp = fpEl();
  if (!fp.hidden && !fp._closing) return opt.queue && setQueueMode(true);
  fp.getAnimations().forEach((a) => a.cancel());
  fp._closing = false;
  setQueueMode(!!opt.queue && isGlass(), { instant: true });
  fp.hidden = false;
  document.body.classList.add("fp-open");
  placeQueue();
  WaveFx.setPaused(true);
  if (S.settings?.animation === false || matchMedia("(prefers-reduced-motion: reduce)").matches || opt.instant) return;
  // 4.6: a short rise with a fade instead of sliding the whole screen up (faster, like Yandex Music)
  fp.animate(
    [
      { transform: "translateY(18%)", opacity: 0 },
      { transform: "none", opacity: 1 },
    ],
    { duration: 320, easing: FP_EASE },
  );
  if (fp.classList.contains("q"))
    $("#fpq").animate(
      [
        { opacity: 0, transform: "translateX(-120px)" },
        { opacity: 1, transform: "none" },
      ],
      { duration: 480, delay: 160, easing: FP_EASE, fill: "backwards" },
    );
}
function closeFull(instant) {
  const fp = fpEl();
  if (fp.hidden || fp._closing) return;
  const done = () => {
    fp.hidden = true;
    fp._closing = false;
    fp.getAnimations().forEach((a) => a.cancel());
    setQueueMode(false, { instant: true });
    document.body.classList.remove("fp-open");
    placeQueue();
    if (!lyOpen()) WaveFx.setPaused(false);
  };
  if (instant === true || S.settings?.animation === false || matchMedia("(prefers-reduced-motion: reduce)").matches) return done();
  fp._closing = true;
  document.body.classList.remove("fp-open");
  fp.animate(
    [
      { transform: "none", opacity: 1 },
      { transform: "translateY(14%)", opacity: 0 },
    ],
    { duration: 240, easing: "cubic-bezier(.4,0,1,1)", fill: "forwards" },
  )
    .finished.catch(() => {})
    .then(() => fp._closing && done());
}

/* ---------------- 4.9: View Transitions — one morph between the full player, the lyrics and pages ---------------- */
// Native View Transitions snapshot animated mobile WebViews inconsistently; use the regular
// player/page transitions there instead, and always respect reduced motion.
const vtOk = () => !root.hasAttribute("data-mobile") && typeof document.startViewTransition === "function" && S.settings?.animation !== false && !S.bg && !matchMedia("(prefers-reduced-motion: reduce)").matches;
const shown = (el) => {
  if (!el || !el.isConnected) return null;
  const r = el.getBoundingClientRect();
  return r.width > 8 && r.height > 8 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth
    ? el
    : null;
};
const plArt = () => shown($("#pl-cover"));
const heroArt = () => shown($("#content .gh-cover, #content .hero .hc"));
let vtCur = null;
// update() changes the DOM; from/to return the element that «flies» (the cover) before and after the change
function morph(update, { kind = "leave", from, to } = {}) {
  if (!vtOk()) return void update();
  try {
    vtCur?.skipTransition();
  } catch {}
  const root = document.documentElement;
  const a = shown(from?.());
  let b = null;
  if (a) a.style.viewTransitionName = "wv-art";
  root.classList.add("vt-" + kind);
  let t;
  try {
    t = document.startViewTransition(() => {
      if (a) a.style.viewTransitionName = "";
      update();
      b = a ? shown(to?.()) : null;
      if (b) b.style.viewTransitionName = "wv-art";
    });
  } catch {
    if (a) a.style.viewTransitionName = "";
    root.classList.remove("vt-" + kind);
    return void update();
  }
  vtCur = t;
  t.finished
    .catch(() => {})
    .then(() => {
      root.classList.remove("vt-" + kind);
      if (b) b.style.viewTransitionName = "";
      if (vtCur === t) vtCur = null;
    });
}
// leaving the full player / the lyrics for a page (a title, an artist, a link): a smooth transition, the cover
// flies to the page cover or to the mini player instead of everything disappearing at once
function leaveTo(fn, { to } = {}) {
  const run = () => {
    LY.fromFull = false;
    closeFull(true);
    toggleLyrics(false, { back: false });
    fn();
  };
  const fp = fpEl();
  if ((fp.hidden || fp._closing) && !lyOpen()) {
    if (S.route === "wave" && isGlass()) {
      return morph(
        () => {
          setContent(skel(8));
          run();
        },
        { kind: "ly", from: () => $("#wv-cover"), to: plArt },
      );
    }
    return run();
  }
  morph(run, { kind: "leave", from: () => (lyOpen() ? $(".ly-cover") : fpArt()), to: to || plArt });
}

/* ---------------- queue view (new interface): the cover moves left, the queue slides out from behind it ---------------- */
const fpQ = () => fpEl().classList.contains("q");
function toggleQueueView() {
  const fp = fpEl();
  if (fp.hidden || fp._closing) return openFull({ queue: true });
  setQueueMode(!fpQ());
}
function setQueueMode(on, { instant = false } = {}) {
  const fp = fpEl();
  if (on === fpQ()) {
    if (on) renderQList(true);
    return;
  }
  const center = fp.querySelector(".fpa-center");
  const before = !instant && !fp.hidden ? center.getBoundingClientRect() : null;
  fp.classList.toggle("q", on);
  $$('[data-cmd="queue"]').forEach((b) => b.id !== "queue-close" && b.classList.toggle("on", on));
  if (on) renderQList(true);
  if (root.hasAttribute("data-mobile")) {
    const queue = $("#fpq");
    queue.getAnimations().forEach((a) => a.cancel());
    if (on && before && S.settings?.animation !== false && !matchMedia("(prefers-reduced-motion: reduce)").matches)
      queue.animate([{opacity:0},{opacity:1}], {duration:180,easing:"ease-out"});
    return;
  }
  if (!before || S.settings?.animation === false || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const after = center.getBoundingClientRect();
  center.animate(
    [{ transform: `translate(${before.left - after.left}px, ${before.top - after.top}px)` }, { transform: "none" }],
    { duration: 540, easing: FP_EASE },
  );
  if (on)
    $("#fpq").animate(
      [
        { opacity: 0, transform: "translateX(-140px)" },
        { opacity: 1, transform: "none" },
      ],
      { duration: 560, delay: 80, easing: FP_EASE, fill: "backwards" },
    );
}
const qRow = (t, i, cls = "") => {
  const [m, v] = splitTitle(t.title);
  const liked = S.likeSet.has(t.id);
  const cur = cls.includes("cur");
  return `<div class="qrow ${cls}" data-l="q" data-i="${i}"><div class="qc" ${bg(t.cover, "s")}>${t.cover ? "" : icon("note")}<span class="ov">${cur ? (audio.paused ? icon("play") : '<span class="eq"><i></i><i></i><i></i></span>') : icon("play")}</span></div><div class="qm"><div class="qt"><b>${esc(m)}</b>${v ? ` <span class="tv">${esc(v)}</span>` : ""}</div><div class="qa">${artistsHtml(t)}</div></div><button class="icon-btn lk${liked ? " on" : ""}" data-act="like" title="Нравится">${icon(liked ? "heart" : "heart-o")}</button><span class="d">${t.duration ? fmt(t.duration) : ""}</span></div>`;
};
function renderQList(scroll) {
  const box = $("#fpq-list");
  if (!box || !fpQ()) return;
  S.lists.q = S.queue;
  const i = Math.max(0, S.index);
  const from = Math.max(0, i - 30);
  const prev = S.queue.slice(from, i).map((t, k) => qRow(t, from + k, "past"));
  const cur = S.queue[i];
  const up = S.queue.slice(i + 1, i + 1 + Q_LIMIT).map((t, k) => qRow(t, i + 1 + k));
  const ctx = S.wave ? "Моя волна" : S.ctx?.title || "Очередь";
  box.innerHTML = cur
    ? `${prev.join("")}<div class="fpq-h" id="fpq-now"><small>Сейчас играет ${S.wave ? "" : "из плейлиста"}</small><b>${esc(ctx)}</b></div>${qRow(cur, i, "cur")}${up.length ? `<div class="fpq-h"><b>Далее в очереди</b></div>${up.join("")}` : '<div class="fpq-empty">Дальше пусто</div>'}`
    : '<div class="fpq-empty">Очередь пуста</div>';
  // keep the playing track in view when the track changes (but don't fight the user's own scrolling otherwise)
  const changed = box._cid !== cur?.id;
  box._cid = cur?.id;
  if (scroll || changed) {
    const h = $("#fpq-now");
    if (h)
      box.scrollTo({ top: Math.max(0, h.offsetTop - 70), behavior: scroll || !box.isConnected ? "auto" : "smooth" });
  }
}

/* ---------------- lyrics (Yandex Music with the user's token → LRCLib), karaoke-style ---------------- */
const LY = { cache: new Map(), id: null, data: null, lines: null, idx: -2, raf: 0, seq: 0, userY: 0, userT: 0 };
const lyOpen = () => !$("#lyrics").hidden;
// the karaoke loop runs only while the lyrics are open and the window is visible
function lyLoop() {
  LY.raf = 0;
  if (!lyOpen() || S.bg) return;
  lySync();
  LY.raf = requestAnimationFrame(lyLoop);
}
const lyStart = () => {
  if (!LY.raf && lyOpen() && !S.bg) LY.raf = requestAnimationFrame(lyLoop);
};
function toggleLyrics(force, o = {}) {
  const el = $("#lyrics");
  const open = typeof force === "boolean" ? force : el.hidden;
  if (open === !el.hidden) return;
  if (open) {
    if (!S.current) return toast("Сначала включите трек", 2000);
    // 4.9: opened from the full player → closing the lyrics returns there (the cover morphs between the two)
    const fp = fpEl();
    const fromFull = !fp.hidden && !fp._closing;
    LY.fromFull = fromFull;
    const show = () => {
      closeFull(true);
      el.hidden = false;
      document.body.classList.add("ly-open");
      WaveFx.setPaused(true);
    };
    if (fromFull && vtOk()) morph(show, { kind: "ly", from: fpArt, to: () => $(".ly-cover") });
    else {
      show();
      if (S.settings?.animation !== false && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
        el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 280, easing: "ease-out" });
        el.querySelector(".ly-body").animate(
          [
            { opacity: 0, transform: "translateY(24px)" },
            { opacity: 1, transform: "none" },
          ],
          { duration: 420, easing: "cubic-bezier(.2,.8,.2,1)" },
        );
      }
    }
    loadLyrics();
    lyStart();
  } else {
    const back = (LY.fromFull || !!o.toFull) && o.back !== false && !!S.current;
    LY.fromFull = false;
    const hide = () => {
      el.hidden = true;
      document.body.classList.remove("ly-open");
      cancelAnimationFrame(LY.raf);
      LY.raf = 0;
      if (back) openFull({ instant: true });
      else if (!document.body.classList.contains("fp-open")) WaveFx.setPaused(false);
    };
    if (back && vtOk()) morph(hide, { kind: "ly", from: () => $(".ly-cover"), to: fpArt });
    else hide();
  }
  $$('[data-cmd="lyrics"]').forEach((b) => b.classList.toggle("on", open));
}
const lySearched = () =>
  "Искали в " +
  ["LRCLib", S.settings?.genius !== false && "Genius", S.settings?.ymToken && "Яндекс Музыке"]
    .filter(Boolean)
    .join(", ")
    .replace(/, ([^,]+)$/, " и $1");
// 4.6: the lyrics buttons are dimmed when the playing track has no text (checked shortly after it starts)
const lyNone = (d) => !!d && !d.error && (d.instrumental || !d.lines?.length);
let lyProbe = { id: null, t: 0 };
function probeLyrics(t) {
  if (!t || lyProbe.id === t.id) return;
  lyProbe.id = t.id;
  clearTimeout(lyProbe.t);
  const d = LY.cache.get(t.id);
  markLyBtns(d);
  if (d) return;
  lyProbe.t = setTimeout(() => {
    if (S.current?.id !== t.id) return;
    lyricsCache(t)
      .then((x) => S.current?.id === t.id && markLyBtns(x))
      .catch(() => {});
  }, 1400);
}
function markLyBtns(d) {
  const none = lyNone(d);
  $$('[data-cmd="lyrics"]:not(.ly-close)').forEach((b) => {
    b.classList.toggle("no-ly", none);
    b.title = none ? (d.instrumental ? "Инструментальная композиция — без слов" : "Текста нет") : "Текст песни";
  });
}
async function loadLyrics() {
  const t = S.current;
  if (!t) return;
  if (LY.id === t.id && LY.data) return renderLyrics();
  LY.id = t.id;
  LY.data = null;
  LY.lines = null;
  const my = ++LY.seq;
  $("#ly-lines").style.transform = "";
  $("#ly-lines").innerHTML = '<div class="ly-empty"><span class="ly-spin"></span><b>Ищу текст песни…</b></div>';
  $("#ly-src").textContent = "";
  let d = LY.cache.get(t.id);
  if (!d) {
    try {
      const via = S.stream?.via && S.stream.via.id !== t.id ? S.stream.via : null;
      d = await api("lyrics", { track: t, via });
      LY.cache.set(t.id, d);
      if (LY.cache.size > 80) LY.cache.delete(LY.cache.keys().next().value);
    } catch (e) {
      d = { lines: [], error: e.message };
    }
  }
  if (my !== LY.seq || S.current?.id !== t.id) return;
  LY.data = d;
  markLyBtns(d);
  renderLyrics();
}
// empty LRC lines and a long intro become «• • • •» like in Yandex Music
function withGaps(lines) {
  const out = [];
  if (lines.length && lines[0].t > 5) out.push({ t: 0, gap: true });
  for (const l of lines) out.push(l.text ? l : { t: l.t, gap: true });
  return out;
}
function renderLyrics() {
  const d = LY.data,
    box = $("#ly-lines"),
    src = $("#ly-src");
  const synced = !!(d && d.synced);
  $("#ly-text").classList.toggle("plain", !synced);
  LY.idx = -2;
  LY.userY = 0;
  box.style.transform = "";
  if (!d || d.error || d.instrumental || !d.lines?.length) {
    LY.lines = null;
    box.innerHTML = d?.instrumental
      ? '<div class="ly-empty"><b>Инструментальная композиция</b><span>В этом треке нет слов — просто слушайте</span></div>'
      : `<div class="ly-empty"><b>${d?.error ? "Не удалось загрузить текст" : "Текст не найден"}</b><span>${esc(
          d?.error ||
            lySearched() + (S.settings.ymToken ? "" : ". С токеном Яндекс Музыки (Настройки) текстов будет больше"),
        )}</span></div>`;
    src.textContent = "";
    return;
  }
  LY.lines = synced ? withGaps(d.lines) : d.lines;
  box.innerHTML = LY.lines
    .map((l, i) =>
      l.gap
        ? `<div class="ly-l gap" data-i="${i}"><i></i><i></i><i></i><i></i></div>`
        : `<div class="ly-l" data-i="${i}"><span class="ly-words">${esc(l.text) || "&nbsp;"}</span></div>`,
    )
    .join("");
  src.innerHTML =
    "Текст: " +
    (d.link ? `<a data-ext="${esc(d.link)}">${esc(d.source)}</a>` : esc(d.source)) +
    (synced ? "" : " · без синхронизации");
  lySync(true);
}
function lySync(force) {
  if (!LY.lines || !LY.data?.synced) return;
  const now = audio.currentTime + 0.25;
  let i = -1;
  for (let k = 0; k < LY.lines.length; k++)
    if (LY.lines[k].t <= now) i = k;
    else break;
  const box = $("#ly-lines"),
    host = $("#ly-text");
  if (LY.userY && performance.now() - LY.userT > 3500) {
    LY.userY = 0;
    force = true;
  }
  if (i === LY.idx && !force) return;
  LY.idx = i;
  const kids = box.children;
  for (let k = 0; k < kids.length; k++) {
    const el = kids[k];
    el.classList.toggle("on", k === i);
    el.classList.toggle("past", k < i);
    // the next lines fade out step by step (PulseSync / Яндекс style)
    const d = k > i ? String(Math.min(5, k - i)) : "";
    if (el.dataset.d !== d) el.dataset.d = d;
  }
  host.classList.toggle("browse", !!LY.userY);
  const cur = kids[Math.max(0, i)];
  const y = cur ? cur.offsetTop + cur.offsetHeight / 2 - host.clientHeight * 0.42 : 0;
  box.style.transform = `translateY(${Math.round(-Math.max(0, y) - LY.userY)}px)`;
}
$("#ly-lines").addEventListener("click", (e) => {
  const words = e.target.closest(".ly-words");
  const l = words?.closest(".ly-l");
  if (!l || !LY.lines || !LY.data?.synced || Date.now() < lyDragUntil) return;
  const t = LY.lines[+l.dataset.i]?.t;
  if (t != null && isFinite(t)) {
    audio.currentTime = Math.max(0, t - 0.05);
    LY.userY = 0;
    if (audio.paused) audio.play().catch(() => {});
  }
});
/* 4.20.1: the synced lyrics follow the finger 1:1 (the eased «follow the line» transition is off while dragging —
   it made the text lag behind and «stick») and keep sliding after the release, like any list on the phone */
let lyTouch = null, lyDragUntil = 0, lyFling = 0;
const lyClamp = (v) => Math.max(-$("#ly-text").clientHeight, Math.min($("#ly-lines").scrollHeight, v));
const lyStopFling = () => { cancelAnimationFrame(lyFling); lyFling = 0; };
$("#ly-text").addEventListener("touchstart", (e) => {
  if (!LY.data?.synced || e.touches.length !== 1) return;
  lyStopFling();
  $("#ly-text").classList.add("ly-drag");
  lyTouch = { y: e.touches[0].clientY, moved: false, v: 0, t: performance.now() };
}, { passive: true });
$("#ly-text").addEventListener("touchmove", (e) => {
  if (!lyTouch || !LY.data?.synced || e.touches.length !== 1) return;
  const y = e.touches[0].clientY, delta = lyTouch.y - y, now = performance.now();
  if (Math.abs(delta) > 1) lyTouch.moved = true;
  const dt = Math.max(1, now - lyTouch.t);
  lyTouch.v = 0.8 * (delta / dt) + 0.2 * lyTouch.v; // px per ms, smoothed
  lyTouch.y = y; lyTouch.t = now;
  LY.userY = lyClamp(LY.userY + delta);
  LY.userT = now; lySync(true); e.preventDefault();
}, { passive: false });
const lyRelease = () => {
  const t = lyTouch;
  lyTouch = null;
  if (!t) return;
  if (t.moved) lyDragUntil = Date.now() + 500;
  let v = performance.now() - t.t > 80 ? 0 : t.v;
  if (Math.abs(v) < 0.05) { $("#ly-text").classList.remove("ly-drag"); return; }
  let last = performance.now();
  const step = (now) => {
    const dt = Math.min(40, now - last);
    last = now;
    v *= Math.pow(0.95, dt / 16.7);
    LY.userY = lyClamp(LY.userY + v * dt);
    LY.userT = now;
    lySync(true);
    if (Math.abs(v) > 0.02) lyFling = requestAnimationFrame(step);
    else { lyFling = 0; $("#ly-text").classList.remove("ly-drag"); }
  };
  lyFling = requestAnimationFrame(step);
};
$("#ly-text").addEventListener("touchend", lyRelease);
$("#ly-text").addEventListener("touchcancel", lyRelease);
$("#ly-text").addEventListener(
  "wheel",
  (e) => {
    if (!LY.data?.synced) return;
    e.preventDefault();
    LY.userY += e.deltaY;
    LY.userT = performance.now();
    lySync(true);
  },
  { passive: false },
);

/* ---------------- window, keys, events ---------------- */
$("#w-min").onclick = () => api("minimize");
$("#w-max").onclick = () => api("maximize");
$("#w-close").onclick = () => api("close");
if ("mediaSession" in navigator) {
  const ms = navigator.mediaSession;
  ms.setActionHandler("play", () => audio.play());
  ms.setActionHandler("pause", () => audio.pause());
  ms.setActionHandler("nexttrack", () => next());
  ms.setActionHandler("previoustrack", prev);
  try {
    ms.setActionHandler("seekto", (d) => {
      audio.currentTime = d.seekTime;
    });
  } catch {}
}
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && CLIP.box) return closeClip();
  if (e.key === "Escape" && lboxOpen()) return closeLightbox();
  if (lboxOpen() && LB.list && (e.key === "ArrowLeft" || e.key === "ArrowRight")) {
    e.preventDefault();
    return lbStep(e.key === "ArrowRight" ? 1 : -1);
  }
  if (e.target?.matches?.("input,textarea") || $("#dialog").open) return;
  if (e.code === "Space") {
    e.preventDefault();
    togglePlay();
  } else if (e.key === "ArrowRight") {
    e.ctrlKey ? next() : (audio.currentTime += 10);
  } else if (e.key === "ArrowLeft") {
    e.ctrlKey ? prev() : (audio.currentTime -= 10);
  } else if (e.key === "ArrowUp") {
    e.preventDefault();
    nudgeVol(0.05);
  } else if (e.key === "ArrowDown") {
    e.preventDefault();
    nudgeVol(-0.05);
  } else if (e.shiftKey && (e.code === "Comma" || e.code === "Period")) {
    e.preventDefault();
    setSpeed(SND.speed + (e.code === "Period" ? 0.05 : -0.05), true);
  } else if (e.key === "Escape") {
    if (lboxOpen()) return closeLightbox();
    if (sndOpen() && $("#menu").hidden) return closeSound();
    $("#menu").hidden = true;
    if (lyOpen()) toggleLyrics(false);
    else if (!fpEl().hidden) fpQ() ? setQueueMode(false) : closeFull();
    else if (TP.open) closeTrackPanel();
  } else if (e.ctrlKey && (e.code === "KeyF" || e.key.toLowerCase() === "f")) {
    e.preventDefault();
    closeFull(true);
    if (isGlass()) go("search");
    else $("#side-search").focus();
  }
});
let matchRefresh;
window.wave?.on((ev) => {
  if (ev.type === "spotify") S.spotify = ev.value;
  // the covers of the strip are asked in the background — their «fallback» notes are not about what plays now
  if (ev.type === "note" && !(window.mCoverQuiet && Date.now() - (window.lastWaveStart || 0) > 15000)) toast(ev.text, 5000);
  // 4.7: new likes of the Yandex account arrived in Wave
  if (ev.type === "likes-sync") {
    reloadLib()
      .then(() => {
        if (S.route === "likes" || S.route === "collection" || S.route === "profile") reroute();
      })
      .catch(() => {});
    if (ev.added)
      toast(
        ev.first
          ? `Яндекс Музыка: перенесено ${plural(ev.added, "лайк", "лайка", "лайков")} в «Мне нравится»`
          : `Из Яндекс Музыки: ${plural(ev.added, "новый лайк", "новых лайка", "новых лайков")}`,
        4000,
      );
  }
  if (ev.type === "ym" && S.settings) {
    S.settings.ymToken = !!ev.value?.connected;
    S.settings.ymUser = ev.value?.user || null;
    if (S.route === "settings") reroute();
  }
  if (ev.type === "win") {
    S.winHidden = !!ev.hidden;
    setWinState(S.winHidden || document.hidden, !ev.focused);
  }
  if (ev.type === "clip-close") closeClip();
  if (ev.type === "nav") navStep(ev.dir < 0 ? -1 : 1);
  if (ev.type === "fullscreen") document.body.classList.toggle("os-full", !!ev.value);
  if (ev.type === "match") {
    S.lastMatch = ev;
    const here = S.route === "playlist:" + ev.id;
    if (here) {
      const el = $("#mstat");
      if (el) el.innerHTML = matchHtml(ev);
    }
    if (!ev.running && ev.done != null) {
      if (here) {
        clearTimeout(matchRefresh);
        matchRefresh = setTimeout(() => S.route === "playlist:" + ev.id && reroute(), 300);
      }
      reloadLib().catch(() => {});
      toast(
        ev.stopped
          ? `Подбор остановлен: найдено ${ev.found} из ${ev.total}`
          : `Подбор завершён: найдено ${ev.found} из ${ev.total}`,
      );
    }
  }
});

// 4.8: a minimized window does not keep animated GIFs (avatar, banner, the GIF over the player, covers) running:
// their images are taken off the elements and put back on restore — no GIF is decoded in the background
const GIF_SEL = '[style*="image/gif"], [style*=".gif"]';
const GIF_IMG = 'img[src^="data:image/gif"], img[src*=".gif"]';
function freezeGifs(on) {
  if (on) {
    for (const el of document.querySelectorAll(GIF_SEL)) {
      if (el.dataset.gifBg !== undefined) continue;
      el.dataset.gifBg = el.style.backgroundImage;
      el.style.backgroundImage = "none";
    }
    for (const el of document.querySelectorAll(GIF_IMG)) {
      if (el.dataset.gifSrc !== undefined) continue;
      el.dataset.gifSrc = el.getAttribute("src");
      el.setAttribute("src", "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
    }
  } else {
    for (const el of document.querySelectorAll("[data-gif-bg]")) {
      el.style.backgroundImage = el.dataset.gifBg;
      delete el.dataset.gifBg;
    }
    for (const el of document.querySelectorAll("[data-gif-src]")) {
      el.setAttribute("src", el.dataset.gifSrc);
      delete el.dataset.gifSrc;
    }
  }
}
// 4.14: a window covered by other windows (a game or a video in full screen, a maximized browser) is hidden for
// Chromium too (window occlusion — see «throttle» in main.cjs): the same pause as for a minimized window
document.addEventListener("visibilitychange", () => setWinState(!!S.winHidden || document.hidden, !!S.unfocused));
// minimized / hidden window: CSS animations pause, the visualizer, lyrics and progress loops stop;
// an unfocused window keeps everything but the visualizer draws at ~20 fps
function setWinState(hidden, unfocused) {
  const was = S.bg;
  S.bg = hidden;
  S.unfocused = unfocused;
  document.body.classList.toggle("bg", hidden);
  if (hidden !== !!was) freezeGifs(hidden);
  if (hidden) {
    WaveFx.stop();
    cancelAnimationFrame(LY.raf);
    LY.raf = 0;
    cancelAnimationFrame(progRaf);
    progRaf = 0;
  } else if (was) {
    WaveFx.resume();
    lyStart();
    progStart();
    lastTu = 0;
    onTimeUpdate(); // the times / the buffer bar were not updated while hidden
  }
}

/* ---------------- 4.14: splash — the logo and the name come in, the slogan slides out from under them, gets
   «censored» (a bar covers it) and the bar is torn off: under it is a fact about censorship in music — another
   one on every start (a shuffled deck in localStorage, no repeats until all were shown). A click or any key skips
   it; Ctrl+R shows only the logo; without animations (settings, reduced motion) everything is still ---------------- */
const SPLASH_SLOGAN = "Мы против цензуры";
const SPLASH_FACTS = [
  "В 1985 году ЦК ВЛКСМ внёс Хулио Иглесиаса в список запрещённых — за «неофашизм»",
  "Village People в чёрном списке комсомола 1985 года значились за «насилие»",
  "Тину Тёрнер комсомольские цензоры 1985 года запретили одним словом: «секс»",
  "Talking Heads в СССР запрещали за «миф о советской военной угрозе»",
  "Pink Floyd попали в чёрный список ВЛКСМ за «искажение внешней политики СССР»",
  "Black Sabbath в СССР запрещали за «насилие и религиозное мракобесие»",
  "Запрещённую музыку в СССР записывали на рентгеновские снимки — «музыка на рёбрах»",
  "С 1958 года за самодельные пластинки «на рёбрах» в СССР могли судить",
  "ФБР 31 месяц изучало «непристойный» текст песни «Louie Louie» — и ничего не нашло",
  "Федеральная комиссия связи США признала текст «Louie Louie» «неразборчивым на любой скорости»",
  "После 11 сентября 2001 года радиосеть Clear Channel внесла «Imagine» в список нежелательных песен",
  "В тот же список Clear Channel в 2001 году попали все песни Rage Against the Machine",
  "Альбом 2 Live Crew в 1990 году первым в США признали непристойным — решение потом отменили",
  "BBC запретила «Relax» Frankie Goes to Hollywood — и песня стала №1 в Британии",
  "Когда BBC запретила «God Save the Queen» Sex Pistols, в некоторых чартах на её месте печатали пустую строку",
  "Ватикан осудил «Je t'aime… moi non plus» — и песня возглавила британский чарт",
  "The Doors попросили не петь «higher» на шоу Эда Салливана. Моррисон спел — и группу больше не звали",
  "Элвиса на шоу Эда Салливана в 1957 году показывали только выше пояса",
  "Rolling Stones пришлось петь на ТВ «Let's spend some time together» вместо «the night»",
  "Боб Дилан ушёл с шоу Эда Салливана, когда ему запретили петь выбранную песню",
  "Наклейка Parental Advisory появилась после слушаний в Сенате США в 1985 году — против выступал Фрэнк Заппа",
  "Первое место в «грязной пятнадцатке» цензоров PMRC заняла песня Принса «Darling Nikki»",
  "В 1936 году «Правда» назвала оперу Шостаковича «Сумбур вместо музыки»",
  "В 1948 году Шостаковича и Прокофьева официально заклеймили «формалистами»",
  "С 1983 года 80% репертуара советских ансамблей должны были составлять песни членов Союза композиторов",
  "Приказ Минкультуры №361 в 1984 году фактически запретил почти все рок-группы СССР",
  "В Ленинградском рок-клубе тексты песен перед концертом проходили «литовку» — проверку цензором",
  "После фестиваля «Тбилиси-80» Гребенщикова исключили из комсомола и уволили с работы",
  "Записи «Аквариума» и «Кино» для сборника Red Wave (1986) тайком вывезла из СССР Джоанна Стингрей",
  "После выхода Red Wave в США Минкультуры велело «Мелодии» выпустить пластинку «Аквариума»",
  "Первый официальный альбом The Beatles «Мелодия» выпустила только в 1986 году",
  "Миньоны «Мелодии» с песнями The Beatles выходили без названия группы",
  "Юрию Шевчуку в КГБ объясняли, что за рок можно и сесть",
  "В 1984 году милиция прервала концерт «Браво» и задержала Жанну Агузарову",
  "Егора Летова в 1985 году насильно отправили в психбольницу — на три месяца",
  "С 1 июля 2014 года в России запрещён мат на концертах, в кино и театре",
  "В 1979 году Хомейни запретил музыку на радио и ТВ Ирана, сравнив её с опиумом",
  "В ЮАР в 1980 году запретили «Another Brick in the Wall» — её пели бастующие школьники",
  "После слов Леннона «мы популярнее Иисуса» пластинки The Beatles жгли на кострах",
  "The Kinks четыре года не пускали в США — причину так и не объяснили",
  "BBC запретила «A Day in the Life» из-за строчки «I'd love to turn you on»",
  "Глушить западные радиостанции в СССР перестали только в ноябре 1988 года",
  "В 1982 году «Комсомолка» разгромила «Машину времени» статьёй «Рагу из синей птицы»",
  "Хаски после отмены концерта спел на крыше машины в Краснодаре — и получил 12 суток",
  "Нацисты в 1938 году устроили выставку «Дегенеративная музыка» — досталось и джазу",
  "Columbia отказалась выпускать «Strange Fruit» Билли Холидей — песню издал маленький лейбл",
  "В 2018 году китайскому ТВ запретили показывать хип-хоп и артистов с татуировками",
  "Советская присказка: «Сегодня он играет джаз, а завтра Родину продаст»",
  "Pussy Riot в 2012 году получили два года колонии за панк-молебен",
];
const SPL = {
  el: $("#splash"),
  mode: "full",
  fact: "",
  ready: false,
  done: false,
  out: false,
  started: false,
  windowVisible: false,
};
// Count only frames actually available for viewing. A long stall or a hidden window must not
// consume the time reserved for the slogan or the fact.
function splashWait(ms) {
  return new Promise((resolve) => {
    let last = 0,
      elapsed = 0;
    const frame = (now) => {
      if (SPL.out || SPL.done) return resolve();
      if (last && SPL.windowVisible && document.visibilityState === "visible" && !S.winHidden)
        elapsed += Math.min(60, Math.max(0, now - last));
      last = now;
      if (elapsed >= ms) resolve();
      else requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  });
}
// the fact of this start: the next one of a shuffled deck (the last one of a deck never opens the next deck)
function splashFact() {
  const n = SPLASH_FACTS.length;
  let st = null;
  try {
    st = JSON.parse(localStorage.getItem("wave.facts") || "null");
  } catch {}
  if (!st || st.n !== n || !Array.isArray(st.deck) || st.deck.length !== n || !(st.pos < n)) {
    const deck = [...Array(n).keys()];
    for (let k = n - 1; k > 0; k--) {
      const j = Math.floor(Math.random() * (k + 1));
      [deck[k], deck[j]] = [deck[j], deck[k]];
    }
    if (n > 1 && deck[0] === st?.last) [deck[0], deck[1]] = [deck[1], deck[0]];
    st = { n, deck, pos: 0, last: st?.last ?? null };
  }
  const i = Math.max(0, Math.min(n - 1, +st.deck[st.pos] || 0));
  st.pos++;
  st.last = i;
  try {
    localStorage.setItem("wave.facts", JSON.stringify(st));
  } catch {}
  return SPLASH_FACTS[i];
}
// Sources: Apple Music artist/catalog pages (Oxxxymiron, Каста, Баста, Noize MC, ATL, Гуф, Хаски),
// https://ncac.org/resource/music-censorship-in-america-an-interactive-timeline and
// https://www.bbc.co.uk/music/articles/46f837da-9ffa-494d-94e7-c7ffb0781bea
const EGG_FACTS = [
  // https://www.the-village.ru/weekend/musika/melon-music
  "Melon Music выросло из тюменской рэп-сцены и названо в память о Lil Melon",
  // https://the-flow.ru/new-flow/vol6-seemee
  "Seemee вспоминал, что в 16 лет выступил на разогреве у Гуфа",
  // https://the-flow.ru/new-flow/vol6-seemee
  "По словам Seemee, на жарком концерте Melon Music в Тюмени 17 зрителей потеряли сознание",
  // https://the-flow.ru/new-flow/vol6-mayot
  "Mayot работал звукорежиссёром и записывал других исполнителей",
  // https://the-flow.ru/features/og-buda-intervyu
  "OG Buda рассказывал, что вместе с Lil Melon искал собственный звук и учился работать с автотюном",
  // https://the-flow.ru/new-flow/vol7-bushido-zho
  "Bushido Zho в детстве любил танцевать и слушать Майкла Джексона",
  // https://the-flow.ru/new-flow/vol7-bushido-zho
  "Bushido Zho и Big Baby Tape познакомились ещё до большой известности",
  // https://the-flow.ru/new-flow/vol7-bushido-zho
  "Bushido Zho занимал деньги у мамы и подрабатывал, чтобы оплачивать записи на студии",
  // https://the-flow.ru/new-flow/vol8-toxis
  "Big Baby Tape стал одним из первых русских рэперов, которые зацепили Toxi$",
  // https://the-flow.ru/features/kto-takoy-aarne-i-kak-on-sobral-stolko-zvezd-u-sebya-na-albome
  "Продюсерский тег Aarne озвучил американский рэпер Winn Billion",
  // https://the-flow.ru/features/kto-takoy-aarne-i-kak-on-sobral-stolko-zvezd-u-sebya-na-albome
  "До работы под именем Aarne продюсер выпускал музыку как Octoberweather",
  // https://the-flow.ru/features/kto-takoy-aarne-i-kak-on-sobral-stolko-zvezd-u-sebya-na-albome
  "Aarne писал биты для Kizaru, Платины, Lil Krystalll и Obladaet",
  // https://the-flow.ru/features/10-klipov-kizaru
  "До псевдонима Kizaru рэпер выступал под именем Dealing Ounces",
  // https://the-flow.ru/features/10-klipov-kizaru
  "Kizaru основал объединение Haunted Family в Барселоне",
  // https://the-flow.ru/features/10-klipov-kizaru
  "Битмейкер White Punk раньше использовал имя PHVNTXM",
  // https://the-flow.ru/features/saluki-interview
  "Saluki рассказывал, что начал слушать русский рэп после знакомства с музыкой Скриптонита и Boulevard Depo",
  // https://the-flow.ru/features/saluki-afisha
  "Saluki сам писал и редактировал пояснения к своим песням на Genius",
  // https://the-flow.ru/features/saluki-afisha
  "Скриптонит помог Saluki со сведением песни «Улыбка»",
  // https://the-flow.ru/features/domu-s-normalnymi-yavleniyami-10-let-chto-izmenil-etot-albom
  "Скриптонит записывал «Дом с нормальными явлениями» в павлодарской квартире",
  // https://the-flow.ru/features/domu-s-normalnymi-yavleniyami-10-let-chto-izmenil-etot-albom
  "Скриптонит задумывал «Дом с нормальными явлениями» как историю с переходами между треками",
  // https://ufa.aif.ru/culture/art/i_face_i_morgenshtern_kak_ufa_stala_stolicey_russkogo_repa
  "Boulevard Depo увлекался граффити и сначала использовал имя Depo",
  // https://ufa.aif.ru/culture/art/i_face_i_morgenshtern_kak_ufa_stala_stolicey_russkogo_repa
  "Клип Pharaoh и Boulevard Depo «Champagne Squirt» стал вирусным и породил множество мемов",
  // https://the-flow.ru/new-flow/new-flow-vol3-gone-fludd
  "GONE.Fludd начинал в объединении Sabbat Cult, которое продвигало мрачный рэп",
  // https://the-flow.ru/features/flesh-interview
  "Flesh рассказывал, что первую музыку записывал в Adobe Audition, полученном на флешке",
  // https://the-flow.ru/features/friendly-thug-52-vpiska-2025
  "Friendly Thug 52 NGG рассказал, что получил высшее образование на факультете туризма",
  // https://the-flow.ru/news/vpiska-friendly-thug-52-ngg
  "Friendly Thug 52 NGG рассказывал, что написал часть альбома в монастыре",
  // https://the-flow.ru/features/friendly-thug-52-vpiska-2025
  "Friendly Thug 52 NGG говорил, что дружит и с OG Buda, и с Obladaet, несмотря на их биф",
  // https://the-flow.ru/features/huski-profile-2022
  "После отмены концерта Хаски исполнил песню на крыше автомобиля и был задержан",
  // https://the-flow.ru/features/zamay-2017
  "Псевдоним Хан Замай, по словам рэпера, придумал Слава КПСС",
  // https://au.rollingstone.com/music/music-news/russia-rappers-putin-war-ukraine-38458
  "Фирменный тег Slava Marlow звучит как «Слава, что ты сделал?»",
  // https://the-flow.ru/features/flesh-interview
  "Flesh связывал расцвет новой рэп-сцены с возможностью записывать музыку дома",
  // https://the-flow.ru/features/klassnyy-diss-na-og-buda-chto-rasskazal-boulevard-depo-v-podkaste-kosmicheskiy-dzhem
  "Boulevard Depo рассказывал, что впервые попал в студию по приглашению друга Pkhat",
  "В 1991 году BBC исключила из эфира 67 песен из-за войны в Персидском заливе",
  "BBC не ставила «It Would Be So Nice» Pink Floyd из-за упоминания газеты",
  "В 2003 году парк Six Flags отменил выступление Marilyn Manson на Ozzfest",
  // https://profile.ru/culture/30-let-russkomu-repu-ot-vtorichnosti-i-prezreniya-k-oshelomlyajushhemu-uspehu-977740
  "Первый рэп-фестиваль «Рэп-пик» в Ленинграде длился три дня",
  "Первое место на фестивале «Рэп-пик» заняла группа Bad Balance",
  "Фестиваль Rap Music проводится с 1994 года по инициативе участников Bad Balance",
  "Дельфин участвовал в группах «Мальчишник» и «Дубовый Гаайъ»",
  // https://daily.jstor.org/parental-advisory-the-story-of-a-warning-label/
  "В 1985 году музыканты Ди Снайдер и Джон Денвер выступили на слушаниях Сената США о маркировке пластинок",
  // https://www.bbc.co.uk/music/articles/46f837da-9ffa-494d-94e7-c7ffb0781bea
  "BBC временно не ставила «Space Oddity» Дэвида Боуи до возвращения экипажа «Аполлона-11»",
  "Для эфира BBC The Kinks изменили упоминание Coca-Cola в песне «Lola»",
  "BBC запрещала «My Generation» The Who из-за вокального заикания",
  "BBC сочла «Monster Mash» Бобби Пикетта слишком мрачной для эфира",
  "BBC не пускала в эфир «Landing of the Daleks» из-за сигнала SOS азбукой Морзе",
  "В 1997 году BBC запретила «Summer Smash» группы Denim после гибели принцессы Дианы",
];
function eggFact() {
  const n = EGG_FACTS.length;
  let st;
  try {
    st = JSON.parse(localStorage.getItem("wave.eggFacts") || "null");
  } catch {}
  if (!st || st.n !== n || !Array.isArray(st.deck) || st.deck.length !== n || !(st.pos < n)) {
    const deck = [...Array(n).keys()];
    for (let k = n - 1; k > 0; k--) {
      const j = Math.floor(Math.random() * (k + 1));
      [deck[k], deck[j]] = [deck[j], deck[k]];
    }
    if (n > 1 && deck[0] === st?.last) [deck[0], deck[1]] = [deck[1], deck[0]];
    st = { n, deck, pos: 0, last: st?.last ?? null };
  }
  const i = st.deck[st.pos++];
  st.last = i;
  try {
    localStorage.setItem("wave.eggFacts", JSON.stringify(st));
  } catch {}
  return EGG_FACTS[i];
}
const EGG = { times: [], timer: 0, navTimer: 0 };
$(".brand").addEventListener("click", (event) => {
  event.stopPropagation(); // a rapid series must not navigate away on its first click
  const now = Date.now();
  EGG.times = EGG.times.filter((t) => now - t < 2200);
  EGG.times.push(now);
  clearTimeout(EGG.navTimer);
  if (EGG.times.length === 1) EGG.navTimer = setTimeout(() => go("wave"), 650);
  if (EGG.times.length < 3) return;
  EGG.times = [];
  if (Math.random() >= 0.35) return;
  let bubble = $(".egg-bubble");
  if (!bubble) {
    bubble = document.createElement("div");
    bubble.className = "egg-bubble";
    bubble.setAttribute("role", "status");
    $(".sidebar").appendChild(bubble);
  }
  bubble.innerHTML = `<strong>Факт от Wave</strong><span>${esc(eggFact())}</span>`;
  bubble.hidden = false;
  clearTimeout(EGG.timer);
  EGG.timer = setTimeout(() => {
    bubble.hidden = true;
  }, 6500);
});

// typography of a fact: names («The Beatles», «Эда Салливана»), short words and «—» do not end a line
function splashType(s) {
  return String(s)
    .replace(/\b([A-Z][a-z']+) (?=[A-Z])/g, "$1\u00a0")
    .replace(/([А-ЯЁ][а-яё]+) (?=[А-ЯЁ][а-яё])/g, "$1\u00a0")
    .replace(/(?<=^|[\s\u00a0«])([вскуояиВСКУОЯИ]|за|на|по|до|из|от|не|об|во|со|ко|№) /g, "$1\u00a0")
    .replace(/ —/g, "\u00a0—");
}
// the tinted logo and the accent of the last start: the splash has the right colours from the first frame
function splashSave() {
  try {
    localStorage.setItem("wave.splash", JSON.stringify({ acc: accentHex(), logo: LOGO.url }));
  } catch {}
}
function splashInit() {
  const sp = SPL.el;
  if (!sp) return;
  let c = null,
    reload = false;
  try {
    c = JSON.parse(localStorage.getItem("wave.splash") || "null");
    reload = performance.getEntriesByType("navigation")[0]?.type === "reload";
    sessionStorage.removeItem("wave.reload");
  } catch {}
  if (c?.acc && /^#[0-9a-f]{6}$/i.test(c.acc)) {
    const n = parseInt(c.acc.slice(1), 16);
    sp.style.setProperty("--sp-acc", c.acc);
    // the text on the accent bar: dark on a light accent, white on a dark one
    sp.style.setProperty(
      "--sp-ink",
      0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255) > 160 ? "#0b0b12" : "#fff",
    );
  }
  const img = sp.querySelector("img");
  if (img && typeof c?.logo === "string" && /^(data:image\/png;base64,|assets\/)/.test(c.logo)) img.src = c.logo;
  let still = false;
  try {
    still = localStorage.getItem("wave.anim") === "0" || matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch {}
  SPL.mode = reload ? "quick" : still ? "still" : "full";
  sp.classList.add(SPL.mode);
  if (SPL.mode !== "quick") SPL.fact = splashType(splashFact());
  let logoReady = false;
  const start = () => {
    if (
      SPL.started ||
      SPL.done ||
      !logoReady ||
      !SPL.windowVisible ||
      document.visibilityState !== "visible" ||
      S.winHidden
    )
      return;
    SPL.started = true;
    // Give the newly shown native window a paint before starting CSS animations.
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        if (!SPL.windowVisible || document.visibilityState !== "visible" || S.winHidden) {
          SPL.started = false;
          return start();
        }
        if (SPL.done || SPL.out) return;
        sp.classList.add("run");
        splashRun().catch(async () => {
          if (SPL.done || SPL.out) return;
          // Even if a browser cannot animate the bars, keep the fact readable.
          sp.querySelectorAll(".sp-bar").forEach((b) => b.remove());
          const line = sp.querySelector(".sp-line"),
            kick = sp.querySelector(".sp-kick");
          if (line) {
            line.style.opacity = "";
            line.style.transition = "";
            line.textContent = SPL.fact;
          }
          if (kick) kick.hidden = false;
          await splashWait(3000);
          if (!SPL.out) {
            SPL.done = true;
            hideSplash();
          }
        });
      }),
    );
  };
  // The native show event can precede script execution; subscribe first, then query it.
  window.wave?.on((event) => {
    if (event?.type !== "win") return;
    SPL.windowVisible = !event.hidden;
    start();
  });
  document.addEventListener("visibilitychange", start);
  api("splash-window-visible")
    .then((visible) => {
      // null means an older preload/main implementation; normal builds return a boolean.
      if (visible === true || visible == null) {
        SPL.windowVisible = true;
        start();
      }
    })
    .catch(() => {
      SPL.windowVisible = true;
      start();
    });
  Promise.race([
    (img?.decode ? img.decode() : Promise.resolve()).catch(() => {}),
    new Promise((r) => setTimeout(r, 350)),
  ]).then(() => {
    logoReady = true;
    start();
  });
  sp.addEventListener("pointerdown", (e) => e.button === 0 && splashSkip());
  addEventListener("keydown", splashKey, true);
  setTimeout(() => {
    if (!SPL.ready && !SPL.out) {
      const hint = sp.querySelector(".sp-hint");
      if (hint) hint.textContent = "Загрузка продолжается…";
    }
  }, 12000);
}
function splashKey(e) {
  if (SPL.out || e.repeat) return;
  e.preventDefault();
  e.stopPropagation();
  splashSkip();
}
function splashSkip() {
  SPL.done = true;
  if (!SPL.ready) {
    const hint = SPL.el?.querySelector(".sp-hint");
    if (hint) hint.textContent = "Загрузка приложения…";
  }
  hideSplash();
}
// the line boxes of the slogan / fact relative to .sp-tag — a bar per line, like a redacted document
function splashRects(line, tag) {
  const b = tag.getBoundingClientRect();
  return [...line.getClientRects()].map((r) => ({
    x: r.left - b.left - 6,
    y: r.top - b.top - 1,
    w: r.width + 12,
    h: r.height + 2,
  }));
}
async function splashRun() {
  const sp = SPL.el;
  const tag = sp.querySelector(".sp-tag"),
    line = sp.querySelector(".sp-line"),
    kick = sp.querySelector(".sp-kick");
  const finish = async (ms) => {
    await splashWait(ms);
    SPL.done = true;
    hideSplash();
  };
  const read = Math.max(3000, Math.min(5000, 1500 + SPL.fact.length * 35));
  if (SPL.mode === "quick") return finish(420);
  if (SPL.mode === "still") {
    await splashWait(1100);
    if (SPL.out || SPL.done) return;
    line.textContent = SPL.fact;
    kick.hidden = false;
    return finish(read + 400);
  }
  await splashWait(2500);
  if (SPL.out || SPL.done || !line || !tag) return;
  // the slogan has finished coming out (its bar is measured where it stays)
  const place = (el, r) =>
    Object.assign(el.style, { left: r.x + "px", top: r.y + "px", width: r.w + "px", height: r.h + "px" });
  const bar = (r) => {
    const b = document.createElement("i");
    b.className = "sp-bar";
    place(b, r);
    tag.appendChild(b);
    return b;
  };
  const r0 = splashRects(line, tag)[0];
  if (!r0) throw new Error("Splash text is not laid out");
  // 1) the slogan is «censored»
  const b0 = bar(r0);
  b0.innerHTML = "<span>цензура</span>";
  b0.animate([{ transform: "scaleX(0)" }, { transform: "scaleX(1)" }], {
    duration: 300,
    easing: "cubic-bezier(.65,0,.3,1)",
    fill: "both",
  });
  await splashWait(560);
  if (SPL.out || SPL.done) return;
  // 2) under the bar it becomes the fact; the bar takes the shape of its lines (the text waits, hidden at once)
  line.style.transition = "none";
  line.style.opacity = "0";
  line.textContent = SPL.fact;
  const rs = splashRects(line, tag);
  b0.remove();
  const bars = rs.map((r) => {
    const b = bar(r);
    b.animate(
      [
        { left: r0.x + "px", top: r0.y + "px", width: r0.w + "px", height: r0.h + "px" },
        { left: r.x + "px", top: r.y + "px", width: r.w + "px", height: r.h + "px" },
      ],
      { duration: 280, easing: "cubic-bezier(.3,.7,.2,1)" },
    );
    return b;
  });
  await splashWait(300);
  line.style.transition = line.style.opacity = "";
  await splashWait(120);
  if (SPL.out || SPL.done) return;
  // 3) the bars are torn off — the fact is revealed
  kick.hidden = false;
  kick.animate(
    [
      { opacity: 0, transform: "translateY(4px)" },
      { opacity: 1, transform: "none" },
    ],
    {
      duration: 420,
      delay: 160,
      easing: "ease-out",
      fill: "both",
    },
  );
  bars.forEach((b, k) => {
    b.style.transformOrigin = "right center";
    b.animate([{ transform: "scaleX(1)" }, { transform: "scaleX(0)" }], {
      duration: 340,
      delay: k * 90,
      easing: "cubic-bezier(.7,0,.3,1)",
      fill: "both",
    });
  });
  await splashWait(400 + Math.max(0, bars.length - 1) * 90);
  if (SPL.out || SPL.done) return;
  bars.forEach((b) => b.remove());
  return finish(read);
}
// hidden when the app is ready and the slogan / fact had its time (or was skipped)
function hideSplash() {
  const sp = SPL.el;
  if (!sp || SPL.out || !SPL.done || !SPL.ready) return;
  SPL.out = true;
  removeEventListener("keydown", splashKey, true);
  sp.classList.add("out");
  setTimeout(() => {
    sp.remove();
    if (S.route === "wave" && $("#wv-fx") && $("#wv-stage")) WaveFx.start($("#wv-fx"), $("#wv-stage"));
    setTimeout(() => loadWheel(), 800);
  }, 600);
}
splashInit();

/* ---------------- 4.14: Ctrl+R — the queue, the track and the second survive the reload ----------------
   main.cjs reloads the page; «pagehide» keeps what plays in sessionStorage (it lives as long as the window) */
const RESUME_KEY = "wave.resume";
addEventListener("pagehide", () => {
  try {
    // Navigation timing distinguishes an actual reload from closing and restarting the app.
    if (!S.current || S.index < 0 || !S.queue[S.index]) return void sessionStorage.removeItem(RESUME_KEY);
    const a = Math.max(0, S.index - 200);
    sessionStorage.setItem(
      RESUME_KEY,
      JSON.stringify({
        at: Date.now(),
        q: S.queue.slice(a, S.index + 300),
        i: S.index - a,
        t: S.pendingResume ? S.startAt?.t || 0 : audio.currentTime || 0,
        play: !S.pendingResume && !audio.paused,
        stream: S.stream ? { ...S.stream, url: undefined } : null,
        ctx: S.ctx || null,
        wave: !!S.wave,
        waveOpts: S.waveOpts || {},
        shuffle: !!S.shuffle,
        repeat: S.repeat,
        route: S.route,
      }),
    );
  } catch {}
});
function takeResume() {
  try {
    const r = JSON.parse(sessionStorage.getItem(RESUME_KEY) || "null");
    sessionStorage.removeItem(RESUME_KEY);
    if (!r || !(Date.now() - r.at < 120000) || !Array.isArray(r.q) || !r.q[r.i]?.id) return null;
    return r;
  } catch {
    return null;
  }
}
function resumeQueue(r) {
  S.queue = r.q;
  S.lists.q = S.queue;
  S.ctx = r.ctx || null;
  S.wave = !!r.wave;
  S.waveOpts = r.waveOpts || {};
  S.shuffle = !!r.shuffle;
  if (["off", "all", "one"].includes(r.repeat)) S.repeat = r.repeat;
  S.startAt = { id: r.q[r.i].id, t: Math.max(0, (+r.t || 0) - 0.4) };
  if (r.play) return void playAt(r.i);
  // paused: the track is shown, ▶ continues it from the same second (see togglePlay)
  S.index = r.i;
  S.current = r.q[r.i];
  S.pendingResume = true;
  updateNow(S.current, r.stream || null);
  renderQueue();
}

/* ---------------- boot ---------------- */
(async () => {
  try {
    const b = await api("bootstrap");
    S.settings = b.settings;
    S.version = b.version;
    S.spotify = b.spotify;
    S.playlists = b.library.playlists;
    S.history = b.library.history;
    S.artistTime = b.library.artistTime || [];
    S.likesCover = b.library.likesCover || null;
    S.dislikes = new Set(b.library.dislikes);
    setLikes(b.library.likes);
    MIXG.on = !!b.mixerGuard;
    applySettings();
    let v = typeof b.settings.volume === "number" ? b.settings.volume : 0.7;
    if (b.settings.volCurve !== 2) {
      // 4.1 stored a linear 0…1 volume; keep the same loudness on the new perceptual curve
      v = Math.sqrt(Math.max(0, Math.min(1, v)));
      api("settings", { volume: v, volCurve: 2 })
        .then((s) => (S.settings = s))
        .catch(() => {});
    }
    setVol(v);
  } catch (e) {
    S.settings = {
      theme: "dark",
      ui: "glass",
      player: "cover",
      accent: "violet",
      glassFx: "full",
      profile: { nick: "Слушатель" },
      wave: { mood: "all", diversity: "default" },
      sources: {},
      animation: true,
    };
    applySettings();
    setVol(0.84);
    toast(e.message, 8000);
  }
  // 4.14: after Ctrl+R the queue, the track (from the same second) and the page come back
  const rs = SPL.mode === "quick" ? takeResume() : null;
  if (rs) resumeQueue(rs);
  syncModes();
  applyPalette();
  const home = isGlass() ? "wave" : "home";
  const back = rs?.route && !(rs.route.startsWith("track:") && rs.route.slice(6) !== S.current?.id) ? rs.route : null;
  go(back || home, { push: false });
  SPL.ready = true;
  hideSplash();
})();

// Spotify library can be collapsed without removing navigation or playlist access.
(() => {
  const btn = document.querySelector("#sp-library-toggle");
  if (!btn) return;
  const apply = (compact) => {
    document.body.classList.toggle("sp-library-compact", compact);
    btn.title = compact ? "Открыть мою медиатеку" : "Закрыть мою медиатеку";
    btn.setAttribute("aria-label", btn.title);
    btn.setAttribute("aria-expanded", String(!compact));
    try { localStorage.setItem("wave.spotify.libraryCompact", compact ? "1" : "0"); } catch {}
  };
  let initial = false; try { initial = localStorage.getItem("wave.spotify.libraryCompact") === "1"; } catch {}
  apply(initial);
  btn.addEventListener("click", () => apply(!document.body.classList.contains("sp-library-compact")));
  document.querySelector("#sp-library-new")?.addEventListener("click", () => newPlaylistDialog());
})();


/* 4.15.8: Spotify-inspired navigation and release surfaces, scoped to this skin. */
async function spotifyReleaseColor(url, colors) {
  const el = $(".sp-release"), route = S.route;
  if (!el) return;
  try {
    const pal = colors?.accent || colors?.average ? { ym: colors } :
      url && /^(https:|wave-media:)/.test(url) ? await api("palette", { url: url.startsWith("https:") ? thumb(url, "s") : url }) : null;
    if (pal && S.route === route && el.isConnected) el.style.setProperty("--release-color", rampFrom(pal)[1]);
  } catch { /* neutral fallback if cover extraction is unavailable */ }
}
function spotifyWaveView() {
  WAVE_ITEMS = wavePresets();
  setContent(`<div class="sp-wave"><div class="sp-wave-hero"><div class="sp-wave-art">${icon("burst")}</div><div><div class="kind">Персональная станция</div><h1>Моя волна</h1><p>Музыка под ваше настроение</p></div></div><div class="sp-wave-controls"><button class="sp-wave-play" data-cmd="sp-wave-play" title="Включить Мою волну" aria-label="Включить Мою волну">${icon(S.wave && S.current && !audio.paused ? "pause" : "play")}</button><div id="sp-wave-current"></div></div><div class="sp-wave-heading"><h2>Настройте свою волну</h2><span>Выберите настроение или станцию</span></div><div class="sp-wave-grid">${WAVE_ITEMS.map((x,i) => `<button class="sp-wave-card" data-sp-wave="${i}"><span class="sp-wave-card-art" ${bg(x.img,"m")}>${x.img ? "" : icon(x.g === "tune" ? "settings" : x.g === "back" ? "left" : x.g === "shake" ? "shuffle" : "note")}</span><span><b>${esc(x.title || "Моя волна")}</b>${x.sub ? `<small>${esc(x.sub)}</small>` : ""}</span></button>`).join("")}</div></div>`);
  $(".sp-wave-grid").onclick = (e) => { const b = e.target.closest("[data-sp-wave]"); if (b) WAVE_ITEMS[+b.dataset.spWave]?.act(); };
  spotifyWaveCurrent();
}
function spotifyWaveCurrent() {
  const el = $("#sp-wave-current"); if (!el) return;
  el.innerHTML = S.current ? `<b>${esc(S.current.title)}</b><small>${esc(S.current.artist || "")}</small>` : '<b>Включите Мою волну</b><small>Откройте музыку для себя</small>';
}
let spQueueTab = "queue";
function renderSpotifyQueue() {
  $$("[data-spq]").forEach(b => { b.classList.toggle("active", b.dataset.spq === spQueueTab); b.setAttribute("aria-selected", String(b.dataset.spq === spQueueTab)); });
  S.lists.q = S.queue;
  const rows = (ts, lid, base=0) => `<div class="tracks">${ts.map((t,i) => trackRow(t,lid,base+i)).join("")}</div>`;
  const box = $("#queue-list");
  if (spQueueTab === "history") {
    const history = S.history.slice(0, Q_LIMIT); const lid = reg(history);
    box.innerHTML = history.length ? `<h4>Недавно прослушано</h4>${rows(history,lid)}` : '<div class="empty">История прослушивания пуста</div>';
    return;
  }
  const start = Math.max(0, S.index + 1), upcoming = S.queue.slice(start, start + Q_LIMIT);
  const current = S.current ? `<h4>Сейчас играет</h4>${rows([S.current],reg([S.current]))}` : '';
  box.innerHTML = current + `<h4>Далее в очереди</h4>` + (upcoming.length ? rows(upcoming,"q",start) : '<div class="empty">Очередь пуста</div>');
  const extra = S.queue.length - start - upcoming.length;
  if (extra > 0) box.insertAdjacentHTML("beforeend", `<div class="q-more">и ещё ${plural(extra,"трек","трека","треков")}</div>`);
}
(() => {
  const input = $("#sp-top-search"), pop = $("#sp-search-pop"), clear = $("#sp-search-clear");
  let seq = 0, found = [];
  const hide = () => { pop.hidden = true; };
  const submit = () => { const q = input.value.trim(); hide(); if (q) go("search:" + encodeURIComponent(q)); else go("search"); };
  const update = debounce(async () => {
    const q = input.value.trim(), n = ++seq; found = [];
    if (!q) return hide();
    pop.innerHTML = `<div class="sp-search-hint">Введите запрос и нажмите Enter</div><button data-sp-query>${icon("search")}<b>Искать «${esc(q)}»</b></button>`; pop.hidden = false;
    try {
      const r = await api("search", { q }); if (n !== seq || input.value.trim() !== q || document.activeElement !== input) return;
      const artists = (r?.artists || []).slice(0,3), tracks = (r?.tracks || []).slice(0,4); found = tracks;
      pop.innerHTML += artists.map(a => `<button data-sp-artist="${esc(a.id || "")}" data-name="${esc(a.name || "")}"><span class="sp-search-art round" ${bg(a.avatar || a.cover || a.image,"s")}>${a.avatar || a.cover || a.image ? "" : icon("note")}</span><span><b>${esc(a.name)}</b><small>Исполнитель</small></span></button>`).join("") + tracks.map((t,i) => `<button data-sp-track="${i}"><span class="sp-search-art" ${bg(t.cover,"s")}>${t.cover ? "" : icon("note")}</span><span><b>${esc(t.title)}</b><small>Трек · ${esc(t.artist || "")}</small></span></button>`).join("");
    } catch { /* full search page displays detailed errors */ }
  }, 350);
  input.addEventListener("input", () => { ++seq; clear.hidden = !input.value; update(); });
  input.addEventListener("focus", () => { if (input.value.trim()) update(); });
  input.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); submit(); } else if (e.key === "Escape") hide(); else if (e.key === "ArrowDown" && !pop.hidden) { e.preventDefault(); pop.querySelector("button")?.focus(); } });
  pop.addEventListener("keydown", e => { const bs=[...pop.querySelectorAll("button")], i=bs.indexOf(document.activeElement); if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); (bs[i+(e.key === "ArrowDown" ? 1 : -1)] || input).focus(); } else if (e.key === "Escape") { hide(); input.focus(); } });
  pop.addEventListener("click", e => { const b=e.target.closest("button"); if (!b) return; if (b.hasAttribute("data-sp-query")) return submit(); if (b.hasAttribute("data-sp-artist")) { hide(); openArtist(b.dataset.spArtist,b.dataset.name); } else if (b.hasAttribute("data-sp-track")) { const t=found[+b.dataset.spTrack]; if (t) { hide(); TRACKS.set(t.id,t); go("track:"+t.id); } } });
  clear.addEventListener("click", () => { input.value=""; clear.hidden=true; ++seq; hide(); input.focus(); });
  $("#sp-search-submit").addEventListener("click",submit);
  document.addEventListener("click",e => { if (!e.target.closest(".sp-search-wrap")) hide(); });
  $(".sp-queue-tabs").addEventListener("click", e => { const b=e.target.closest("[data-spq]"); if (b) { spQueueTab=b.dataset.spq; renderQueue(); } });
  clear.hidden=true;
})();

// 4.16: light follows the last visible letters without covering the input text.
(() => {
  const selector = "#sq, #sp-top-search, #side-search";
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  function update(input) {
    if (!input?.matches?.(selector)) return;
    const box = input.closest(".ysearch, .bigsearch, .sp-search-box, .side-search");
    if (!box) return;
    if (document.activeElement !== input || !input.value) { box.classList.remove("search-glow"); return; }
    const style = getComputedStyle(input), ir = input.getBoundingClientRect(), br = box.getBoundingClientRect();
    ctx.font = style.font;
    const spacing = parseFloat(style.letterSpacing) || 0;
    const textWidth = ctx.measureText(input.value).width + Math.max(0, input.value.length - 1) * spacing;
    const end = ir.left - br.left + (parseFloat(style.paddingLeft) || 0) + textWidth - input.scrollLeft;
    const x = Math.max(ir.left - br.left + 4, Math.min(ir.right - br.left - 4, end + 16));
    box.style.setProperty("--search-glow-x", x + "px");
    box.classList.add("search-glow");
  }
  function schedule(e) { const input = e.target; if (input?.matches?.(selector)) requestAnimationFrame(() => update(input)); }
  document.addEventListener("input", schedule);
  document.addEventListener("focusin", schedule);
  document.addEventListener("focusout", schedule);
  document.addEventListener("scroll", schedule, true);
  window.addEventListener("resize", () => update(document.activeElement));
})();

/* 4.20.1: the confirmation dialog of the PC renderer (social.js asks before leaving a room, removing a friend…) */
let waveConfirmTail = Promise.resolve();
function waveConfirm(text, { title = "Подтверждение", ok = "Продолжить", danger = false } = {}) {
  const job = waveConfirmTail.then(
    () =>
      new Promise((resolve) => {
        const d = document.createElement("dialog");
        d.className = "dialog confirm wave-confirm";
        d.setAttribute("aria-label", title);
        d.innerHTML = `<div class="cf-head"><h3>${esc(title)}</h3></div><p class="cf-text">${esc(text)}</p><div class="acts"><button class="btn" data-answer="no">Отмена</button><button class="btn ${danger ? "danger" : "acc"}" data-answer="yes">${esc(ok)}</button></div>`;
        let result = false;
        d.querySelector("[data-answer=no]").onclick = () => d.close();
        d.querySelector("[data-answer=yes]").onclick = () => { result = true; d.close(); };
        d.addEventListener("close", () => { d.remove(); resolve(result); }, { once: true });
        document.body.append(d);
        d.showModal();
      }),
  );
  waveConfirmTail = job.catch(() => {});
  return job;
}
