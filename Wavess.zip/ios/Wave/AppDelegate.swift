import UIKit
import AVFoundation

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    /// fixed port: the WebView keeps localStorage per origin, so it survives restarts
    static let port: UInt16 = 47800
    static let key: String = {
        var bytes = [UInt8](repeating: 0, count: 16)
        _ = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
        return bytes.map { String(format: "%02x", $0) }.joined()
    }()

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default, options: [])
        try? session.setActive(true)

        startCore()

        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = .black
        w.rootViewController = WaveViewController()
        w.makeKeyAndVisible()
        window = w
        application.beginReceivingRemoteControlEvents()
        return true
    }

    func startCore() {
        let fm = FileManager.default
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let data = base.appendingPathComponent("wave-data", isDirectory: true)
        try? fm.createDirectory(at: data, withIntermediateDirectories: true)
        // ui/ is copied into the root of the app bundle
        let root = Bundle.main.resourcePath ?? "."
        root.withCString { r in
            data.path.withCString { d in
                AppDelegate.key.withCString { k in
                    _ = wave_ios_start(r, d, AppDelegate.port, k)
                }
            }
        }
    }
}
