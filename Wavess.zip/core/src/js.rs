//! Small helpers that give serde_json values the semantics of the original JavaScript core:
//! `obj.key` of a missing key is `null`, truthiness, `String(x || "")`, `Number(x)`, `Math.round`, slicing.
//! The whole backend works on dynamic JSON (like the JS code did), so the answers keep exactly the same shape.

use serde_json::{Map, Value};
use std::fmt;

pub static NULL: Value = Value::Null;

/// An error like the JS ones: a message plus the few properties the core looked at (status, body, drm, preview).
#[derive(Debug, Clone, Default)]
pub struct E {
    pub msg: String,
    pub status: Option<u16>,
    pub body: Option<String>,
    pub drm: bool,
    pub preview: bool,
    pub captcha: bool,
}
impl E {
    pub fn new(m: impl Into<String>) -> E {
        E { msg: m.into(), ..Default::default() }
    }
    pub fn status(mut self, s: u16) -> E {
        self.status = Some(s);
        self
    }
}
impl fmt::Display for E {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.msg)
    }
}
pub type R<T> = Result<T, E>;

/// a compiled-once regex: `re!(r"…")`
#[macro_export]
macro_rules! re {
    ($s:expr) => {{
        static RE: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new($s).unwrap());
        &*RE
    }};
}

#[macro_export]
macro_rules! bail {
    ($($t:tt)*) => { return Err($crate::js::E::new(format!($($t)*))) };
}

/// JS-like access to dynamic values.
pub trait J {
    fn g(&self, k: &str) -> &Value;
    fn at(&self, i: usize) -> &Value;
    fn path(&self, ks: &[&str]) -> &Value;
    fn truthy(&self) -> bool;
    /// `String(v || "")`
    fn s(&self) -> String;
    /// `String(v)` (null → "null")
    fn sv(&self) -> String;
    /// `Number(v)` (NaN when not a number)
    fn n(&self) -> f64;
    fn arr(&self) -> &[Value];
    fn str_(&self) -> Option<&str>;
    fn is_obj(&self) -> bool;
}
impl J for Value {
    fn g(&self, k: &str) -> &Value {
        match self {
            Value::Object(m) => m.get(k).unwrap_or(&NULL),
            Value::Array(a) => k.parse::<usize>().ok().and_then(|i| a.get(i)).unwrap_or(&NULL),
            _ => &NULL,
        }
    }
    fn at(&self, i: usize) -> &Value {
        match self {
            Value::Array(a) => a.get(i).unwrap_or(&NULL),
            _ => &NULL,
        }
    }
    fn path(&self, ks: &[&str]) -> &Value {
        let mut v = self;
        for k in ks {
            v = v.g(k);
        }
        v
    }
    fn truthy(&self) -> bool {
        match self {
            Value::Null => false,
            Value::Bool(b) => *b,
            Value::Number(n) => n.as_f64().map(|f| f != 0.0 && !f.is_nan()).unwrap_or(false),
            Value::String(s) => !s.is_empty(),
            _ => true,
        }
    }
    fn s(&self) -> String {
        if !self.truthy() {
            return String::new();
        }
        self.sv()
    }
    fn sv(&self) -> String {
        match self {
            Value::Null => "null".into(),
            Value::Bool(b) => b.to_string(),
            Value::Number(n) => num_str(n.as_f64().unwrap_or(0.0)),
            Value::String(s) => s.clone(),
            Value::Array(a) => a.iter().map(|x| if x.is_null() { String::new() } else { x.sv() }).collect::<Vec<_>>().join(","),
            Value::Object(_) => "[object Object]".into(),
        }
    }
    fn n(&self) -> f64 {
        match self {
            Value::Null => 0.0,
            Value::Bool(b) => *b as i32 as f64,
            Value::Number(n) => n.as_f64().unwrap_or(f64::NAN),
            Value::String(s) => str_num(s),
            Value::Array(a) if a.is_empty() => 0.0,
            Value::Array(a) if a.len() == 1 => a[0].n(),
            _ => f64::NAN,
        }
    }
    fn arr(&self) -> &[Value] {
        match self {
            Value::Array(a) => a,
            _ => &[],
        }
    }
    fn str_(&self) -> Option<&str> {
        self.as_str()
    }
    fn is_obj(&self) -> bool {
        self.is_object()
    }
}

/// `Number("…")`
pub fn str_num(s: &str) -> f64 {
    let t = s.trim();
    if t.is_empty() {
        return 0.0;
    }
    if let Some(h) = t.strip_prefix("0x").or_else(|| t.strip_prefix("0X")) {
        return i64::from_str_radix(h, 16).map(|x| x as f64).unwrap_or(f64::NAN);
    }
    if t == "Infinity" || t == "+Infinity" {
        return f64::INFINITY;
    }
    if t == "-Infinity" {
        return f64::NEG_INFINITY;
    }
    if t.chars().any(|c| c.is_ascii_alphabetic() && c != 'e' && c != 'E') {
        return f64::NAN;
    }
    t.parse::<f64>().unwrap_or(f64::NAN)
}

/// number → string like JS
pub fn num_str(f: f64) -> String {
    if f.is_nan() {
        return "NaN".into();
    }
    if f.is_infinite() {
        return if f > 0.0 { "Infinity".into() } else { "-Infinity".into() };
    }
    if f == f.trunc() && f.abs() < 1e21 {
        return format!("{}", f as i64);
    }
    format!("{}", f)
}

/// a number value; integral numbers become JSON integers (JSON.stringify writes 5, not 5.0)
pub fn jn(f: f64) -> Value {
    if !f.is_finite() {
        return Value::Null;
    }
    if f == f.trunc() && f.abs() < 9.0e15 {
        Value::from(f as i64)
    } else {
        Value::from(f)
    }
}

/// `Math.round`
pub fn round(x: f64) -> f64 {
    (x + 0.5).floor()
}

/// `Number.isFinite(+v) ? Math.min(hi, Math.max(lo, +v)) : def`
pub fn clamp_num(v: &Value, lo: f64, hi: f64, def: f64) -> f64 {
    if v.is_null() {
        return def; // `undefined` of a missing key
    }
    let x = v.n();
    if x.is_finite() {
        x.max(lo).min(hi)
    } else {
        def
    }
}

/// `typeof v === "string" ? v.slice(0, n) : ""`
pub fn str_n(v: &Value, n: usize) -> String {
    match v {
        Value::String(s) => slice(s, n),
        _ => String::new(),
    }
}

/// `s.slice(0, n)` by characters
pub fn slice(s: &str, n: usize) -> String {
    match s.char_indices().nth(n) {
        Some((i, _)) => s[..i].to_string(),
        None => s.to_string(),
    }
}

/// `s.slice(-n)` by characters
pub fn slice_end(s: &str, n: usize) -> String {
    let c = s.chars().count();
    if c <= n {
        return s.to_string();
    }
    s.chars().skip(c - n).collect()
}

pub fn obj() -> Map<String, Value> {
    Map::new()
}

/// `{ ...a, ...b }` for objects
pub fn spread(a: &Value, b: &Value) -> Value {
    let mut m = match a {
        Value::Object(m) => m.clone(),
        _ => Map::new(),
    };
    if let Value::Object(bm) = b {
        for (k, v) in bm {
            m.insert(k.clone(), v.clone());
        }
    }
    Value::Object(m)
}

/// sets a key of an object value (no-op for other values)
pub fn set(o: &mut Value, k: &str, v: Value) {
    if let Value::Object(m) = o {
        m.insert(k.to_string(), v);
    }
}

pub fn now_ms() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

pub fn rand_f() -> f64 {
    rand::random::<f64>()
}

pub fn shuffle<T>(a: &mut [T]) {
    for i in (1..a.len()).rev() {
        let j = (rand_f() * (i as f64 + 1.0)).floor() as usize;
        a.swap(i, j.min(i));
    }
}

/// `encodeURIComponent`
pub fn enc(s: &str) -> String {
    const SET: &percent_encoding::AsciiSet = &percent_encoding::NON_ALPHANUMERIC
        .remove(b'-')
        .remove(b'_')
        .remove(b'.')
        .remove(b'!')
        .remove(b'~')
        .remove(b'*')
        .remove(b'\'')
        .remove(b'(')
        .remove(b')');
    percent_encoding::utf8_percent_encode(s, SET).to_string()
}

/// `decodeURIComponent` (lossy)
pub fn dec(s: &str) -> String {
    percent_encoding::percent_decode_str(s).decode_utf8_lossy().to_string()
}

/// `new URLSearchParams(pairs).toString()`
pub fn qs(pairs: &[(&str, &str)]) -> String {
    let mut s = url::form_urlencoded::Serializer::new(String::new());
    for (k, v) in pairs {
        s.append_pair(k, v);
    }
    s.finish()
}

/// Set-like dedupe keeping the first occurrence
pub fn uniq_strings(list: impl IntoIterator<Item = String>) -> Vec<String> {
    let mut seen = std::collections::HashSet::new();
    let mut out = vec![];
    for s in list {
        if seen.insert(s.clone()) {
            out.push(s);
        }
    }
    out
}

pub fn err_msg(e: &E) -> Value {
    Value::String(e.msg.clone())
}
