//! Yandex Music «get-file-info» (lossless FLAC): HMAC-SHA256 signed requests; the «encraw» transport gives an
//! AES-CTR encrypted file + its key, decrypted on the fly (with seeking, resuming and link renewal) for
//! wave-media://ym/<id>.

use crate::js::{jn, now_ms, qs, J};
use crate::re;
use crate::resp::{channel, Body, Resp};
use base64::Engine;
use bytes::Bytes;
use ctr::cipher::{KeyIvInit, StreamCipher};
use hmac::{Hmac, Mac};
use serde_json::{json, Value};
use sha2::Sha256;
use std::sync::{Arc, LazyLock, Mutex};
use std::time::Duration;

pub const SIGN_KEY: &str = "p93jhgh689SBReK6ghtw62";

fn codecs(q: &str) -> &'static [&'static str] {
    match q {
        "hq" | "nq" => &["aac-mp4", "aac", "mp3", "he-aac", "he-aac-mp4"],
        _ => &["flac", "flac-mp4", "aac-mp4", "aac", "he-aac", "mp3", "he-aac-mp4"],
    }
}
fn quality(q: &str) -> &'static str {
    match q {
        "hq" => "nq",
        "nq" => "lq",
        _ => "lossless",
    }
}

pub fn signed_query(track_id: &str, q: &str) -> String {
    let ts = (now_ms() / 1000.0).floor() as i64;
    let codecs = codecs(q).join(",");
    let pairs = [
        ("ts", ts.to_string()),
        ("trackId", track_id.to_string()),
        ("quality", quality(q).to_string()),
        ("codecs", codecs),
        ("transports", "encraw".to_string()),
    ];
    let msg: String = pairs.iter().map(|x| x.1.as_str()).collect::<String>().replace(',', "");
    let mut mac = Hmac::<Sha256>::new_from_slice(SIGN_KEY.as_bytes()).unwrap();
    mac.update(msg.as_bytes());
    let mut sign = base64::engine::general_purpose::STANDARD.encode(mac.finalize().into_bytes());
    sign.pop();
    let mut all: Vec<(&str, &str)> = pairs.iter().map(|(k, v)| (*k, v.as_str())).collect();
    all.push(("sign", &sign));
    qs(&all)
}

fn mime(codec: &str) -> Option<&'static str> {
    Some(match codec {
        "flac" => "audio/flac",
        "flac-mp4" | "aac-mp4" | "he-aac-mp4" => "audio/mp4",
        "aac" | "he-aac" => "audio/aac",
        "mp3" => "audio/mpeg",
        _ => return None,
    })
}
fn label(codec: &str) -> &'static str {
    match codec {
        "flac" | "flac-mp4" => "FLAC",
        "aac-mp4" | "aac" => "AAC",
        "he-aac-mp4" | "he-aac" => "HE-AAC",
        _ => "MP3",
    }
}

pub struct Info {
    pub url: String,
    pub kbps: Value,
    pub key: Option<String>,
    pub mime: &'static str,
    pub label: &'static str,
    pub lossless: bool,
}

pub fn parse_info(r: &Value) -> Option<Info> {
    let d = if r.g("downloadInfo").truthy() {
        r.g("downloadInfo")
    } else if r.g("download_info").truthy() {
        r.g("download_info")
    } else {
        r
    };
    if !d.is_object() {
        return None;
    }
    let mut cands = vec![d.g("url").clone()];
    cands.extend(d.g("urls").arr().iter().cloned());
    let url = cands.iter().map(|u| u.s()).find(|u| re!(r"^https://[^\s]{8,2000}$").is_match(u))?;
    let codec = d.g("codec").s().to_lowercase();
    let mime = mime(&codec)?;
    let enc = d.g("transport").s().contains("enc") || d.g("key").truthy();
    let k = d.g("key").s();
    let key = if enc && re!(r"(?i)^[0-9a-f]{32}([0-9a-f]{32})?$").is_match(&k) { Some(k.to_lowercase()) } else { None };
    if enc && key.is_none() {
        return None;
    }
    let kbps = d.g("bitrate").n();
    Some(Info {
        url,
        kbps: if kbps > 0.0 { jn(kbps) } else { Value::Null },
        key,
        mime,
        label: label(&codec),
        lossless: codec.starts_with("flac"),
    })
}

/* ---------- decryption ---------- */
enum Dec {
    A128(ctr::Ctr128BE<aes::Aes128>),
    A256(ctr::Ctr128BE<aes::Aes256>),
}
impl Dec {
    fn at(key_hex: &str, offset: u64) -> Option<Dec> {
        let key = hex::decode(key_hex).ok()?;
        let mut iv = [0u8; 16];
        iv[8..].copy_from_slice(&(offset / 16).to_be_bytes());
        Some(if key.len() == 32 {
            Dec::A256(ctr::Ctr128BE::<aes::Aes256>::new_from_slices(&key, &iv).ok()?)
        } else {
            Dec::A128(ctr::Ctr128BE::<aes::Aes128>::new_from_slices(&key, &iv).ok()?)
        })
    }
    fn apply(&mut self, b: &mut [u8]) {
        match self {
            Dec::A128(c) => c.apply_keystream(b),
            Dec::A256(c) => c.apply_keystream(b),
        }
    }
}

pub struct Entry {
    pub url: String,
    pub key: String,
    pub mime: String,
    pub at: f64,
    pub size: Option<u64>,
    /// the Yandex track id + quality: a fresh link (and key) when the old one expired
    pub refresh: Option<(String, String)>,
}

static ENTRIES: LazyLock<Mutex<Vec<(String, Arc<Mutex<Entry>>)>>> = LazyLock::new(|| Mutex::new(vec![]));

pub fn register(url: String, key: String, mime: String, refresh: Option<(String, String)>) -> String {
    let id = hex::encode(rand::random::<[u8; 12]>());
    let mut m = ENTRIES.lock().unwrap();
    m.push((id.clone(), Arc::new(Mutex::new(Entry { url, key, mime, at: now_ms(), size: None, refresh }))));
    let now = now_ms();
    let mut i = 0;
    while i < m.len() {
        let old = now - m[i].1.lock().unwrap().at > 12.0 * 3600e3;
        if m.len() > 40 || old {
            m.remove(i);
        } else {
            i += 1;
        }
    }
    format!("wave-media://ym/{}", id)
}
pub fn entry(id: &str) -> Option<Arc<Mutex<Entry>>> {
    ENTRIES.lock().unwrap().iter().find(|x| x.0 == id).map(|x| x.1.clone())
}

struct Range {
    start: Option<u64>,
    end: Option<u64>,
    suffix: bool,
}
fn parse_range(h: Option<&str>) -> Option<Range> {
    let m = re!(r"^bytes=(\d*)-(\d*)$").captures(h?.trim())?;
    if m[1].is_empty() && m[2].is_empty() {
        return None;
    }
    Some(Range {
        start: m[1].parse().ok(),
        end: m[2].parse().ok(),
        suffix: m[1].is_empty(),
    })
}

const HEAD_MS: u64 = 20000;
const READ_MS: u64 = 15000;
const RETRIES: u32 = 4;

async fn open(e: &Arc<Mutex<Entry>>, off: u64, ask_end: Option<u64>) -> Result<(reqwest::Response, u64), String> {
    let mut renewed = false;
    loop {
        let url = e.lock().unwrap().url.clone();
        let mut rq = crate::http::RAW.get(&url);
        if off > 0 || ask_end.is_some() {
            rq = rq.header(
                "Range",
                format!("bytes={}-{}", off, ask_end.map(|x| x.to_string()).unwrap_or_default()),
            );
        }
        let up = match tokio::time::timeout(Duration::from_millis(HEAD_MS), rq.send()).await {
            Ok(Ok(r)) => r,
            Ok(Err(_)) => return Err("fetch failed".into()),
            Err(_) => return Err("upstream timeout".into()),
        };
        let st = up.status().as_u16();
        let refresh = e.lock().unwrap().refresh.clone();
        if (st == 403 || st == 410) && !renewed {
            if let Some((id, q)) = refresh {
                renewed = true;
                let mime = e.lock().unwrap().mime.clone();
                if let Ok(Some((u, k))) = super::yandex::renew_enc(&id, &q, &mime).await {
                    let mut en = e.lock().unwrap();
                    en.url = u;
                    en.key = k;
                    drop(en);
                    continue;
                }
            }
        }
        let o = if st == 206 { off } else { 0 };
        return Ok((up, o));
    }
}

fn hdr(r: &reqwest::Response, k: &str) -> Option<String> {
    r.headers().get(k).and_then(|v| v.to_str().ok()).map(String::from)
}

pub async fn serve_decrypted(e: Arc<Mutex<Entry>>, range: Option<&str>) -> Resp {
    let rg = parse_range(range);
    let mut total = e.lock().unwrap().size;
    if rg.as_ref().map(|r| r.suffix).unwrap_or(false) && total.is_none() {
        let url = e.lock().unwrap().url.clone();
        if let Ok(h) = crate::http::RAW.head(&url).timeout(Duration::from_secs(15)).send().await {
            total = hdr(&h, "content-length").and_then(|v| v.parse().ok()).filter(|x| *x > 0);
            if total.is_some() {
                e.lock().unwrap().size = total;
            }
        }
    }
    let start = match &rg {
        Some(r) if r.suffix => total.unwrap_or(0).saturating_sub(r.end.unwrap_or(0)),
        Some(r) => r.start.unwrap_or(0),
        None => 0,
    };
    let mut end = match &rg {
        Some(r) if !r.suffix => r.end,
        _ => None,
    };
    let ask_end = end;
    let (up, off) = match open(&e, start - start % 16, ask_end).await {
        Ok(x) => x,
        Err(m) => {
            crate::app::blog(&format!("ym stream: {}", m));
            return Resp::text(502, "upstream error");
        }
    };
    let st = up.status().as_u16();
    if !up.status().is_success() && st != 206 {
        return Resp::text(502, &format!("upstream {}", st));
    }
    if let Some(cr) = hdr(&up, "content-range") {
        if let Some(m) = re!(r"/(\d+)\s*$").captures(&cr) {
            total = m[1].parse().ok();
        }
    } else if st == 200 {
        total = hdr(&up, "content-length").and_then(|v| v.parse().ok()).filter(|x| *x > 0).or(total);
    }
    if total.is_some() {
        e.lock().unwrap().size = total;
    }
    if end.is_none() {
        if let Some(t) = total {
            end = Some(t.saturating_sub(1));
        }
    }
    let last = end.unwrap_or(u64::MAX);
    let (tx, body) = channel(8);
    let e2 = e.clone();
    tokio::spawn(async move {
        let mut cur = (up, off);
        let mut next = start;
        let mut fails = 0u32;
        loop {
            let (mut resp, coff) = cur;
            let mut pos = coff;
            let key = e2.lock().unwrap().key.clone();
            let Some(mut dec) = Dec::at(&key, pos) else {
                let _ = tx.send(Err(std::io::Error::other("bad key"))).await;
                return;
            };
            let mut clean = false;
            let mut err: Option<String> = None;
            loop {
                match tokio::time::timeout(Duration::from_millis(READ_MS), resp.chunk()).await {
                    Ok(Ok(Some(ch))) => {
                        let mut buf = ch.to_vec();
                        dec.apply(&mut buf);
                        let len = buf.len() as u64;
                        let a = pos.max(next);
                        let b = (pos + len).min(last.saturating_add(1));
                        if b > a {
                            let part = Bytes::copy_from_slice(&buf[(a - pos) as usize..(b - pos) as usize]);
                            if tx.send(Ok(part)).await.is_err() {
                                return; // the player went away
                            }
                            next = b;
                            fails = 0;
                        }
                        pos += len;
                        if next > last {
                            return;
                        }
                    }
                    Ok(Ok(None)) => {
                        clean = true;
                        break;
                    }
                    Ok(Err(_)) => {
                        err = Some("fetch failed".into());
                        break;
                    }
                    Err(_) => {
                        err = Some("upstream stalled".into());
                        break;
                    }
                }
            }
            if tx.is_closed() {
                return;
            }
            if clean && (last == u64::MAX || total.map(|t| next >= t).unwrap_or(false)) {
                return;
            }
            fails += 1;
            if fails > RETRIES {
                let _ = tx.send(Err(std::io::Error::other(err.unwrap_or_else(|| "upstream ended early".into())))).await;
                return;
            }
            tokio::time::sleep(Duration::from_millis(300 * fails as u64)).await;
            if tx.is_closed() {
                return;
            }
            match open(&e2, next - next % 16, ask_end).await {
                Ok((r, o)) => {
                    let s = r.status().as_u16();
                    if !r.status().is_success() && s != 206 {
                        let _ = tx.send(Err(std::io::Error::other(format!("upstream {}", s)))).await;
                        return;
                    }
                    cur = (r, o);
                }
                Err(m) => {
                    let _ = tx.send(Err(std::io::Error::other(m))).await;
                    return;
                }
            }
        }
    });
    let mime = e.lock().unwrap().mime.clone();
    let mut r = Resp { status: 200, headers: vec![], body: Body::Stream(body) }
        .h("Content-Type", if mime.is_empty() { "audio/mpeg" } else { &mime })
        .h("Accept-Ranges", "bytes")
        .h("Access-Control-Allow-Origin", "*")
        .h("Cache-Control", "no-cache");
    if let Some(en) = end {
        r = r.h("Content-Length", &(en + 1 - start).to_string());
    }
    if let (Some(_), Some(t)) = (&rg, total) {
        r.status = 206;
        r = r.h("Content-Range", &format!("bytes {}-{}/{}", start, end.unwrap_or(t - 1), t));
    }
    r
}

pub fn info_json(i: &Info) -> Value {
    json!({ "codec": i.label, "kbps": i.kbps, "lossless": i.lossless })
}
