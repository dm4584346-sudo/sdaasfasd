//! Wave Android — the backend in Rust. It replaces the embedded Node.js (nodejs-mobile + the desktop core run through
#![recursion_limit = "512"]
//! an Electron stand-in): the Java class `app.wave.mobile.NodeRunner` still calls the same two native functions
//! (`setEnv`, `startNode`) of libwavenode.so, so the interface (WebView), the Java shell and the audio playback stay
//! exactly as they were.

pub mod app;
pub mod cfg;
pub mod commands;
pub mod engine;
pub mod http;
pub mod js;
pub mod offline;
pub mod providers;
pub mod resp;
pub mod security;
pub mod server;
pub mod social;
pub mod store;
pub mod vault;
pub mod windows;

use std::path::{Path, PathBuf};

/// starts everything and serves until the process ends. `root` is the folder of the installed assets
/// (<files>/wave, with ui/ inside).
pub fn run(root: &Path) -> i32 {
    let data = std::env::var("WAVE_DATA").map(PathBuf::from).unwrap_or_else(|_| root.join("data"));
    let _ = std::fs::create_dir_all(&data);
    let port: u16 = std::env::var("WAVE_PORT").ok().and_then(|p| p.parse().ok()).filter(|p| *p > 0).unwrap_or(47800);
    let key = std::env::var("WAVE_KEY").ok().filter(|k| !k.is_empty()).unwrap_or_else(|| hex::encode(rand::random::<[u8; 16]>()));
    // the version of this build (the Java side passes the one of its manifest, which is patched to the same value)
    let version = env!("CARGO_PKG_VERSION").to_string();
    let rt = match tokio::runtime::Builder::new_multi_thread().worker_threads(4).enable_all().thread_name("wave-rt").build() {
        Ok(rt) => rt,
        Err(e) => {
            app::log(&format!("runtime: {}", e));
            return 2;
        }
    };
    rt.block_on(async move {
        let settings = store::Store::open(data.join("settings.json"), cfg::default_settings());
        let library = store::Store::open(data.join("library.json"), cfg::default_library());
        let (events, _) = tokio::sync::broadcast::channel(256);
        app::init(app::App {
            data: data.clone(),
            ui: root.join("ui"),
            port,
            key,
            version,
            settings: settings.clone(),
            library: library.clone(),
            events,
            pending_files: std::sync::Mutex::new(vec![]),
        });
        app::blog("ready");
        cfg::repair_settings(&mut settings.lock());
        settings.save();
        let before = library.lock().to_string();
        cfg::repair_library(&mut library.lock());
        if library.lock().to_string() != before {
            library.save();
            library.flush_now();
        }
        providers::spotify::load();
        engine::load_ym_token();
        engine::ym_likes_schedule();
        tokio::spawn(async {
            tokio::time::sleep(std::time::Duration::from_secs(15)).await;
            engine::sweep_media().await;
        });
        if providers::yandex::has_token() {
            tokio::spawn(async {
                if let Ok(me) = providers::yandex::account().await {
                    app::emit(serde_json::json!({ "type": "ym", "value": { "connected": true, "user": me.get("name") } }));
                }
            });
        }
        if providers::spotify::connected() {
            tokio::spawn(async {
                if providers::spotify::token().await.is_ok() {
                    if let Ok(me) = providers::spotify::me().await {
                        providers::spotify::set_me(me);
                        app::emit(serde_json::json!({ "type": "spotify", "value": providers::spotify::public() }));
                    }
                }
            });
        }
        if let Err(e) = server::run().await {
            app::log(&format!("server: {}", e));
            return 1;
        }
        0
    })
}

/* ---------- JNI: app.wave.mobile.NodeRunner ---------- */
#[cfg(target_os = "android")]
mod jni_entry {
    use jni::objects::{JClass, JObjectArray, JString};
    use jni::sys::jint;
    use jni::JNIEnv;

    #[no_mangle]
    pub extern "system" fn Java_app_wave_mobile_NodeRunner_setEnv(mut env: JNIEnv, _c: JClass, k: JString, v: JString) {
        let k: String = env.get_string(&k).map(|s| s.into()).unwrap_or_default();
        let v: String = env.get_string(&v).map(|s| s.into()).unwrap_or_default();
        if !k.is_empty() {
            std::env::set_var(k, v);
        }
    }

    /// args = ["node", "<files>/wave/node/server.cjs"] — the folder of the assets is taken from the script path
    #[no_mangle]
    pub extern "system" fn Java_app_wave_mobile_NodeRunner_startNode(mut env: JNIEnv, _c: JClass, args: JObjectArray) -> jint {
        let n = env.get_array_length(&args).unwrap_or(0);
        let script: String = if n > 1 {
            env.get_object_array_element(&args, 1)
                .ok()
                .and_then(|o| env.get_string(&JString::from(o)).ok().map(|s| s.into()))
                .unwrap_or_default()
        } else {
            String::new()
        };
        let p = std::path::PathBuf::from(script);
        let root = p.parent().and_then(|x| x.parent()).map(|x| x.to_path_buf()).unwrap_or_else(|| std::path::PathBuf::from("."));
        match std::panic::catch_unwind(|| super::run(&root)) {
            Ok(c) => c,
            Err(_) => 70,
        }
    }
}


/* ---------- iOS: called from the Swift shell (AppDelegate) ---------- */
#[cfg(target_os = "ios")]
mod ios_entry {
    use std::ffi::CStr;
    use std::os::raw::c_char;

    fn s(p: *const c_char) -> String {
        if p.is_null() {
            return String::new();
        }
        unsafe { CStr::from_ptr(p) }.to_string_lossy().into_owned()
    }

    /// starts the core on its own thread and returns at once; `root` is the folder with ui/ inside
    #[no_mangle]
    pub extern "C" fn wave_ios_start(root: *const c_char, data: *const c_char, port: u16, key: *const c_char) -> i32 {
        let root = s(root);
        let data = s(data);
        let key = s(key);
        if !data.is_empty() {
            std::env::set_var("WAVE_DATA", &data);
        }
        std::env::set_var("WAVE_PORT", port.to_string());
        if !key.is_empty() {
            std::env::set_var("WAVE_KEY", &key);
        }
        let r = std::thread::Builder::new().name("wave-core".into()).stack_size(8 * 1024 * 1024).spawn(move || {
            let _ = std::panic::catch_unwind(|| super::run(std::path::Path::new(&root)));
        });
        if r.is_ok() { 0 } else { 1 }
    }
}
